'use strict';
(function(root){
  const bookPages=['read','talk','results'];
  const isBook=page=>bookPages.includes(page);
  const basic=page=>({page});
  function defaults(page,selection){
    const map=basic('map'),practice=basic('practice'),home=[map,practice,basic('home')];
    if(page==='map')return [];
    if(page==='practice')return [map];
    if(page==='home')return [map,practice];
    if(page==='read'||page==='clip')return [...home,basic('shelf')];
    if(page==='talk'||page==='results')return [...home,basic('shelf'),{...selection,page:'read',anchor:'reading-selection'}];
    if(page==='item')return [...home,basic('items')];
    return home;
  }
  function enter(trail,from,to){
    if(from.page===to.page)return trail;
    if(to.page==='home'||to.page==='map'||to.page==='practice')return defaults(to.page,to);
    // The three book tabs share one selection. Switching tabs must not build a back loop.
    if(isBook(from.page)&&isBook(to.page)){
      if(from.page==='read')return [...trail,from];
      if(to.page==='read'&&trail.at(-1)?.page==='read')return trail.slice(0,-1);
      return trail;
    }
    if(['cards','visits'].includes(from.page)&&['cards','visits'].includes(to.page))return trail;
    const next=[...trail,from];
    if(to.page==='talk')next.push({...to,page:'read',anchor:'reading-selection'});
    return next;
  }
  root.MindTrail={defaults,enter};
  if(typeof module!=='undefined'&&module.exports)module.exports=root.MindTrail;
})(globalThis);
