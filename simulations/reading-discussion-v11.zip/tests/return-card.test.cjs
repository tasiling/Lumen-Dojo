'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const C=require('../core.js');
const R=require('../returns.js');

const note={id:'test-a',label:'第一段',excerpt:'測試書摘',reflection:'測試舊筆記'};
const other={...note,id:'test-b',label:'第二段'};
const notes=[note,other];
function local(){
  const db={v:1,mode:'demo',note:other.id,scopes:{},sessions:{}};
  function add(mode,n,scope){
    const key=R.baseKey(mode,n.id,scope),thread=C.newThread();
    C.newPacket(thread);db.sessions[key]=thread;
    return {key,thread,mode,scope};
  }
  return {db,mine:add('my',note,'excerpt'),demo:add('demo',other,'both')};
}
function card(thread,n=note){
  return {格式:C.format,討論ID:thread.id,討論包ID:thread.pack.id,選段ID:n.id,狀態:'完成',
    問答:[{角色:'GPT',內容:'你如何安排？'},{角色:'我',內容:'我先看目次，再選一頁。'}],下次從這裡:'',
    候選:[{類型:'觀點',內容:'可以先看目次。',依據:'T2',依據原句:'先看目次',行動:''}]};
}
test('a real return pasted into a different example finds its original note, scope and discussion',()=>{
  const {db,mine,demo}=local(),raw=JSON.stringify(card(mine.thread));
  demo.thread.raw=raw;mine.thread.raw='另一份尚未整理的草稿';
  const plan=R.locate(db,notes,raw);
  assert.equal(plan.known.key,mine.key);assert.equal(plan.scope,'excerpt');
  const result=R.save(db,notes,raw,demo.key,'my','excerpt');
  assert.equal(result.turns.length,2);assert.equal(db.mode,'my');assert.equal(db.note,note.id);
  assert.equal(mine.thread.rounds.length,1);assert.equal(mine.thread.proposals[0].origin,'本人');
  assert.equal(mine.thread.products.length,0);assert.equal(mine.thread.raw,'另一份尚未整理的草稿');
  assert.equal(demo.thread.raw,'');assert.equal(demo.thread.rounds.length,0);
  const reload=JSON.parse(JSON.stringify(db));
  assert.equal(R.activeKey(reload,'my',note.id,'excerpt'),mine.key);
  assert.throws(()=>R.save(reload,notes,raw,demo.key,'my','excerpt'),/已經保存/);
  assert.equal(reload.sessions[mine.key].rounds.length,1);
});
test('an old card can be brought back on another browser without overwriting an open packet or inventing a scope',()=>{
  const {db,mine,demo}=local(),foreign=C.newThread();C.newPacket(foreign);
  const d=card(foreign);d.候選.push({類型:'觀點',內容:'來自原書',依據:'S',依據原句:'測試書摘'});
  const raw=JSON.stringify(d);
  const plan=R.locate(db,notes,raw);
  assert.equal(plan.known,undefined);assert.equal(plan.scope,null);
  const before=JSON.stringify(mine.thread);
  R.save(db,notes,raw,demo.key,'my','unknown');
  const target=R.locate(db,notes,raw).known;
  assert.equal(target.thread.id,d.討論ID);assert.equal(target.thread.pack.id,d.討論包ID);
  assert.equal(target.thread.recovered,true);assert.equal(target.scope,'unknown');
  assert.equal(target.thread.proposals.length,1);assert.equal(target.thread.rounds[0].pending.length,1);
  assert.equal(JSON.stringify(mine.thread),before);assert.equal(R.activeKey(db,'my',note.id,'unknown'),target.key);
});
test('freshly brought-back cards with the same selection remain separately reachable',()=>{
  const {db,mine}=local(),foreign=C.newThread();C.newPacket(foreign);
  const d=card(foreign);d.帶入範圍='excerpt';
  const raw=JSON.stringify(d),firstId=mine.thread.pack.id;
  R.save(db,notes,raw,mine.key,'my','excerpt');
  assert.notEqual(R.activeKey(db,'my',note.id,'excerpt'),mine.key);
  const original=R.sessions(db).find(t=>t.key===mine.key);R.select(db,original);
  assert.equal(R.activeKey(db,'my',note.id,'excerpt'),mine.key);
  assert.equal(mine.thread.pack.id,firstId);assert.equal(mine.thread.rounds.length,0);
});
test('known built-in demonstration stays in its own history, including pre-marker example cards',()=>{
  const {db,mine,demo}=local();
  for(const marked of [false,true]){
    const d=JSON.parse(C.exampleCard(demo.thread,other,'both','完成'));if(!marked)delete d.內建示例;
    const raw=JSON.stringify(d),plan=R.locate(db,notes,raw);
    assert.equal(plan.sample,true);assert.equal(plan.known.key,demo.key);
    assert.throws(()=>R.save(db,notes,raw,mine.key,'my','both'),/示例區/);
  }
  const raw=C.exampleCard(demo.thread,other,'both','完成');
  R.save(db,notes,raw,mine.key,'demo','both');
  assert.equal(demo.thread.rounds.length,1);assert.equal(mine.thread.rounds.length,0);
});
test('user dialogue started with a demonstration packet needs a personal destination and keeps both identities',()=>{
  const {db,mine,demo}=local(),raw=JSON.stringify(card(demo.thread,other));
  assert.equal(R.locate(db,notes,raw).chooseOwner,true);
  R.save(db,notes,raw,demo.key,'my','both');
  assert.equal(R.locate(db,notes,raw).known.mode,'my');
  assert.equal(R.locate(db,notes,C.exampleCard(demo.thread,other,'both','完成')).known.mode,'demo');
  assert.equal(demo.thread.rounds.length,0);assert.equal(mine.thread.rounds.length,0);
  assert.throws(()=>R.save(db,notes,raw,demo.key,'my','both'),/已經保存/);
});
test('partly invalid evidence retains the original candidate while the valid transcript and sourced candidate save',()=>{
  const {db,mine}=local(),d=card(mine.thread);
  d.候選.push({類型:'洞察卡',內容:'試一次',依據:'T2',依據原句:'不是原句',行動:'回看一次'});
  const r=R.save(db,notes,JSON.stringify(d),mine.key,'my','excerpt');
  assert.deepEqual(r.pending[0].original,d.候選[1]);assert.equal(mine.thread.products.length,0);
  const correction={...d.候選[1],依據:'T1',依據原句:'如何安排'};
  const p=C.repairCandidate(mine.thread,note,'excerpt',d.討論包ID,1,correction);
  assert.equal(p.origin,'GPT');assert.equal(p.share,false);assert.equal(mine.thread.rounds[0].pending.length,0);
  assert.throws(()=>C.repairCandidate(mine.thread,note,'excerpt',d.討論包ID,1,correction));
  assert.equal(C.adopt(mine.thread,p.id).origin,'GPT');
});
test('a mismatch, invalid envelope or ambiguous speaker does not alter either local history',()=>{
  const {db,mine,demo}=local(),d=card(mine.thread);
  for(const changes of [{選段ID:other.id},{討論ID:demo.thread.id},{討論包ID:demo.thread.pack.id},{選段ID:'no-record'},{問答:[]},{討論ID:'missing'},{帶入範圍:'both'},{問答:[{角色:'未知',內容:'這是誰說的？'}]}]){
    const before=JSON.stringify(db);
    assert.throws(()=>R.save(db,notes,JSON.stringify({...d,...changes}),demo.key,'my','excerpt'));
    assert.equal(JSON.stringify(db),before);
  }
});
test('duplicate after a later round routes to the saved round without consuming the open continuation',()=>{
  const {db,mine,demo}=local(),d=card(mine.thread),raw=JSON.stringify(d);
  R.save(db,notes,raw,demo.key,'my','excerpt');C.newPacket(mine.thread);
  const next=mine.thread.pack.id;
  assert.equal(R.savedRound(R.locate(db,notes,raw).known,d.討論包ID).status,'完成');
  assert.throws(()=>R.save(db,notes,raw,demo.key,'my','excerpt'),/已經保存/);
  assert.equal(mine.thread.pack.id,next);
  const follow={...card(mine.thread),狀態:'暫存',下次從這裡:'明天再往下讀',候選:[]};
  const resumed=R.save(db,notes,JSON.stringify(follow),demo.key,'my','excerpt');
  assert.equal(resumed.seq,2);assert.equal(db.tab,'talk');assert.equal(mine.thread.rounds.length,2);
});
test('copying fenced JSON or literal line breaks preserves quotes, speaker and original text',()=>{
  const {db,mine}=local(),d=card(mine.thread);
  d.問答=[{role:'user',content:'第一行\n第二行有「引言」和 "引號"'}];d.候選=[];
  d.討論ID=d.討論ID.replaceAll('-','–');
  const raw=JSON.stringify(d).replace('第一行\\n','第一行\n');
  const wrapped=['上方文字 {提示}',String.fromCharCode(96).repeat(3)+'json',raw,String.fromCharCode(96).repeat(3),'下方文字 {說明}'].join('\n');
  const round=R.save(db,notes,wrapped,mine.key,'my','excerpt');
  assert.deepEqual(round.turns,[{role:'我',text:d.問答[0].content}]);
});

test('copying a confirmed insight includes its action, reading source and version',()=>{
  const {db,mine}=local();
  const data=card(mine.thread);
  data.候選=[{類型:'洞察卡',內容:'從目次選一頁',依據:'T2',依據原句:'先看目次',行動:'試一次'}];
  R.save(db,notes,JSON.stringify(data),mine.key,'my','excerpt');
  const insight=C.adopt(mine.thread,mine.thread.proposals[0].id);
  const text=C.productText({book:'選讀',read:1},{...note,location:'第 24 頁'},mine.thread,insight);
  assert.equal(text,'【洞察卡】\n從目次選一頁\n待觀察／執行　試一次\n來源　選讀 · 第 1 次閱讀 · 第一段 · 第 24 頁 · 第 1 輪討論 · v1');
  assert.doesNotMatch(text,/測試書摘|你如何安排|我先看目次/);
});
