'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {defaults,enter}=require('../trail.js');
const home={page:'home'},english={page:'item',item:'english',anchor:'item-tools'},shelf={page:'shelf'},read={page:'read',note:'example',scope:'excerpt',key:'my|example|excerpt'},talk={...read,page:'talk'},results={...read,page:'results'};
test('item, shelf and exact reading selection survive switching discussion tabs',()=>{
  let trail=defaults('home',home);
  for(const [from,to] of [[home,english],[english,shelf],[shelf,read],[read,talk],[talk,results]])trail=enter(trail,from,to);
  assert.deepEqual(trail.slice(-3),[english,shelf,read]);
  assert.deepEqual(enter(trail,results,read).slice(-2),[english,shelf]);
});
test('home resume gets its original selection while a card opens back to its library',()=>{
  const resumed=enter([],home,talk);assert.equal(resumed.at(-1).key,read.key);assert.equal(resumed.at(-1).page,'read');
  const library={page:'cards',filter:'pending'};
  assert.deepEqual(enter([],library,results),[library]);
  assert.deepEqual(enter([home],library,{page:'visits'}),[home]);
});
test('direct reading links have a usable parent and switching fields starts at the map',()=>{
  assert.deepEqual(defaults('talk',talk).map(p=>p.page),['map','practice','home','shelf','read']);
  assert.deepEqual(enter([home,english],talk,{page:'map'}),[]);
});
