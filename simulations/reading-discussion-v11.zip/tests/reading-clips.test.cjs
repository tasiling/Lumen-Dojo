'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const clips = require('../reading-clips.js');
const C = require('../core.js');
require('../returns.js');
const hub = require('../mind.js');

const reference = {book:'書架原書',read:1,start:'2026-10-01',opening:'舊書的問題',source:'舊書來源'};
const photo = {id:'local-image',name:'第24頁.png',bookTitle:' 書頁紀錄 ',readNumber:'2',location:'第 24 頁',ocr:'原始辨識',excerpt:'核對後的原句',reflection:'本人的想法'};

test('automatic Chinese spacing cleanup keeps line breaks and English words intact',()=>{
  assert.equal(clips.readingText('  桌 上 有 一 張 白紙 。\n寫 下 今天 的 觀察\nReading notes 24  '),'桌上有一張白紙。\n寫下今天的觀察\nReading notes 24');
  assert.equal(clips.makeNote({...photo,excerpt:'我 刻意留白。'},'my').excerpt,'我 刻意留白。');
});

test('a reviewed photo uses its own book and reading, with excerpt and reflection kept apart',()=>{
  const n=clips.makeNote(photo,'my');
  assert.equal(n.id,clips.makeNote({...photo,label:'重新命名'},'my').id);
  assert.equal(n.clipId,photo.id);
  const info=clips.bookInfo(n,reference);
  assert.deepEqual([info.book,info.read,info.original,info.start],['書頁紀錄',2,false,'']);
  assert.equal(clips.bookInfo({},reference).original,true);
  assert.equal(clips.bookInfo({...n,bookTitle:reference.book},reference).original,false);
  const t=C.newThread();C.newPacket(t);
  const prompt=C.buildPacket(info,n,'both',t);
  for(const expected of ['書頁紀錄','第 2 次','行光剪藏','第 24 頁','【S｜作者原文】\n核對後的原句','【N｜我當時已寫下的想法】\n本人的想法'])assert.ok(prompt.includes(expected));
  assert.doesNotMatch(prompt,/原始辨識|舊書的問題|舊書來源|undefined/);
  for(const change of [{bookTitle:' '},{readNumber:0},{readNumber:1.5},{excerpt:' '}])assert.throws(()=>clips.makeNote({...photo,...change},'my'));
});

test('manual cards retain their origin, stay personal, and never create a pending discussion',()=>{
  const note=clips.makeNote(photo,'my');
  const card=clips.manualCard(note,{type:'觀點',text:'我的新理解',action:'多餘'},'mine');
  assert.deepEqual([card.quote,card.noteId,card.share,card.action],['核對後的原句',note.id,false,'']);
  assert.throws(()=>clips.manualCard(note,{type:'洞察卡',text:'我的理解'},'invalid'));
  const insight=clips.manualCard({...note,excerpt:''},{type:'洞察卡',text:'值得觀察的事',action:'下次試著寫下來'},'other');
  assert.deepEqual([insight.originLabel,insight.quote],['原筆記・我的心得','本人的想法']);
  const db={sessions:{}};hub.init(db);db.mind.manualCards=[card];db.mind.demo.manualCards=[insight];
  card.review={date:hub.day(),history:[]};
  assert.deepEqual(hub.index(db,'my').saved.map(s=>s.p.id),['mine']);
  assert.deepEqual(hub.index(db,'demo').saved.map(s=>s.p.id),['other']);
  assert.equal(hub.index(db,'my').due.length,1);
  assert.equal(hub.index(db,'my').pending.length,0);
  assert.equal(hub.index(db,'my').records.length,0);
  const copied=C.productText(clips.bookInfo(note,reference),note,null,card);
  for(const expected of ['書頁紀錄','第 24 頁','我的新理解','作者原文','核對後的原句'])assert.ok(copied.includes(expected));
  assert.doesNotMatch(copied,/輪討論/);
  assert.throws(()=>C.useItem(card,'織光堂'));card.share=true;
  assert.equal(C.useItem(card,'織光堂'),true);assert.equal(C.useItem(card,'織光堂'),false);
});
