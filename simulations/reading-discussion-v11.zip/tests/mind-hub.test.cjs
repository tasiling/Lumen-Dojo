'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const C=require('../core.js');
const R=require('../returns.js');
const H=require('../mind.js');

test('opening the hub preserves prior saved reading and builds personal and demo workspaces separately',()=>{
  const t=C.newThread(), n={id:'book-a',excerpt:'書中原文',reflection:'我的心得'};C.newPacket(t);
  const origin=R.baseKey('my',n.id,'both'), demoKey=R.baseKey('demo',n.id,'both');
  const db={v:1,sessions:{[origin]:t,[demoKey]:C.newThread()},scopes:{},mode:'my',note:n.id};
  const d={格式:C.format,選段ID:n.id,討論ID:t.id,討論包ID:t.pack.id,狀態:'完成',問答:[{角色:'我',內容:'這是我說過的。'}],候選:[{類型:'觀點',內容:'我的觀點',依據:'T1',依據原句:'我說過的'}]};
  R.save(db,[n],JSON.stringify(d),origin,'my','both');
  const before=JSON.stringify(db.sessions);H.init(db);H.init(db);
  assert.equal(JSON.stringify(db.sessions),before);
  assert.equal(H.index(db,'my').count(H.index(db,'my').pending[0]),1);
  assert.equal(H.index(db,'demo').pending.length,0);
  db.mind.items[0].focus=true;assert.equal(db.mind.demo.items[0].focus,false);
  const product=C.adopt(t,t.proposals[0].id);product.review={date:H.day(),history:[]};
  assert.equal(H.index(db,'my').due[0].p.id,product.id);assert.equal(H.index(db,'demo').saved.length,0);
  product.review.history.push({date:H.day(),text:'留下觀察'});product.review.date='';
  const reloaded=JSON.parse(JSON.stringify(db));H.init(reloaded);
  assert.equal(H.index(reloaded,'my').due.length,0);
  assert.equal(H.index(reloaded,'my').saved[0].p.review.history[0].text,'留下觀察');
});
test('a personal reading note with a single kind of source carries only the available evidence',()=>{
  const n={id:'local-note',label:'提問',excerpt:'',reflection:'今天的觀察',location:'第二章'};
  const t=C.newThread();C.newPacket(t).scope='reflection';
  const packet=C.buildPacket({book:'測試書籍',read:1,start:'2026-11-18',source:'測試資料',opening:'問題'},n,'reflection',t);
  assert.ok(packet.includes('第二章'));assert.ok(packet.includes('今天的觀察'));assert.ok(!packet.includes('【S｜'));
  assert.deepEqual(Object.keys(C.sourceAnchors(n,'both')),['N']);
});

test('upgrading preserves prior item IDs, focus, logs and reading links and adds the sample drawing only once',()=>{
  const drawing=require('../learning-catalog.js').drawing;
  const existing={id:'user-created',name:'繪圖',steps:[{text:'素描',done:false}],logs:[{date:'2026-11-10',text:'光影'}],focus:true};
  const db={mind:{items:[existing],links:{note:'user-created'},demo:{items:[]}}};
  H.init(db);H.init(db);
  assert.equal(db.mind.items.length,2);
  assert.equal(db.mind.items[1],existing);
  assert.equal(existing.logs[0].text,'光影');assert.equal(existing.focus,true);
  assert.equal(db.mind.links.note,existing.id);
  const item=db.mind.items.find(i=>i.id===drawing.id);assert.equal(item.focus,true);
  item.focus=false;item.status='暫時擱置';H.init(db);assert.equal(item.focus,false);
  assert.equal(db.mind.demo.items[0].focus,false);assert.notEqual(db.mind.demo.items[0],item);
});
test('sample drawing has twenty complete topics and uninitialized templates are not registered as official items',()=>{
  const c=require('../learning-catalog.js');
  assert.deepEqual(c.drawing.stages.map(s=>s.topics.length),[6,4,4,6]);
  for(const s of c.drawing.stages)for(const t of [s,...s.topics])assert.ok(t.description&&t.goal&&t.outcome);
  assert.equal(c.templates.length,9);const db={};H.init(db);
  assert.ok(!db.mind.items.some(i=>i.id==='tarot'));
});

test('a reading selection can link to a learning item before it has any local progress',()=>{
  const db={};H.init(db);
  const item=H.availableItems(db.mind).find(i=>i.id==='psychology');
  assert.equal(item.name,'心理學');
  assert.equal(H.pathFor(item)[0].topics[0].readingNoteId,'demo-reading-a');
  assert.ok(!db.mind.items.some(i=>i.id===item.id));
  db.mind.items.push({...item,id:'existing-psychology',templateKey:item.id});
  const options=H.availableItems(db.mind).filter(i=>i.name===item.name);
  assert.deepEqual(options.map(i=>i.id),['existing-psychology']);
  assert.equal(H.pathFor(options[0])[0].topics[0].name,'閱讀詞彙');
});

test('a prepared discussion carries the reading question recorded with that packet',()=>{
  const book={book:'測試書籍',read:1,start:'2026-11-18',opening:'書架讀前問題',source:'測試資料'};
  const n={id:'note-a',label:'選段 A',excerpt:'摘錄'};
  const thread=C.newThread();
  const packet=C.newPacket(thread);
  assert.match(C.buildPacket(book,n,'excerpt',thread),/讀前問題　書架讀前問題/);
  packet.readingQuestion='準備討論包時的問題';
  const revised={...book,opening:'後來改寫的問題'};
  const prompt=C.buildPacket(revised,n,'excerpt',thread);
  assert.match(prompt,/讀前問題　準備討論包時的問題/);
  assert.doesNotMatch(prompt,/後來改寫的問題/);
});
