'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const C=require('../core.js');
const R=require('../returns.js');
const H=require('../mind.js');

const notes=['a','b'].map(id=>({id,label:'相同的選段名稱',excerpt:'這是原文',reflection:''}));
function setup(){
  const db={mode:'my',note:'a',scopes:{},sessions:{}};
  const add=(mode,n)=>{
    const thread=C.newThread(),scope='both',key=R.baseKey(mode,n.id,scope);
    db.sessions[key]=thread;C.newPacket(thread).scope=scope;
    return {thread,key,n,mode,scope};
  };
  return {db,a:add('my',notes[0]),b:add('my',notes[1]),demo:add('demo',notes[0])};
}
function card(t,status='完成',items=[]){
  return JSON.stringify({格式:C.format,討論ID:t.thread.id,討論包ID:t.thread.pack.id,選段ID:t.n.id,
    帶入範圍:t.scope,狀態:status,下次從這裡:status==='暫存'?'下次從哪一句找例子？':'',
    問答:[{角色:'我',內容:'我想先寫下問題。'}],候選:items});
}
const read=db=>R.resume(db,'my');
const reload=db=>JSON.parse(JSON.stringify(db));
test('prepared packets and finished history stay off home; there is one explicit, dismissible shortcut',()=>{
  const {db,a,b}=setup();R.initResume(db,notes);assert.equal(read(db),null);
  R.pin(db,a.key);assert.equal(read(db).key,a.key);
  R.pin(db,b.key);assert.equal(read(reload(db)).key,b.key);
  R.save(db,notes,card(a),a.key,'my','both');assert.equal(read(db).key,b.key);
  R.dismiss(db,'my',read(db));R.initResume(db,notes);
  assert.equal(read(reload(db)),null);assert.equal(a.thread.rounds.length,1);
  assert.equal(R.pin(db,a.key),false);
});
test('a saved pause shows its exact next step; reopening then saving completion closes only that packet',()=>{
  const {db,a,b}=setup();R.initResume(db,notes);R.pin(db,b.key);
  R.save(db,notes,card(a,'暫存'),a.key,'my','both');
  const first=a.thread.pack.id;
  assert.equal(read(db).next,'下次從哪一句找例子？');
  a.thread.pack=null;assert.equal(read(db).kind,'paused');
  C.newPacket(a.thread);R.pin(db,a.key);assert.notEqual(read(db).packId,first);
  assert.equal(read(db).next,'下次從哪一句找例子？');
  const raw=card(a);a.thread.raw=raw;R.trackDraft(db,notes,a.key);
  assert.equal(read(db).kind,'draft');
  C.check(raw,a.thread,a.n,a.scope);assert.equal(read(db).kind,'draft');
  R.save(db,notes,raw,a.key,'my','both');assert.equal(read(db),null);
  assert.deepEqual(a.thread.rounds.map(r=>r.status),['暫存','完成']);
  a.thread.raw=raw;assert.equal(R.trackDraft(db,notes,a.key),false);assert.equal(read(reload(db)),null);
});
test('completion closes with zero candidates, pending candidates, or evidence to repair',()=>{
  const good={類型:'觀點',內容:'先留下問題',依據:'T1',依據原句:'寫下問題'};
  for(const items of [[],[good],[{...good,依據原句:'未曾說過的句子'}]]){
    const {db,a}=setup();R.initResume(db,notes);R.pin(db,a.key);
    const raw=card(a,'完成',items);a.thread.raw=raw;R.trackDraft(db,notes,a.key);
    assert.equal(read(db).kind,'draft');R.save(db,notes,raw,a.key,'my','both');
    const pending=H.index(db,'my');assert.equal(pending.pending.reduce((n,t)=>n+pending.count(t),0),items.length);
    assert.equal(read(db),null);assert.equal(a.thread.rounds[0].turns.length,1);
  }
});
test('upgrading remembers a selected pause or valid unsaved card once; never sweeps historical pauses',()=>{
  const {db,a,b}=setup();C.commit(card(b,'暫存'),b.thread,b.n,b.scope);
  const old=reload(db);R.initResume(old,notes);assert.equal(read(old),null);
  C.commit(card(a,'暫存'),a.thread,a.n,a.scope);R.initResume(db,notes);assert.equal(read(db).key,a.key);
  R.dismiss(db,'my',read(db));const reopened=reload(db);R.initResume(reopened,notes);assert.equal(read(reopened),null);
  const fresh=setup();fresh.a.thread.raw=card(fresh.b);
  R.initResume(fresh.db,notes);assert.equal(read(fresh.db).target.key,fresh.a.key);assert.equal(read(fresh.db).noteId,'b');
});
test('a valid foreign paste opens its source editor, while malformed text and built-in examples do not take over personal home',()=>{
  const {db,a,b,demo}=setup();R.initResume(db,notes);R.pin(db,b.key);
  demo.thread.raw='還在輸入';R.trackDraft(db,notes,demo.key);assert.equal(read(db).key,b.key);
  const raw=card(a);demo.thread.raw=raw;R.trackDraft(db,notes,demo.key);
  assert.equal(read(db).key,demo.key);assert.equal(read(db).noteId,a.n.id);
  R.save(db,notes,raw,demo.key,'my','both');assert.equal(read(db),null);
  R.pin(db,b.key);a.thread.raw=C.exampleCard(demo.thread,demo.n,'both','完成');R.trackDraft(db,notes,a.key);
  assert.equal(read(db).key,b.key);assert.equal(R.resume(db,'demo').kind,'draft');
  R.save(db,notes,a.thread.raw,a.key,'demo','both');assert.equal(read(db).key,b.key);assert.equal(R.resume(db,'demo'),null);
});
