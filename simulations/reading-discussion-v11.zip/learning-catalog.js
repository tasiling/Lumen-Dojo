'use strict';
const learningCatalog = {
  "drawing": {
    "id": "demo-drawing",
    "name": "繪圖",
    "icon": "write",
    "description": "這個虛構項目用來試走階段、主題、完成標記與紀錄之間的流程。",
    "vision": "用簡筆畫記錄散步看到的形狀。",
    "stages": [
      {
        "name": "紙上散步",
        "description": "可從任何一個主題開始。",
        "goal": "選一個主題，記錄一次觀察。",
        "outcome": "一份可回看的練習紀錄。",
        "topics": [
          {
            "name": "點的距離",
            "description": "挑一個例子，留下對「點的距離」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "短線",
            "description": "挑一個例子，留下對「短線」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "轉彎",
            "description": "挑一個例子，留下對「轉彎」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "曲線",
            "description": "挑一個例子，留下對「曲線」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "交叉",
            "description": "挑一個例子，留下對「交叉」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "間隔",
            "description": "挑一個例子，留下對「間隔」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          }
        ]
      },
      {
        "name": "觀察桌面",
        "description": "可從任何一個主題開始。",
        "goal": "選一個主題，記錄一次觀察。",
        "outcome": "一份可回看的練習紀錄。",
        "topics": [
          {
            "name": "杯口",
            "description": "挑一個例子，留下對「杯口」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "湯匙",
            "description": "挑一個例子，留下對「湯匙」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "紙盒",
            "description": "挑一個例子，留下對「紙盒」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "剪影",
            "description": "挑一個例子，留下對「剪影」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          }
        ]
      },
      {
        "name": "改變視角",
        "description": "可從任何一個主題開始。",
        "goal": "選一個主題，記錄一次觀察。",
        "outcome": "一份可回看的練習紀錄。",
        "topics": [
          {
            "name": "正面",
            "description": "挑一個例子，留下對「正面」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "側面",
            "description": "挑一個例子，留下對「側面」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "上方",
            "description": "挑一個例子，留下對「上方」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "下方",
            "description": "挑一個例子，留下對「下方」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          }
        ]
      },
      {
        "name": "畫一條街",
        "description": "可從任何一個主題開始。",
        "goal": "選一個主題，記錄一次觀察。",
        "outcome": "一份可回看的練習紀錄。",
        "topics": [
          {
            "name": "路牌",
            "description": "挑一個例子，留下對「路牌」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "門框",
            "description": "挑一個例子，留下對「門框」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "屋頂",
            "description": "挑一個例子，留下對「屋頂」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "窗戶",
            "description": "挑一個例子，留下對「窗戶」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "道路",
            "description": "挑一個例子，留下對「道路」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          },
          {
            "name": "遠山",
            "description": "挑一個例子，留下對「遠山」的觀察。",
            "goal": "練習描述一個具體細節。",
            "outcome": "一句練習筆記。"
          }
        ]
      }
    ]
  },
  "templates": [
    {
      "id": "english",
      "name": "英語練習",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份英語練習的練習筆記。"
    },
    {
      "id": "massage",
      "name": "按摩知識",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份按摩知識的練習筆記。"
    },
    {
      "id": "yijing",
      "name": "易經",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份易經的練習筆記。"
    },
    {
      "id": "ziwei",
      "name": "紫微斗數",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份紫微斗數的練習筆記。"
    },
    {
      "id": "qimen",
      "name": "奇門遁甲",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份奇門遁甲的練習筆記。"
    },
    {
      "id": "tarot",
      "name": "塔羅",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份塔羅的練習筆記。"
    },
    {
      "id": "lenormand",
      "name": "雷諾曼",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份雷諾曼的練習筆記。"
    },
    {
      "id": "psychology",
      "name": "心理學",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份心理學的練習筆記。"
    },
    {
      "id": "chinese-medicine",
      "name": "中醫",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份中醫的練習筆記。"
    }
  ],
  "routes": {
    "english": {
      "goal": "建立一份英語練習的練習筆記。",
      "stages": []
    },
    "massage": {
      "goal": "建立一份按摩知識的練習筆記。",
      "stages": [
        {
          "name": "入門觀察",
          "description": "可從任何一個主題開始。",
          "goal": "選一個主題，記錄一次觀察。",
          "outcome": "一份可回看的練習紀錄。",
          "topics": [
            {
              "name": "閱讀詞彙",
              "description": "挑一個例子，留下對「閱讀詞彙」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            },
            {
              "name": "描述一個例子",
              "description": "挑一個例子，留下對「描述一個例子」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            }
          ]
        }
      ]
    },
    "yijing": {
      "goal": "建立一份易經的練習筆記。",
      "stages": [
        {
          "name": "入門觀察",
          "description": "可從任何一個主題開始。",
          "goal": "選一個主題，記錄一次觀察。",
          "outcome": "一份可回看的練習紀錄。",
          "topics": [
            {
              "name": "閱讀詞彙",
              "description": "挑一個例子，留下對「閱讀詞彙」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            },
            {
              "name": "描述一個例子",
              "description": "挑一個例子，留下對「描述一個例子」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            }
          ]
        }
      ]
    },
    "ziwei": {
      "goal": "建立一份紫微斗數的練習筆記。",
      "stages": [
        {
          "name": "入門觀察",
          "description": "可從任何一個主題開始。",
          "goal": "選一個主題，記錄一次觀察。",
          "outcome": "一份可回看的練習紀錄。",
          "topics": [
            {
              "name": "閱讀詞彙",
              "description": "挑一個例子，留下對「閱讀詞彙」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            },
            {
              "name": "描述一個例子",
              "description": "挑一個例子，留下對「描述一個例子」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            }
          ]
        }
      ]
    },
    "qimen": {
      "goal": "建立一份奇門遁甲的練習筆記。",
      "stages": [
        {
          "name": "入門觀察",
          "description": "可從任何一個主題開始。",
          "goal": "選一個主題，記錄一次觀察。",
          "outcome": "一份可回看的練習紀錄。",
          "topics": [
            {
              "name": "閱讀詞彙",
              "description": "挑一個例子，留下對「閱讀詞彙」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            },
            {
              "name": "描述一個例子",
              "description": "挑一個例子，留下對「描述一個例子」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            }
          ]
        }
      ]
    },
    "cards": {
      "goal": "觀察卡牌圖案，練習描述。",
      "stages": [
        {
          "name": "塔羅",
          "description": "可從任何一個主題開始。",
          "goal": "選一個主題，記錄一次觀察。",
          "outcome": "一份可回看的練習紀錄。",
          "topics": [
            {
              "name": "圖案觀察",
              "description": "挑一個例子，留下對「圖案觀察」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            },
            {
              "name": "寫一句描述",
              "description": "挑一個例子，留下對「寫一句描述」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            }
          ]
        },
        {
          "name": "雷諾曼",
          "description": "可從任何一個主題開始。",
          "goal": "選一個主題，記錄一次觀察。",
          "outcome": "一份可回看的練習紀錄。",
          "topics": [
            {
              "name": "圖案觀察",
              "description": "挑一個例子，留下對「圖案觀察」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            },
            {
              "name": "寫一句描述",
              "description": "挑一個例子，留下對「寫一句描述」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            }
          ]
        }
      ]
    },
    "psychology": {
      "goal": "建立一份心理學的練習筆記。",
      "stages": [
        {
          "name": "入門觀察",
          "description": "可從任何一個主題開始。",
          "goal": "選一個主題，記錄一次觀察。",
          "outcome": "一份可回看的練習紀錄。",
          "topics": [
            {
              "name": "閱讀詞彙",
              "description": "挑一個例子，留下對「閱讀詞彙」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。",
              "readingNoteId": "demo-reading-a"
            },
            {
              "name": "描述一個例子",
              "description": "挑一個例子，留下對「描述一個例子」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            }
          ]
        }
      ]
    },
    "chinese-medicine": {
      "goal": "建立一份中醫的練習筆記。",
      "stages": [
        {
          "name": "入門觀察",
          "description": "可從任何一個主題開始。",
          "goal": "選一個主題，記錄一次觀察。",
          "outcome": "一份可回看的練習紀錄。",
          "topics": [
            {
              "name": "閱讀詞彙",
              "description": "挑一個例子，留下對「閱讀詞彙」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            },
            {
              "name": "描述一個例子",
              "description": "挑一個例子，留下對「描述一個例子」的觀察。",
            "goal": "練習描述一個具體細節。",
              "outcome": "一句練習筆記。"
            }
          ]
        }
      ]
    }
  },
  "items": [
    {
      "id": "english",
      "name": "英語練習",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份英語練習的練習筆記。"
    },
    {
      "id": "massage",
      "name": "按摩知識",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份按摩知識的練習筆記。"
    },
    {
      "id": "yijing",
      "name": "易經",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份易經的練習筆記。"
    },
    {
      "id": "ziwei",
      "name": "紫微斗數",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份紫微斗數的練習筆記。"
    },
    {
      "id": "qimen",
      "name": "奇門遁甲",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份奇門遁甲的練習筆記。"
    },
    {
      "id": "cards",
      "name": "塔羅及雷諾曼",
      "vision": "觀察卡牌圖案，練習描述。"
    },
    {
      "id": "psychology",
      "name": "心理學",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份心理學的練習筆記。"
    },
    {
      "id": "chinese-medicine",
      "name": "中醫",
      "description": "虛構的學習項目，用於記錄與回訪測試。",
      "vision": "建立一份中醫的練習筆記。"
    }
  ]
};
globalThis.MindCatalog = learningCatalog;
if (typeof module !== 'undefined' && module.exports) module.exports = learningCatalog;
