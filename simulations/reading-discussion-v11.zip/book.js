'use strict';
window.readingBook = {
  "book": "走一段陌生的路",
  "read": 1,
  "start": "",
  "opening": "出門之前",
  "source": "專供流程測試的原創虛構短篇",
  "record": "",
  "notes": [
    {
      "id": "demo-reading-a",
      "label": "擔心與準備",
      "excerpt": "他把行程表摺進口袋，重新看了一眼站牌，再決定要搭哪一班車。",
      "reflection": "示例讀者好奇：查一次時刻表和反覆檢查，有什麼可以觀察的差別？"
    },
    {
      "id": "demo-reading-b",
      "label": "選擇自己的路線",
      "excerpt": "兩條路都通到展場。他收起導覽圖，選了能直接看到河岸的那一條。",
      "reflection": "示例讀者想把地圖上的建議，和人物自己在意的事情分開來看。"
    }
  ]
};
