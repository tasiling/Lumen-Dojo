'use strict';
(function(root){
  const clips=root.ReadingClips;
  function create(api){
    const {el,div,para,hd,btn,label,details,mode,bookList,defaultBook,findNote,saveNote,openNote}=api;
    const urls=new Set();
    let unsubscribe=()=>{};
    function dispose(){
      unsubscribe();unsubscribe=()=>{};
      for(const url of urls)URL.revokeObjectURL(url);
      urls.clear();
    }
    async function showOriginal(id,target){
      try{
        const file=await clips.original(id);
        if(!target.isConnected)return;
        if(!file)throw Error();
        const url=URL.createObjectURL(file);urls.add(url);
        const img=el('img',{src:url,alt:'這個選段的原始閱讀頁面截圖',cls:'clip-image'});
        img.onerror=()=>target.replaceChildren(para('這台裝置無法顯示原圖，可在相簿開啟原檔核對。','small'));
        const full=el('dialog',{cls:'clip-zoom','aria-label':'原始書頁大圖'});
        const close=btn('關閉大圖',()=>full.close(),'secondary');
        const detail=el('img',{src:url,alt:'放大的原始書頁'});
        const scroll=div('clip-zoom-scroll',detail);
        const toggle=btn('查看原始尺寸',()=>{
          const zoom=scroll.classList.toggle('actual-size');
          toggle.textContent=zoom?'縮回整頁':'查看原始尺寸';
          toggle.setAttribute('aria-pressed',String(zoom));
        },'secondary',{'aria-pressed':'false'});
        full.append(div('clip-zoom-bar',toggle,close),scroll);
        target.replaceChildren(img,btn('放大原圖',()=>full.showModal(),'text-link'),full);
      }catch{if(target.isConnected)target.replaceChildren(para('原圖暫時無法讀取。','form-error'));}
    }
    function attachment(note){
      const target=div('clip-attachment',para(note.photoName||'原圖','small'));
      const fold=details('查看剪藏原圖',target);let loaded=false;
      fold.addEventListener('toggle',()=>{if(fold.open&&!loaded){loaded=true;void showOriginal(note.clipId,target);}});
      return fold;
    }
    function page(){
      const owner=mode();
      const file=el('input',{id:'clip-files',type:'file',accept:'image/*',multiple:true});
      const feed=el('p',{cls:'small',role:'status'}),err=el('p',{cls:'form-error',role:'alert'});
      const picker=div('panel clip-upload',label(file.id,'加入閱讀頁面截圖'),file,para('可一次選多張，原圖會留在這個瀏覽器。','small'),feed,err);
      const tabs=div('clip-list'),editor=div('clip-editor'),container=div('column-stack',picker,tabs,editor);
      let selected='',generation=0,visible=null,selectionVersion=0;
      const current=()=>container.isConnected&&mode()===owner;
      function fail(){err.textContent='裝置無法保存變更。請保留原圖和已輸入的文字，再試一次。';}
      async function list(prefer){
        const snapshot=++generation;
        let pages;
        try{pages=await clips.list(owner);}catch{fail();return;}
        if(!current()||snapshot!==generation)return;
        if(!pages.length){tabs.replaceChildren();editor.replaceChildren();return;}
        const waiting=pages.filter(p=>!findNote(p.id));
        const requested=(Array.isArray(prefer)?prefer:[prefer]).map(id=>pages.find(p=>p.id===id)).filter(Boolean);
        selected=(requested.find(p=>!findNote(p.id))||requested[0]||pages.find(p=>p.id===selected)||waiting[0]||pages.at(-1)).id;
        const pick=p=>btn(p.name||'閱讀截圖',()=>void list(p.id),'clip-choice',{'aria-pressed':String(p.id===selected)});
        const saved=pages.filter(p=>findNote(p.id));
        tabs.replaceChildren(div('panel stack-tight',hd(2,'待核對（'+waiting.length+'）'),
          waiting.length?div('clip-choices',waiting.map(pick)):para('這批截圖都已存成選段。','small'),
          saved.length?details('已存為選段（'+saved.length+'）',div('clip-choices',saved.map(pick))):null));
        display(pages.find(p=>p.id===selected),waiting);
        waiting.filter(p=>p.recognition==='new').forEach(p=>{void clips.recognize(p);});
      }
      function display(p,waiting){
        const version=++selectionVersion;
        for(const url of urls)URL.revokeObjectURL(url);
        urls.clear();visible=null;
        const old=findNote(p.id),image=div('clip-frame',para('正在打開原圖…','small'));
        const original=el('section',{cls:'panel stack-tight'},hd(2,'原始截圖'),para(p.name,'small'),image);
        if(old){
          editor.replaceChildren(div('clip-layout',original,div('panel stack',hd(2,'已存為閱讀選段'),para(old.bookTitle+' · '+old.label),
            btn('打開已保存的選段',()=>openNote(old),'primary'))));void showOriginal(p.id,image);return;
        }
        const dest=defaultBook(),titles=bookList();
        const books=el('datalist',{id:'clip-book-options'},[...new Set(titles.map(b=>b.book))].map(value=>el('option',{value})));
        const book=el('input',{id:'clip-book',type:'text',list:books.id,maxlength:180,value:p.bookEdited?p.bookTitle:p.bookTitle||dest?.book||'',placeholder:'選擇書架上的書，或輸入新書名'});
        const count=el('input',{id:'clip-read',type:'number',min:1,max:999,step:1,value:p.bookTitle?p.readNumber:(dest?.read||1)});
        const loc=el('input',{id:'clip-location',type:'text',maxlength:120,value:p.location||'',placeholder:'例如第 24 頁'});
        const title=el('input',{id:'clip-label',type:'text',maxlength:80,value:p.label||'',placeholder:'留白時使用摘錄的開頭'});
        const excerpt=el('textarea',{id:'clip-excerpt',rows:7,maxlength:40000}),reflection=el('textarea',{id:'clip-reflection',rows:3,maxlength:6000});
        excerpt.value=p.excerpt??p.ocr??'';reflection.value=p.reflection||'';
        let edited=p.excerpt!==undefined;
        const tracking=new Set();
        function persist(values){
          const write=clips.patch(p.id,values);tracking.add(write);
          write.catch(fail).finally(()=>tracking.delete(write));return write;
        }
        for(const [input,key] of [[book,'bookTitle'],[count,'readNumber'],[loc,'location'],[title,'label'],[excerpt,'excerpt'],[reflection,'reflection']]){
          input.addEventListener('input',()=>{
            if(input===excerpt)edited=true;
            const values={[key]:input.value};
            if(input===book||input===count)values.bookEdited=true;
            void persist(values);
          });
        }
        const status=el('p',{cls:'clip-status',role:'status'}),layout=el('select',{id:'clip-layout'},el('option',{value:'horizontal'},'橫排／一般版面'),el('option',{value:'vertical'},'中文直排'));
        layout.value=p.layout||'horizontal';
        const again=btn('重新辨識',()=>{void clips.recognize(p,layout.value);},'secondary');
        const use=btn('採用本次辨識文字',()=>{excerpt.value=p.ocr;edited=true;void persist({excerpt:p.ocr});use.hidden=true;},'ghost');
        function noteStatus(message){
          if(message){status.textContent=message;return;}
          status.textContent=p.recognition==='done'?(p.confidence<70?'已辨識，請特別核對模糊字。':'文字已辨識，請核對要留下的段落。'):
            p.recognition==='failed'?'這張圖未能完成辨識。可重試，或對照原圖貼入文字。':
            p.recognition==='empty'?'這張圖沒有辨識出文字。可切換直排重試，或對照原圖貼入文字。':'等待文字辨識…';
        }
        const update=async message=>{
          if(!current()||version!==selectionVersion)return;
          if(message){again.disabled=true;noteStatus(message);return;}
          const newer=await clips.readPage(p.id).catch(()=>null);
          if(!newer||!current()||version!==selectionVersion)return;
          p=newer;again.disabled=false;noteStatus('');
          if(!edited)excerpt.value=p.ocr||'';
          use.hidden=!edited||!p.ocr||excerpt.value===p.ocr;
        };
        visible={id:p.id,update};use.hidden=!edited||!p.ocr||excerpt.value===p.ocr;noteStatus('');
        const error=el('p',{role:'alert',cls:'form-error'});
        const nextPage=waiting.find(other=>other.id!==p.id&&other.batch===p.batch);
        const confirm=btn('核對並存為閱讀選段',()=>void submit(false),nextPage?'secondary':'primary');
        const next=nextPage?btn('存入並核對下一張',()=>void submit(true),'primary'):null;
        async function submit(continueBatch){
          if(confirm.disabled)return;confirm.disabled=true;if(next)next.disabled=true;error.textContent='';
          try{
            const draft={...p,bookTitle:book.value,readNumber:count.value,location:loc.value,label:title.value,excerpt:excerpt.value,reflection:reflection.value};
            const note=clips.makeNote(draft,owner);
            await Promise.all(tracking);
            await persist({bookTitle:note.bookTitle,readNumber:note.readNumber,bookEdited:true,label:title.value,location:note.location,excerpt:note.excerpt,reflection:note.reflection});
            await clips.setBatchBook(p,note);
            if(!current()||version!==selectionVersion)return;
            await saveNote(note,!continueBatch);
            if(continueBatch&&current()){feed.textContent='已存入《'+note.bookTitle+'》。請核對下一張截圖。';await list(nextPage.id);editor.scrollIntoView({block:'start'});}
          }catch(e){error.textContent=e?.message||'目前未能保存選段。';}
          finally{confirm.disabled=false;if(next)next.disabled=false;}
        }
        const form=el('section',{cls:'panel stack clip-form'},hd(2,'核對閱讀選段'),
          label(book.id,'書名'),book,books,div('clip-fields',div('stack-tight',label(count.id,'這是第幾讀？'),count),div('stack-tight',label(loc.id,'頁碼或位置（選填）'),loc)),
          label(excerpt.id,'作者原文'),status,excerpt,details('文字辨識選項',label(layout.id,'原圖排版'),layout,div('actions',again,use)),
          label(reflection.id,'我的心得（選填）'),reflection,details('替選段命名',label(title.id,'選段名稱'),title),error,div('actions clip-save',next,confirm));
        editor.replaceChildren(div('clip-layout',original,form));void showOriginal(p.id,image);
      }
      const onUpdate=event=>{if(visible?.id===event.detail.id)void visible.update(event.detail.status);};
      root.addEventListener('reading-clip-update',onUpdate);
      unsubscribe=()=>root.removeEventListener('reading-clip-update',onUpdate);
      file.addEventListener('change',async()=>{
        const files=Array.from(file.files||[]);if(!files.length)return;
        file.disabled=true;err.textContent='';const defaults=defaultBook()||{};
        const batchStart=Date.now(),batch=crypto.randomUUID(),ids=[];
        for(const [i,f] of files.entries()){
          try{
            if(f.type&&!f.type.startsWith('image/'))throw Error('請選擇圖片。');
            const page=await clips.keep(f,owner,defaults,batchStart+i,batch);ids.push(page.id);
          }catch(e){err.textContent='「'+f.name+'」未能保存。'+(e?.message||'請再試一次。');}
        }
        if(!current())return;
        file.disabled=false;file.value='';
        if(ids.length){feed.textContent='已讀取 '+ids.length+' 張截圖。相同原圖會回到原紀錄。';await list(ids);}
      });
      void list();return container;
    }
    return {page,attachment,dispose};
  }
  root.ReadingClipView={create};
})(globalThis);
