'use strict';
(function(root){
  const catalog=root.MindCatalog||(typeof require==='function'&&require('./learning-catalog.js'));
  const statuses=['進行中','暫時擱置','已完成','封存'];
  const seedItems=[
    {id:'english',name:'英文',icon:'subject-english',tools:[['語境修習室','/practice/context'],['VocabForge','/practice/vocabulary'],['寫作修習室','https://lumen-context-room-production-4a2c.up.railway.app/writing'],['日記自譯','/practice/journal'],['句型語法','/practice/grammar'],['英文主題練習','/practice/topic'],['英文節奏','/practice/rhythm']]},
    {id:'massage',name:'按摩',icon:'subject-massage'},
    {id:'writing',name:'書寫修習',icon:'type',tools:[['字型與連筆','/practice/handwriting']]}
  ];
  function init(db){
    db.mind||={};
    db.mind.demo||={};
    for(const space of [db.mind,db.mind.demo]){
      space.items??=seedItems.map(({id,name,icon})=>({id,name,icon,focus:false,steps:[],logs:[]}));
      if(!space.items.some(i=>i.id===catalog.drawing.id)){
        const {id,name,icon}=catalog.drawing;
        space.items.unshift({id,name,icon,focus:space===db.mind,steps:[],logs:[],status:'進行中'});
      }
      for(const i of space.items){
        i.status??='進行中';
        if(i.id==='english'&&i.name==='英文')i.name='英語練習';
        if(i.id==='massage'&&i.name==='按摩')i.name='按摩知識';
      }
      space.notes??=[];space.links??={};
    }
  }
  function day(offset=0){
    const now=new Date();now.setDate(now.getDate()+offset);
    return [now.getFullYear(),String(now.getMonth()+1).padStart(2,'0'),String(now.getDate()).padStart(2,'0')].join('-');
  }
  function pathFor(item){
    if(!item)return [];
    if(item.id===catalog.drawing.id)return catalog.drawing.stages;
    if(item.id==='tarot'||item.id==='lenormand')return catalog.routes.cards.stages.filter(stage=>stage.name===item.name);
    return catalog.routes[item.templateKey||item.id]?.stages||[];
  }
  function availableItems(state){
    const unstarted=catalog.items.filter(t=>!state.items.some(i=>i.id===t.id||i.templateKey===t.id));
    return [...state.items,...unstarted];
  }
  function index(db,mode){
    const records=root.ReadingReturns.sessions(db).filter(t=>t.mode===mode);
    const personal=mode==='demo'?db.mind?.demo:db.mind;
    const manual=(personal?.manualCards||[]).map(p=>({t:{mode,manual:true,noteId:p.noteId},p}));
    const saved=[...manual,...records.flatMap(t=>t.thread.products.map(p=>({t,p})))];
    const pending=records.filter(t=>t.thread.proposals.some(p=>p.status==='待選')||t.thread.rounds.some(r=>r.pending?.length));
    const count=t=>t.thread.proposals.filter(p=>p.status==='待選').length+t.thread.rounds.reduce((n,r)=>n+(r.pending?.length||0),0);
    const due=saved.filter(({p})=>p.review?.date&&p.review.date<=day());
    return {records,saved,pending,count,due};
  }
  function create(api){
    const {db,C,R,book,bookList,bookInfo,el,div,para,hd,btn,pill,details,label,selectControl,store,render,nav,flash,openNote,openThread,openProduct,goUp,parentLabel,syncRoute,openAdd}=api;
    const icon=(name)=>{
      const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg'),use=document.createElementNS(ns,'use');
      svg.setAttribute('class','ui-icon');svg.setAttribute('aria-hidden','true');svg.setAttribute('focusable','false');
      use.setAttribute('href','ui-icons.svg#i-'+name);svg.append(use);return svg;
    };
    const noteBy=id=>book.notes.find(n=>n.id===id);
    const current=()=>db().mode==='demo'?db().mind.demo:db().mind;
    const listing=()=>index(db(),db().mode);
    const noteTitle=t=>noteBy(t.noteId)?.label||'閱讀選段';
    const action=(text,go,cls='secondary')=>btn(text,go,cls);
    const row=(ico,title,desc,go,detail='')=>el('button',{type:'button',cls:'hub-row',onclick:go},div('entry-icon',icon(ico)),
      div('row-copy',el('b',{},title),desc?el('small',{},desc):null),detail?el('span',{cls:'row-detail'},detail):null,icon('arrow'));
    const section=(title,...content)=>el('section',{cls:'panel'},hd(2,title),...content);
    const formmsg=()=>el('p',{cls:'form-error',role:'alert'});
    const panelInfo=t=>para(t,'small');
    function write(message){store();render();if(message)flash(message);}
    function chosenItem(){return current().items.find(i=>i.id===current().item);}
    function openItem(item){current().itemTab='overview';current().item=item.id;current().resumeItem=item.id;nav('item');}
    function resumeInfo(){
      const mode=db().mode,shown=R.resume(db(),mode);
      if(shown){
        const draft=shown.kind==='draft';
        return {heading:'接著上次',title:noteTitle({noteId:shown.noteId}),
          label:draft?'核對回傳卡':'回到 GPT 討論',
          detail:draft?'回傳卡已貼上，核對並保存就能留下這輪問答。':shown.next?'下次從這裡　'+shown.next:'你選了下次接著談。可以帶走討論包，或貼回這輪問答。',
          go:()=>openThread(shown.target,'talk',draft),
          hide:()=>{R.dismiss(db(),mode,shown);delete current().resumeItem;write('已從首頁收起，可從閱讀筆記再開啟。');}};
      }
      const item=current().items.find(i=>i.id===current().resumeItem);
      if(item)return {heading:'接續學習',label:'接續這個項目',go:()=>openItem(item),title:item.name,detail:item.steps.find(s=>!s.done)?.text||'回到學習路徑與紀錄'};
      return {heading:'從閱讀開始',label:'打開書架',go:()=>nav('shelf'),title:'閱讀筆記',detail:'選一本書，從摘錄、心得或讀過的問題開始。'};
    }
    function hero(tab){
      const home=tab==='home',item=chosenItem();
      const readingTitle=bookInfo(noteBy(db().note)).book;
      const cfg={
        map:['行光道場','場域','選擇這次想進入的場域。','compass'],
        practice:['行光道場','修習所','從心・知進入學習項目、閱讀與回訪。','knowledge'],
        shelf:['修習所・心知','閱讀書架','選一本書，查看摘錄、心得與歷次討論。','book'],
        home:['知識與學習','修習所・心知','接續學習，從閱讀和對話留下自己的理解。','knowledge'],
        items:['修習所・心知','學習項目','挑選本期想專注的項目，再從自己的進度接續。','grid'],
        item:['學習項目',item?.name||'學習項目','學習路徑、修習工具和這個項目的紀錄。',item?.icon||'knowledge'],
        clip:['行光剪藏','心知閱讀截圖','選擇書頁截圖，對照原文後存入閱讀筆記。','book'],
        read:['閱讀書架','閱讀選段',readingTitle,'book'],
        talk:['閱讀筆記','GPT 討論',noteTitle({noteId:db().note})+' · '+readingTitle,'chat'],
        results:['閱讀筆記','討論成果',noteTitle({noteId:db().note})+' · '+readingTitle,'layers'],
        cards:['修習所・心知','心知卡片庫','回看你從閱讀或討論留下的觀點、洞察與原句。','layers'],
        visits:['卡片與回訪','今日回訪','回看當時想嘗試的事，記下這次的觀察。','history']
      }[tab];
      const practice=['home','items','item','map','practice'].includes(tab);
      const parent=parentLabel(),crumb=parent?el('button',{type:'button',cls:'crumb',onclick:goUp,'aria-label':'返回'+parent},icon('back'),parent):null;
      const art=div('hero-art');art.setAttribute('aria-hidden','true');
      if(practice)for(let i=0;i<4;i++)art.append(el('i',{}));
      const header=div('realm-hero '+(practice?'practice-hero':'reading-hero')+(home?' home-hero':''),
        art,div('hero-content',div('hero-symbol',icon(cfg[3])),el('h1',{id:'page-title',tabindex:'-1'},cfg[1]),para(cfg[2])));
      return div('page-head',crumb,header);
    }
    function home(){
      const list=listing(),next=resumeInfo(),focus=current().items.filter(i=>i.focus&&i.status==='進行中');
      const pending=list.pending.reduce((v,t)=>v+list.count(t),0);
      const resume=el('section',{cls:'panel resume-panel'},div('section-label',icon('book'),next.heading),hd(2,next.title),para(next.detail,'small'),div('actions',action(next.label,next.go,'primary'),next.hide?action('先收起來',next.hide,'ghost'):null));
      const queue=section('待處理',row('layers','待挑選的成果','從問答裡挑出值得留下的觀點',()=>{current().cardFilter='pending';nav('cards');},String(pending)),
        row('history','今日回訪','已到期的卡片與觀察',()=>nav('visits'),String(list.due.length)));
      const items=section('本期專注',focus.length?focus.map(i=>row(i.icon,i.name,i.steps.find(x=>!x.done)?.text||'查看學習項目',()=>openItem(i))):
        panelInfo('選一個這期想投入的學習項目，就能從這裡接續。'),hd(3,'全部學習項目'),itemGroups(),
        action('管理學習項目',()=>nav('items'),'text-link'));
      const entry=section('閱讀與內化',row('book','閱讀筆記','從書架選一本書',()=>nav('shelf')),
        row('layers','查看全部卡片','回看已確認的觀點、洞察卡與出處',()=>{current().cardFilter='saved';nav('cards');}));
      return div('hub-grid home-grid',resume,queue,items,entry);
    }
    function shelf(){
      return section('我的書架',bookList().map(b=>row('book',b.book,'第 '+b.read+' 次閱讀 · '+b.notes.length+' 個選段',
        ()=>openNote(b.notes.find(n=>n.id===db().note)||b.notes[0]))),
        row('layers','從行光剪藏加入截圖','核對原圖、選擇書籍與讀次',()=>nav('clip')));
    }
    function map(){
      return section('道場場域',row('knowledge','修習所','心・知與學習項目',()=>nav('practice')),
        el('a',{cls:'external-row',href:'https://lumen-dojo.up.railway.app/map',target:'_blank',rel:'noopener noreferrer'},'到正式版查看所有場域 ↗'));
    }
    function practice(){
      const logs=current().practiceLogs||[];
      return div('column-stack',section('修習入口',row('knowledge','心・知','學習項目、閱讀筆記與卡片',()=>nav('home'))),
        logs.length?section('修習紀錄',[...logs].map(l=>div('log-entry',el('small',{},l.date),para(l.text,'preserve')))):null);
    }
    function itemGroups(){
      const group=(title,nodes)=>div('stack-tight',el('small',{cls:'small'},title),div('item-chips',nodes));
      const chip=i=>action(i.name,()=>openItem(i),'item-chip');
      const state=current(), drawing=state.items.find(i=>i.id===catalog.drawing.id);
      const planned=catalog.items.map(t=>action(t.name,()=>{
        let item=state.items.find(i=>i.id===t.id||i.templateKey===t.id);
        if(!item){
          item={id:t.id,templateKey:t.id,name:t.name,icon:'knowledge',status:'進行中',focus:false,steps:[],logs:[]};
          state.items.push(item);
        }
        openItem(item);
      },'item-chip'));
      const other=state.items.filter(i=>i!==drawing&&!catalog.items.some(t=>t.id===i.id||t.id===i.templateKey));
      return div('stack-tight',group('示例已建立',[chip(drawing)]),group('本次模擬項目',planned),other.length?group('其他本機項目',other.map(chip)):null);
    }
    const external=(name,path)=>el('a',{cls:'external-row',href:path.startsWith('https://')?path:'https://lumen-dojo.up.railway.app'+path,target:'_blank',rel:'noopener noreferrer'},name+' ↗');
    function items(){
      const state=current(),nameInput=el('input',{id:'new-item-name',type:'text',maxlength:60,autocomplete:'off'}),err=formmsg();
      const add=details('新增學習項目',label(nameInput.id,'項目名稱'),nameInput,err,action('加入學習項目',()=>{
        const name=nameInput.value.trim();if(!name||state.items.some(i=>i.name===name)){err.textContent='請填寫一個尚未使用的項目名稱。';return;}
        const item={id:C.uid(),name,icon:'knowledge',status:'進行中',focus:false,steps:[],logs:[]};state.items.push(item);openItem(item);
      },'primary'));
      const focused=state.items.filter(i=>i.focus&&i.status==='進行中');
      return div('hub-grid',section('全部學習項目',itemGroups(),add),
        section('本期專注',focused.length?focused.map(i=>row(i.icon,i.name,i.status,()=>openItem(i))):panelInfo('可以在各項目的總覽選擇本期專注。'),
          external('查看正式版學習管理','/practice/manage')));
    }
    function learningPath(i){
      if(i.id==='english'&&!i.steps.length)return section('英文學習系統',para(catalog.routes.english.goal),itemTools(i));
      const stages=pathFor(i).map(stage=>
        details(stage.name+'（'+stage.topics.length+' 個主題）',stage.description?para(stage.description):null,stage.goal?div('learning-facts',hd(3,'學習目標'),para(stage.goal),hd(3,'預期成果'),para(stage.outcome)):null,
          stage.topics.map(t=>{
            const key=stage.name+'/'+t.name;
            const reading=noteBy(t.readingNoteId);
            const check=el('input',{type:'checkbox',checked:!!i.finishedTopics?.[key],onchange:e=>{
              i.finishedTopics||={};i.finishedTopics[key]=e.target.checked;store();check.closest('details').querySelector('summary').textContent=(e.target.checked?'✓ ':'')+t.name;
            }});
            return details((i.finishedTopics?.[key]?'✓ ':'')+t.name,para(t.description),t.goal?hd(3,'練習方向'):null,t.goal?para(t.goal):null,hd(3,'留下的成果'),para(t.outcome),
              el('label',{cls:'checkline step-row'},check,'已完成這個單元'),div('actions',
                reading?action('閱讀「'+reading.label+'」',()=>openNote(reading)):null,
                action('記錄這個練習',()=>openAdd({stage:stage.name,topic:t.name}))));})));
      const input=el('input',{type:'text',id:'step-text',maxlength:160}),err=formmsg();
      const steps=section('我的練習步驟',i.steps.map(s=>{
        const cb=el('input',{type:'checkbox',checked:s.done,onchange:e=>{s.done=e.target.checked;write();}});
        return el('label',{cls:'checkline step-row'},cb,s.text);
      }),details('新增一個步驟',label(input.id,'想做的下一步'),input,err,action('加入路徑',()=>{
        if(!input.value.trim()){err.textContent='請寫下步驟。';return;}
        i.steps.push({text:input.value.trim(),done:false});write('已加入路徑。');
      })));
      return div('column-stack',i.id==='english'?itemTools(i):null,stages.length?section('階段與主題',panelInfo('依需要挑選練習，可以直接展開任何階段。'),...stages):null,steps);
    }
    function itemTools(i){
      const extra=seedItems.find(s=>s.id===i.id)?.tools||[];
      const tools=section('修習工具',row('book','閱讀筆記','進入共用書架',()=>nav('shelf')),external('野採素材','/forage'),
        extra.map(([name,path])=>external(name,path)),action('留下學習紀錄',()=>openAdd()));
      tools.id='item-tools';
      const routeNotes=pathFor(i).flatMap(stage=>stage.topics.map(topic=>topic.readingNoteId).filter(Boolean));
      const related=book.notes.filter(n=>(!n.local||n.owner===db().mode)&&(current().links[n.id]===i.id||routeNotes.includes(n.id)));
      if(related.length)tools.append(hd(3,'相關閱讀選段'),...related.map(n=>row('book',n.label,bookInfo(n).book,()=>openNote(n))));
      return tools;
    }
    function overview(i){
      const drawing=i.id===catalog.drawing.id,info=drawing?catalog.drawing:catalog.items.find(t=>t.id===i.id||t.id===i.templateKey)||catalog.templates.find(t=>t.id===i.id)||{};
      const defaults={...info,goal:info.goal||catalog.routes[i.id]?.goal,outcome:info.outcome||pathFor(i)[0]?.topics[0]?.outcome};
      const fields=[['vision','長期方向'],['goal','學習目標'],['outcome','示例成果']].filter(([key])=>key!=='outcome'||i.id!=='english'||i.outcome);
      const form=fields.map(([key,title])=>{
        const id='edit-'+key,input=el('textarea',{id,rows:2,maxlength:2400});input.value=i[key]??defaults[key]??'';
        return {key,input,node:div('stack-tight',label(id,title),input)};
      });
      const status=selectControl('item-status',statuses.map(x=>[x,x]),i.status,v=>{i.status=v;if(v!=='進行中')i.focus=false;write('已更新本機項目狀態。');});
      return div('column-stack',section(i.name+'的學習方向',fields.map(([k,l])=>div('learning-facts',hd(3,l),para((i[k]??defaults[k])||'尚未指定'))),
        info.description?details('項目說明與來源',para(info.description,'preserve')):null,
        action('開始修習・留下紀錄',()=>openAdd(),'primary')),
        section('項目設定',div('actions',btn(i.focus?'移出本期專注':'加入本期專注',()=>{i.focus=!i.focus;write('已更新本期專注。');},'secondary',{disabled:i.status!=='進行中'})),
          i.status!=='進行中'?panelInfo('將狀態設為進行中，即可加入本期專注。'):null,
          label(status.id,'項目狀態'),status,details('編輯本機學習方向',form.map(f=>f.node),action('保存學習方向',()=>{for(const f of form)i[f.key]=f.input.value.trim();write('已保存本機學習方向。');}))));
    }
    function logsFor(i){
      return section('學習紀錄',action('留下學習紀錄',()=>openAdd(),'primary'),
        i.logs.length?i.logs.map(l=>div('log-entry',el('small',{},[l.date,l.stage,l.topic].filter(Boolean).join(' · ')),para(l.text,'preserve'))):panelInfo('這台裝置還沒有這個項目的修習紀錄。'),
        i.id===catalog.drawing.id?external('查看正式版學習紀錄','/practice/records'):null);
    }
    function item(){
      const i=chosenItem();if(!i)return items();
      const tab=current().itemTab||'overview',entries=[['overview','總覽',overview],['path','學習路徑',learningPath],['tools','修習工具',itemTools],['logs','學習紀錄',logsFor]];
      const strip=el('nav',{cls:'work-tabs item-tabs','aria-label':'學習項目分頁'},entries.map(([key,title])=>btn(title,()=>{
        current().itemTab=key;write();syncRoute(true);
        document.querySelector('.item-tabs [aria-current="page"]')?.focus({preventScroll:true});
      },'ghost',{'aria-current':key===tab?'page':null})));
      return div('column-stack',strip,(entries.find(([k])=>k===tab)||entries[0])[2](i));
    }
    function tabs(view){
      return el('nav',{cls:'work-tabs', 'aria-label':'卡片與回訪分頁'},['cards','visits'].map((k,i)=>el('a',{href:'#'+k,'aria-current':k===view?'page':null},['卡片庫','今日回訪'][i])));
    }
    function schedule(t,p){
      const id='visit-'+C.uid(),date=el('input',{type:'date',id,value:p.review?.date||day()}),err=formmsg();
      return details(p.review?.date?'調整回訪日期':'安排回訪',label(id,'回訪日期'),date,err,action('保存回訪日期',()=>{
        if(!date.value||!date.validity.valid){err.textContent='請選擇有效日期。';return;}
        p.review||={history:[]};p.review.date=date.value;write('已安排在 '+date.value+' 回訪。');
      },'secondary'));
    }
    function savedCard(t,p){
      return el('article',{cls:'panel insight-tile'},div('eyeline',pill(p.type),el('span',{cls:'small'},noteTitle(t))),hd(3,p.text),
        p.action?para(p.action,'small'):null,div('actions',action('回看來源與取用',()=>openProduct(t,p),'text-link')),
        schedule(t,p),p.review?.date?panelInfo('已安排 '+p.review.date+' 回訪'):null);
    }
    function cards(){
      const data=listing(),state=current(),filter=state.cardFilter||'saved';
      const pending=data.pending.reduce((n,t)=>n+data.count(t),0);
      const filterBar=div('filter-row', [['saved','已確認',data.saved.length],['pending','待挑選',pending]].map(([k,l,n])=>btn(l+'（'+n+'）',()=>{state.cardFilter=k;write();},'filter',{'aria-pressed':String(k===filter)})));
      const body=filter==='pending'?data.pending.map(t=>row('chat',noteTitle(t),data.count(t)+' 筆待挑選或待核對',()=>openThread(t,'results'))):data.saved.map(({t,p})=>savedCard(t,p));
      const empty=filter==='pending'?'目前沒有待挑選的成果':'這裡會收錄你確認留下的觀點與洞察卡';
      return div('column-stack',tabs('cards'),filterBar,body.length?div(filter==='saved'?'cards-grid':'panel',body):section(empty,panelInfo(filter==='pending'?'貼回完成卡後，可以在這裡挑選。':'閱讀時可從選段的「更多」手動留卡，也能在討論結束後挑選成果。'),filter==='pending'?action('查看本段討論成果',()=>nav('results')):action('打開閱讀筆記',()=>nav('shelf'))));
    }
    function visitForm(t,p){
      const id='obs-'+C.uid(),obs=el('textarea',{id,rows:2,maxlength:4000}),err=formmsg();
      return el('article',{cls:'panel visit-tile'},div('eyeline',pill(p.type),el('small',{},p.review.date)),hd(3,p.text),p.action?para(p.action,'alt'):null,
        label(id,'這次有什麼觀察？'),obs,err,div('actions',action('保存這次回訪',()=>{
          if(!obs.value.trim()){err.textContent='先寫下一句這次的觀察。';return;}
          p.review.history.push({date:day(),text:obs.value.trim()});p.review.date='';write('回訪觀察已保存。');
        },'primary'),action('順延到明天',()=>{p.review.date=day(1);write('已順延到明天。');})),action('回看來源',()=>openProduct(t,p),'text-link'));
    }
    function visits(){
      const {saved,due}=listing();
      const later=saved.filter(({p})=>p.review?.date>day()).sort((a,b)=>a.p.review.date.localeCompare(b.p.review.date));
      const logs=saved.flatMap(({t,p})=>(p.review?.history||[]).map(h=>({t,p,h}))).sort((a,b)=>b.h.date.localeCompare(a.h.date));
      return div('column-stack',tabs('visits'),div('hub-grid',div('column-stack',section('今天與已到期',due.length?panelInfo(due.length+' 張卡可以回訪。'):panelInfo('今天沒有到期的卡。你可以到卡片庫替一張已確認的卡安排日期。'),!due.length?action('到卡片庫安排',()=>{current().cardFilter='saved';nav('cards');}):null),due.map(({t,p})=>visitForm(t,p))),
        div('column-stack',section('接下來的回訪',later.length?later.map(({t,p})=>div('log-entry',el('small',{},p.review.date),hd(3,p.text),schedule(t,p))):panelInfo('目前沒有排在未來的回訪。')),
          section('已留下的觀察',logs.length?logs.map(({t,p,h})=>div('log-entry',el('small',{},h.date+' · '+noteTitle(t)),para(h.text,'preserve'),action('回看原卡',()=>openProduct(t,p),'text-link'))):panelInfo('完成回訪後，可以在這裡找回當時的觀察。')))));
    }
    return {home,items,item,cards,visits,hero,schedule,shelf,map,practice};
  }
  root.MindHub={init,create,index,day,pathFor,availableItems};
  if(typeof module!=='undefined'&&module.exports)module.exports=root.MindHub;
})(globalThis);
