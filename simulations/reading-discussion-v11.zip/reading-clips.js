'use strict';
(function(root){
  const cleanTitle=value=>String(value||'').trim().replace(/\s+/g,' ').normalize('NFC');
  function readingText(value){
    return value.trim().replace(/([\p{Script=Han}，。！？；：「」『』、（）《》〈〉])[ \t]+(?=[\p{Script=Han}，。！？；：「」『』、（）《》〈〉])/gu,'$1');
  }
  function bookInfo(note,reference){
    const title=cleanTitle(note?.bookTitle)||reference.book;
    const read=Number(note?.readNumber)||reference.read;
    const original=title===reference.book&&read===reference.read;
    return {book:title,read,key:JSON.stringify([title,read]),original,
      start:original?reference.start:'',opening:original?reference.opening:'',
      source:note?.clipId?'行光剪藏・閱讀截圖':original?reference.source:'我的閱讀筆記'};
  }
  function makeNote(photo,owner){
    const title=cleanTitle(photo.bookTitle),read=Number(photo.readNumber);
    const excerpt=(photo.excerpt??photo.ocr??'').trim(),reflection=(photo.reflection||'').trim();
    if(!title)throw Error('請選擇或輸入這次閱讀的書名。');
    if(!Number.isSafeInteger(read)||read<1||read>999)throw Error('讀次請填 1 到 999 之間的整數。');
    if(!excerpt)throw Error('請對照原圖，留下要保存的作者原文。');
    return {id:'clip-note-'+photo.id,owner,local:true,clipId:photo.id,photoName:photo.name,
      bookTitle:title,readNumber:read,location:(photo.location||'').trim(),
      label:cleanTitle(photo.label)||Array.from(excerpt.replace(/\s+/g,' ')).slice(0,25).join(''),
      excerpt,reflection};
  }
  function manualCard(note,input,uid){
    const text=(input.text||'').trim(),action=(input.action||'').trim();
    if(!['觀點','洞察卡'].includes(input.type)||!text)throw Error('先用自己的話寫下想留下的內容。');
    if(input.type==='洞察卡'&&!action)throw Error('請補上一件想觀察或實際執行的事。');
    return {id:uid,noteId:note.id,method:'manual',type:input.type,text,action:input.type==='洞察卡'?action:'',
      origin:'本人',originLabel:note.excerpt?'作者原文':'原筆記・我的心得',quote:note.excerpt||note.reflection,
      status:'本人已確認',share:false,version:1,uses:[]};
  }
  let connection;
  function database(){
    if(!connection)connection=new Promise((resolve,reject)=>{
      const req=indexedDB.open('lumen.xinzhi.reading.public-demo.v11.originals',1);
      req.onupgradeneeded=()=>{
        req.result.createObjectStore('pages',{keyPath:'id'});
        req.result.createObjectStore('originals');
      };
      req.onsuccess=()=>{const db=req.result;db.onversionchange=()=>{db.close();connection=null;};resolve(db);};
      req.onerror=()=>{connection=null;reject(req.error);};
    });
    return connection;
  }
  async function read(store,key){
    const db=await database();
    return new Promise((resolve,reject)=>{
      const table=db.transaction(store).objectStore(store);
      const req=key===undefined?table.getAll():table.get(key);
      req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
    });
  }
  async function change(id,update,original){
    const db=await database();
    return new Promise((resolve,reject)=>{
      const tr=db.transaction(original?['pages','originals']:['pages'],'readwrite'),pages=tr.objectStore('pages');
      let result;
      tr.oncomplete=()=>resolve(result);
      tr.onabort=()=>reject(tr.error||Error('裝置無法保存截圖，請確認儲存空間。'));
      const req=pages.get(id);
      req.onsuccess=()=>{
        const was=req.result;
        if(!was&&!original){tr.abort();return;}
        result=update(was);
        if(result!==was)pages.put(result);
        if(original&&!was)tr.objectStore('originals').put(original,id);
      };
    });
  }
  async function keep(file,owner,defaults,order,batch){
    const buffer=await file.arrayBuffer();
    const hash=await crypto.subtle.digest('SHA-256',buffer);
    const id=owner+'-'+Array.from(new Uint8Array(hash),n=>n.toString(16).padStart(2,'0')).join('');
    return change(id,existing=>existing||{id,owner,name:file.name,order,batch,bookEdited:false,bookTitle:defaults.book||'',
      readNumber:defaults.read||1,layout:'horizontal',recognition:'new',ocr:'',confidence:null},file);
  }
  const list=async owner=>(await read('pages')).filter(x=>x.owner===owner).sort((a,b)=>a.order-b.order);
  const patch=(id,values)=>change(id,page=>({...page,...values}));
  const original=id=>read('originals',id);
  async function setBatchBook(source,note){
    if(!source.batch)return;
    const siblings=(await list(source.owner)).filter(p=>p.batch===source.batch&&p.id!==source.id&&!p.bookEdited);
    await Promise.all(siblings.map(p=>change(p.id,current=>current.bookEdited?current:
      {...current,bookTitle:note.bookTitle,readNumber:note.readNumber})));
  }
  let scriptLoading;
  function engine(){
    if(root.Tesseract)return Promise.resolve(root.Tesseract);
    if(!scriptLoading)scriptLoading=new Promise((resolve,reject)=>{
      const script=document.createElement('script');script.src='ocr/tesseract.min.js';
      script.onload=()=>resolve(root.Tesseract);
      script.onerror=()=>{script.remove();scriptLoading=null;reject(Error('文字辨識未能載入。'));};
      document.head.append(script);
    });
    return scriptLoading;
  }
  async function pixels(blob){
    const url=URL.createObjectURL(blob),img=new Image();
    try{
      img.src=url;await img.decode();
      const scale=Math.min(1,3200/Math.max(img.naturalWidth,img.naturalHeight));
      const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
      const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
      return canvas;
    }finally{URL.revokeObjectURL(url);}
  }
  const tasks=new Map();
  let running=false;
  function emit(id,status){root.dispatchEvent(new CustomEvent('reading-clip-update',{detail:{id,status}}));}
  async function processTasks(){
    if(running)return;
    running=true;let worker,language='',activeId='';
    try{
      while(tasks.size){
        const [key,task]=tasks.entries().next().value;activeId=task.id;
        try{
          emit(activeId,'正在載入文字辨識…');
          const T=await engine(),langs=task.layout==='vertical'?'chi_tra_vert':'chi_tra';
          const base=new URL('ocr/',document.baseURI).href;
          if(!worker){
            worker=await new Promise((resolve,reject)=>{
              T.createWorker(langs,1,{workerPath:base+'worker.min.js',corePath:base+'tesseract-core-lstm.wasm.js',
                langPath:base,workerBlobURL:false,errorHandler:reject,
                logger:m=>{if(m.status==='recognizing text')emit(activeId,'正在辨識 '+Math.round(m.progress*100)+'%');}
              }).then(resolve,reject);
            });
          }else if(language!==langs)await worker.reinitialize(langs,1);
          language=langs;
          const blob=await original(activeId);if(!blob)throw Error('找不到這張原圖。');
          const canvas=await pixels(blob);
          let data;
          try{
            await worker.setParameters({tessedit_pageseg_mode:task.layout==='vertical'?'5':'3',user_defined_dpi:'300'});
            ({data}=await worker.recognize(canvas));
          }finally{canvas.width=canvas.height=1;}
          const text=readingText(data.text);
          await patch(activeId,{layout:task.layout,ocr:text,confidence:data.confidence,recognition:text?'done':'empty'});
        }catch{
          if(worker){try{await worker.terminate();}catch{}worker=null;language='';}
          try{await patch(activeId,{layout:task.layout,recognition:'failed'});}catch{}
        }finally{
          tasks.delete(key);emit(activeId,'');task.resolve();
        }
      }
    }finally{
      running=false;if(worker){try{await worker.terminate();}catch{}}
    }
  }
  function recognize(page,layout=page.layout||'horizontal'){
    const key=page.id+'/'+layout;
    if(tasks.has(key))return tasks.get(key).promise;
    let resolve;const promise=new Promise(done=>{resolve=done;});
    tasks.set(key,{id:page.id,layout,resolve,promise});void processTasks();return promise;
  }
  const api={bookInfo,makeNote,manualCard,readingText,keep,list,patch,setBatchBook,original,recognize,readPage:id=>read('pages',id)};
  root.ReadingClips=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(globalThis);
