import { createHash } from 'node:crypto';
import { mkdir, copyFile, writeFile, readFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { gzipSync } from 'node:zlib';

const target = join(dirname(fileURLToPath(import.meta.url)), 'ocr');
const modules = resolve('node_modules');
const revision = '87416418657359cb625c412a48b6e1d6d41c29bd';
const hashes = {
  chi_tra: '529c5b5797d64b126065cd55f2bb4c7fd7b15790798091b1ff259941a829330b',
  chi_tra_vert: '1df02a4b210e5c217b783819538b63e9dfe6904e2b5e53b62664f1b9f7a989d0',
};

await mkdir(target, { recursive: true });
for (const packageName of ['tesseract.js', 'tesseract.js-core']) {
  const info = JSON.parse(await readFile(join(modules, packageName, 'package.json'), 'utf8'));
  if (info.version !== '7.0.0') throw new Error('需要 ' + packageName + ' 7.0.0');
}
for (const name of ['tesseract.min.js', 'worker.min.js', 'tesseract.min.js.LICENSE.txt', 'worker.min.js.LICENSE.txt']) {
  await copyFile(join(modules, 'tesseract.js/dist', name), join(target, name));
}
await copyFile(join(modules, 'tesseract.js/LICENSE.md'), join(target, 'LICENSE.txt'));
await copyFile(join(modules, 'tesseract.js-core/LICENSE'), join(target, 'core-LICENSE.txt'));
await copyFile(join(modules, 'tesseract.js-core/tesseract-core-lstm.wasm.js'), join(target, 'tesseract-core-lstm.wasm.js'));

// The trial uses the smaller tessdata_fast models for horizontal and vertical text.
for (const [name, expected] of Object.entries(hashes)) {
  const file = name + '.traineddata';
  const url = 'https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/' + revision + '/' + file;
  const response = await fetch(url);
  if (!response.ok) throw new Error('無法下載 ' + file + '（HTTP ' + response.status + '）');
  const data = Buffer.from(await response.arrayBuffer());
  if (createHash('sha256').update(data).digest('hex') !== expected) throw new Error(file + ' 校驗失敗');
  await writeFile(join(target, file + '.gz'), gzipSync(data));
}
await writeFile(join(target, 'NOTICE.txt'), [
  'Tesseract.js and Tesseract.js-core 7.0.0: https://github.com/naptha/tesseract.js and https://github.com/naptha/tesseract.js-core',
  'Traditional Chinese horizontal and vertical models: https://github.com/tesseract-ocr/tessdata_fast/tree/' + revision,
  'Apache License 2.0. See accompanying licenses and notices.',
].join('\n') + '\n');
