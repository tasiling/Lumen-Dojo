'use strict';
(function(root){
  const C=root.ReadingTrial;
  const baseKey=(mode,noteId,scope)=>[mode,noteId,scope].join('|');
  function sessions(db){
    return Object.entries(db.sessions).map(([key,thread])=>{
      const [mode,noteId,scope]=key.split('|');
      return {key,mode,noteId,scope,thread};
    });
  }
  function activeKey(db,mode,noteId,scope){
    const base=baseKey(mode,noteId,scope),selected=db.activeSessions?.[base];
    return selected&&db.sessions[selected]?selected:base;
  }
  function select(db,target){
    const base=baseKey(target.mode,target.noteId,target.scope);
    db.activeSessions||={};db.activeSessions[base]=target.key;
    db.note=target.noteId;db.scopes[target.noteId]=target.scope;db.mode=target.mode;
  }
  function isBuiltIn(data,note){
    if(data.內建示例===true)return true;
    if(!['暫存','完成'].includes(data.狀態)||!Array.isArray(data.問答))return false;
    // Older example cards have no marker. Only recognize the supplied dialogue.
    const sample={pack:{id:'sample'},rounds:[]};
    for(const rounds of [[],[{next:data.問答[0]?.內容}]]){
      sample.rounds=rounds;
      const turns=JSON.parse(C.exampleCard(sample,note,'both',data.狀態)).問答;
      if(turns.length===data.問答.length&&turns.every((t,i)=>t.角色===data.問答[i]?.角色&&t.內容===data.問答[i]?.內容))return true;
    }
    return false;
  }
  function locate(db,notes,raw){
    const d=C.readReturn(raw);
    const note=notes.find(n=>n.id===d.選段ID);
    if(!note)throw Error('這張卡的選段不在這本測試筆記裡。請核對原討論包上的選段ID。');
    const entries=sessions(db),belongs=s=>s.thread.id===d.討論ID&&s.noteId===note.id;
    const hasPack=s=>s.thread.pack?.id===d.討論包ID||s.thread.rounds.some(r=>r.packId===d.討論包ID);
    if(entries.some(s=>(s.thread.id===d.討論ID&&s.noteId!==note.id)||(hasPack(s)&&!belongs(s))))
      throw Error('卡上的討論、討論包與選段指向不同紀錄。請讓原對話核對三個識別碼。');
    const related=entries.filter(belongs),exact=related.filter(hasPack);
    const sample=isBuiltIn(d,note);
    const mine=exact.find(s=>s.mode==='my'),demo=exact.find(s=>s.mode==='demo');
    const known=sample?demo:(mine||demo);
    const recordedScope=Object.hasOwn(C.scopes,d.帶入範圍)?d.帶入範圍:null;
    if(known&&recordedScope&&known.scope!==recordedScope)throw Error('卡上的帶入範圍和原討論包不同，請核對原討論包。');
    const scope=known?.scope||recordedScope||related[0]?.scope||null;
    return {d,note,sample,known,scope,chooseOwner:!!(known?.mode==='demo'&&!sample)};
  }
  function destination(plan,mode,scope){
    const {d,note,sample,known}=plan;
    if(sample&&mode!=='demo')throw Error('這張內建示例卡只會存入示例區。');
    if(!['my','demo'].includes(mode)||!Object.hasOwn(C.scopes,scope))throw Error('請先選擇原討論包使用的範圍。');
    if(plan.scope&&plan.scope!==scope)throw Error('選取的範圍與原討論包不同。');
    if(known?.mode===mode)return known;
    if(known&&!plan.chooseOwner)throw Error('請回到這張卡所屬的討論。');
    const key=[baseKey(mode,note.id,scope),d.討論ID,d.討論包ID].join('|');
    const thread=C.newThread(d.討論ID);
    thread.pack={id:d.討論包ID,sequence:1,starter:'gpt',question:'',scope};
    thread.recovered=true;
    return {key,mode,noteId:note.id,scope,thread};
  }
  function savedRound(target,packId){return target.thread.rounds.find(r=>r.packId===packId);}
  // One home shortcut per workspace. Reading history and the results queue are independent.
  function entry(db,key){
    if(!db.sessions[key])return null;
    const [mode,noteId,scope]=key.split('|');
    return {key,mode,noteId,scope,thread:db.sessions[key]};
  }
  function slots(db){return db.discussionResume??={my:null,demo:null};}
  function validPause(thread){
    const last=thread.rounds.at(-1);
    return last?.status==='暫存'&&(!thread.pack||thread.pack.id===last.packId)?last:null;
  }
  function pin(db,key){
    const t=entry(db,key);if(!t)return false;
    const paused=validPause(t.thread),packId=paused?.packId||t.thread.pack?.id;
    if(!packId||(!paused&&savedRound(t,packId)))return false;
    slots(db)[t.mode]={key,noteId:t.noteId,threadId:t.thread.id,packId,kind:paused?'paused':'planned'};
    return true;
  }
  function resume(db,mode){
    const p=db.discussionResume?.[mode];if(!p)return null;
    const target=entry(db,p.key);if(!target)return null;
    const thread=target.thread;
    if(p.kind==='draft'){
      try{
        const d=C.readReturn(thread.raw);
        if(d.討論ID!==p.threadId||d.討論包ID!==p.packId||d.選段ID!==p.noteId)return null;
      }catch{return null;}
      return {...p,target};
    }
    if(thread.id!==p.threadId)return null;
    const paused=validPause(thread);
    if(p.kind==='paused'&&paused?.packId===p.packId)return {...p,target,next:paused.next};
    if(p.kind==='planned'&&thread.pack?.id===p.packId&&!savedRound(target,p.packId)){
      const previous=thread.rounds.at(-1);
      return {...p,target,next:thread.pack.question||(previous?.status==='暫存'?previous.next:'')};
    }
    return null;
  }
  function dismiss(db,mode,shown){
    const p=db.discussionResume?.[mode];
    if(p&&shown&&p.key===shown.key&&p.packId===shown.packId&&p.kind===shown.kind)db.discussionResume[mode]=null;
  }
  function trackDraft(db,notes,key){
    const source=entry(db,key);if(!source)return false;
    let draft=null,owner;
    if(source.thread.raw?.includes('}')){
      try{
        const plan=locate(db,notes,source.thread.raw);
        owner=plan.sample?'demo':plan.known&&!plan.chooseOwner?plan.known.mode:source.mode;
        const sc=plan.scope||'unknown',target=destination(plan,owner,sc);
        C.check(source.thread.raw,target.thread,plan.note,sc);
        draft={key,noteId:plan.note.id,threadId:plan.d.討論ID,packId:plan.d.討論包ID,kind:'draft'};
      }catch{/* Incomplete or already saved cards stay in the editor. */}
    }
    const homes=slots(db);
    for(const [mode,p] of Object.entries(homes)){
      if(p?.key===key&&p.kind==='draft'&&(!draft||mode!==owner))homes[mode]=null;
    }
    if(draft)homes[owner]=draft;
    return !!draft;
  }
  function initResume(db,notes){
    if(db.discussionResume)return;
    slots(db);
    const key=activeKey(db,db.mode,db.note,db.scopes[db.note]||'both'),t=entry(db,key);
    if(!t||trackDraft(db,notes,key))return;
    if(validPause(t.thread))pin(db,key);
  }
  function dismissSaved(db,target,sourceKey,card,sample){
    for(const [mode,p] of Object.entries(slots(db))){
      if(!p||p.threadId!==target.thread.id||p.packId!==card.packId||p.noteId!==target.noteId)continue;
      if(mode===target.mode||(!sample&&p.kind==='draft'&&p.key===sourceKey))db.discussionResume[mode]=null;
    }
    if(card.status==='暫存')pin(db,target.key);
  }
  function save(db,notes,raw,sourceKey,mode,scope){
    const plan=locate(db,notes,raw),target=destination(plan,mode,scope);
    if(savedRound(target,plan.d.討論包ID))throw Error('這一輪已經保存，可以回看原紀錄。');
    const card=C.commit(raw,target.thread,plan.note,scope);
    db.sessions[target.key]=target.thread;
    if(db.sessions[sourceKey]?.raw===raw)db.sessions[sourceKey].raw='';
    dismissSaved(db,target,sourceKey,card,plan.sample);
    select(db,target);db.tab=card.status==='暫存'?'talk':'results';
    return card;
  }
  root.ReadingReturns={baseKey,sessions,activeKey,select,isBuiltIn,locate,destination,savedRound,initResume,pin,resume,dismiss,trackDraft,save};
  if(typeof module!=='undefined'&&module.exports)module.exports=root.ReadingReturns;
})(globalThis);
