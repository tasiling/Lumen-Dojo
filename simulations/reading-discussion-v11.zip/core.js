'use strict';
(function (root) {
  const format = '心知閱讀討論/v1';
  const scopes = {both:'原文和我的想法', excerpt:'只帶原文', reflection:'只帶我的想法', unknown:'只核對本輪問答（原範圍未記錄）'};
  const convergenceGuide = [
    '每次我說完，先回到這輪想釐清的問題。從整輪本人已說過的話判斷。當我已用自己的話回答，而且給過一個理由、例子、區別、適用界線或尚待查證之處，就主動收斂。這些線索擇一就夠，依內容判斷，不數輪次。書摘、你提出的例子和我簡短附和的話，單獨都不足以代表我的理解。',
    '若我還有直接影響原問題的疑問，先接住它，一次只補一個關鍵點。若下一問只會重複我已說過的內容、討另一個相似例子，或打開我沒要求的新題，就停下追問。就算還沒有定論，也可以小結已經釐清的部分，標出我仍拿不準的那一點。',
    '收斂的那一則回覆用一兩句話說清我對原問題的看法，盡量保留我的用詞和經驗範圍。必要時補一句仍待釐清的地方。接著只問「這輪可以整理成完成卡嗎？」並等我回應。此時不加新問題、不要求行動計畫，也先不輸出回傳卡。',
    '若我回應這個收尾提議說「好」「可以整理」或其他明確同意，直接依本輪原格式產生完成卡。若我修正意思，先採用我的修正。若我說還想談，就接著我指定的那一點聊，等理解有新的進展再提收尾。我隨時主動說「整理這次討論」或「先暫存」時，直接給相應的卡，不必再問。'
  ].join('\n\n');
  const convergenceUpdate = [
    '請把以下收斂方式加入我們正在進行的心知閱讀討論。沿用這段對話原有的討論包識別與回傳格式。',
    convergenceGuide,
    '請現在就根據我在這輪已說過的話作出下一則回覆。已經可以收斂就直接小結，還有關鍵疑問才續談。'
  ].join('\n\n');
  function uid() {
    if (globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function') return globalThis.crypto.randomUUID();
    return 'rd-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
  }
  function newThread(id=uid()) {
    return {id,starter:'gpt',question:'',pack:null,raw:'',rounds:[],proposals:[],products:[]};
  }
  function newPacket(thread) {
    if (thread.pack && !thread.rounds.some(r => r.packId === thread.pack.id)) return thread.pack;
    thread.pack = {id:uid(), sequence:thread.rounds.length+1, starter:thread.starter, question:thread.question.trim()};
    return thread.pack;
  }
  function sourceAnchors(note, scope) {
    const a = {};
    if (note.excerpt&&(scope==='both'||scope==='excerpt')) a.S = {label:'作者原文',text:note.excerpt,role:'作者'};
    if (note.reflection&&(scope==='both'||scope==='reflection')) a.N = {label:'原筆記・我的想法',text:note.reflection,role:'本人'};
    return a;
  }
  function anchors(note, scope, turns) {
    const a = sourceAnchors(note,scope);
    turns.forEach((t,i) => {a['T'+(i+1)]={label:'第 '+(i+1)+' 則・'+t.role,text:t.text,role:t.role==='我'?'本人':'GPT'};});
    return a;
  }
  function shellCard(thread,note,status) {
    return {格式:format,討論ID:thread.id,討論包ID:thread.pack.id,選段ID:note.id,...(thread.pack.scope?{帶入範圍:thread.pack.scope}:{}),狀態:status,問答:[],下次從這裡:'',候選:[]};
  }
  function cardFormat(thread,note,status) {
    return [
      '產生回傳卡時只輸出一個 JSON 物件。保留以下三個 ID 原值，問答按實際順序填。',
      JSON.stringify(shellCard(thread,note,status),null,2),
      '「問答」填入本輪實際說過的內容，每則用 {"角色":"我","內容":"逐字發言"} 或 {"角色":"GPT","內容":"逐字發言"}。從本輪帶入的問題或第一句發問開始，保留前後次序，不替我補話，不重抄舊輪次、討論包或收尾指令。T1、T2 依問答陣列的順序編號。若我還沒回答，照實保留 GPT 的提問。',
      status==='暫存'?'「下次從這裡」填一個具體續談點，「候選」保持空陣列。':'「候選」每項使用 {"類型":"觀點","內容":"一句候選文字","依據":"T2","依據原句":"逐字片段","行動":""}。類型可為「觀點」或「洞察卡」。洞察卡可帶一項待觀察或執行的行動。「依據」填本輪 T 編號，或本次已帶入的 N（既有心得）、S（作者原文）。「依據原句」須從該筆完整逐字摘錄一小段。出自 GPT 的建議或書中原文要用它自己的依據，不能掛到本人名下。沒有合適成果時留空陣列。「下次從這裡」可留空。',
      '我同意收尾只表示可以整理。候選觀點與行動須引用有實質內容的原句。輸出前確認 JSON 字串中的引號、換行均正確跳脫。'
    ].join('\n\n');
  }
  function instructions(thread,note,status) {
    const request=status==='暫存'?'請把這一輪整理成暫存卡，讓我下次能接著談。':'請整理這次討論，回傳完成卡，讓我自己挑選觀點與洞察卡。';
    return request+'\n\n'+cardFormat(thread,note,status);
  }
  function buildPacket(book,note,scope,thread) {
    const pack=thread.pack, a=sourceAnchors(note,scope);
    const intro=['【心知｜本次閱讀討論包】','書籍　'+book.book,'讀次　第 '+book.read+' 次'+(book.start?'（'+book.start+' 開始）':''),'來源　'+book.source+'，'+(note.location?'閱讀位置：'+note.location:'本選段未記頁碼、章節'),'選段　'+note.label+'／'+scopes[scope], '讀前問題　'+((pack.readingQuestion??book.opening)||'尚未填寫')];
    if(a.S)intro.push('【S｜作者原文】\n'+a.S.text);
    if(a.N)intro.push('【N｜我當時已寫下的想法】\n'+a.N.text);
    intro.push('【本次怎麼聊】\n用繁體中文，依選段討論。引述原文、我的說法、你的推論分清楚。只看到摘錄時不要假稱讀過全書。別補作者、章節、頁碼或科學證據。先理解我想問什麼，一次只談一個重點。',
      '【何時主動收斂】\n'+convergenceGuide);
    if(thread.rounds.at(-1)?.status==='暫存') {
      const previous=thread.rounds.at(-1);
      const evidence=previous.turns.slice(-12).map(t=>t.role+'：'+t.text).join('\n');
      intro.push('【接續上次｜舊輪次供回顧】\n'+evidence+'\n上次停在　'+(previous.next||'上次的最後一則問答')+'\n沿用已說清楚的地方，從這次想談的焦點接續。之前同意收尾只適用於當時那一輪。本輪回傳只記新的問答。');
    }
    if(pack.question)intro.push((pack.starter==='me'?'【我這次的問題】':'【我想談的方向】')+'\n'+pack.question);
    intro.push('【開場】\n'+(pack.starter==='me'?'先回答我這次的問題。':'先就這次選段或續談點，問我一個能幫助我說清理解的問題，等我回答。'));
    intro.push('【收尾時才使用的回傳格式】\n我同意你的收尾提議，或主動要求整理時，用下列完成卡格式。若我說「先暫存」，沿用同一格式與 ID，把狀態改為「暫存」，寫好下次從這裡，候選留空。',
      cardFormat(thread,note,'完成'),'收到這份討論包時先依開場自然對話。');
    return intro.join('\n\n');
  }
  function readJSON(raw) {
    const s=String(raw||'').trim();
    if(!s) throw Error('先貼上從 ChatGPT 帶回的回傳卡。');
    if(s.length>170000) throw Error('這輪回傳太長，請讓 GPT 分成較短的一輪並保留發言原句。');
    const blocks=[...s.matchAll(/^`{3}(?:json)?[ \t]*\r?\n([\s\S]*?)^`{3}[ \t]*\r?$/gmi)].map(m=>m[1].trim()).filter(t=>t.startsWith('{'));
    if(blocks.length>1)throw Error('這裡有兩張以上的卡，請一次貼回一張。');
    const body=blocks[0]||s;
    const start=body.indexOf('{'), end=body.lastIndexOf('}');
    if(start<0||end<=start) throw Error('找不到回傳卡的 JSON。請用「複製整理指令」或「複製暫存指令」，並貼回完整結果。');
    const json=body.slice(start,end+1);
    try{return JSON.parse(json);}catch{
      // Some copied replies contain literal newlines inside an otherwise valid JSON string.
      const escaped=json.replace(/"(?:\\[\s\S]|[^"\\])*"/g,part=>part.replace(/[\u0000-\u001f]/g,c=>JSON.stringify(c).slice(1,-1)));
      if(escaped!==json){try{return JSON.parse(escaped);}catch{}}
      throw Error('這段文字還讀不成完整的 JSON。可把下方的修正指令貼回原來的 GPT 對話，請它重新輸出同一張卡。');
    }
  }
  function string(v){return typeof v==='string'?v.trim():'';}
  function readReturn(raw) {
    const d=readJSON(raw);
    if(!d || d.格式!==format) throw Error('需要「心知閱讀討論/v1」回傳卡。可以請原來的 GPT 對話重新輸出。');
    for(const name of ['討論ID','討論包ID']){
      let id=string(d[name]).replace(/[‐‑‒–—−﹣－]/g,'-');
      if(/^[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}$/i.test(id))id=id.toLowerCase();
      else if(!/^rd-[a-z\d]+-[a-z\d]+$/i.test(id))throw Error('回傳卡缺少有效的「'+name+'」。請原對話沿用帶出時的識別碼。');
      d[name]=id;
    }
    if(!string(d.選段ID))throw Error('回傳卡缺少「選段ID」。請沿用原討論包上的選段。');
    return d;
  }
  function makeCandidate(c,refs,packId,index){
    if(!c||!['觀點','洞察卡'].includes(c.類型)||!string(c.內容))throw Error('請補上候選類型與想保留的文字。');
    const anchor=string(c.依據), quote=string(c.依據原句);
    const ref=Object.hasOwn(refs,anchor)?refs[anchor]:null;
    if(!ref||!quote||!ref.text.includes(quote))throw Error('依據原句跟所指的發言或筆記對不上。');
    return {id:packId+'/'+index,type:c.類型,text:string(c.內容),action:string(c.行動),anchor,quote,origin:ref.role,originLabel:ref.label,status:'待選',share:false,packId};
  }
  function check(raw,thread,note,scope) {
    const d=readReturn(raw);
    if(d.選段ID!==note.id || d.討論ID!==thread.id) throw Error('這是其他選段或討論的回傳卡。請回到原本的選段和帶入範圍貼回。');
    if(thread.rounds.some(r=>r.packId===d.討論包ID)) throw Error('這一輪已經保存，可以到「討論成果」回看。');
    if(!thread.pack || thread.pack.id!==d.討論包ID) throw Error('討論包 ID 與目前輪次不同。請使用本輪的暫存或整理指令。');
    const status=d.狀態;
    if(!['暫存','完成'].includes(status))throw Error('狀態應為「暫存」或「完成」。');
    if(!Array.isArray(d.問答) || !d.問答.length) throw Error('這張卡的「問答」是空的。請原對話把已經談過的實際發言填入完成卡。');
    if(d.問答.length>240)throw Error('這張卡超過 240 則發言，請原對話分輪整理並保留原句。');
    const roles={我:'我',本人:'我',使用者:'我',user:'我',GPT:'GPT',ChatGPT:'GPT',assistant:'GPT'};
    const turns=d.問答.map((t,i)=>{
      const role=t?.角色??t?.role,text=string(t?.內容??t?.content);
      if(!Object.hasOwn(roles,role)||!text)throw Error('請檢查第 '+(i+1)+' 則問答的角色與內容。');
      return {role:roles[role],text};
    });
    const next=string(d.下次從這裡);
    if(status==='暫存' && !next) throw Error('暫存卡需要「下次從這裡」，方便重新開啟討論。');
    const items=d.候選??[];
    if(!Array.isArray(items)||items.length>80)throw Error('候選欄位需要是最多 80 筆的清單，沒有項目時可用空清單。');
    if(status==='暫存'&&items.length)throw Error('暫存卡先保留問答與續談點。請將候選留空，或改用完成卡。');
    const refs=anchors(note,scope,turns);
    const candidates=[],pending=[];
    items.forEach((c,i)=>{
      try{candidates.push(makeCandidate(c,refs,thread.pack.id,i));}
      catch(e){pending.push({index:i,original:c,reason:e.message});}
    });
    return {packId:thread.pack.id,seq:thread.pack.sequence,status,turns,next,candidates,pending};
  }
  function commit(raw,thread,note,scope){
    const card=check(raw,thread,note,scope);
    thread.rounds.push({packId:card.packId,seq:card.seq,status:card.status,turns:card.turns,next:card.next,pending:card.pending});
    thread.proposals.push(...card.candidates);
    if(thread.raw===raw)thread.raw='';
    return card;
  }
  function repairCandidate(thread,note,scope,packId,index,input){
    const round=thread.rounds.find(r=>r.packId===packId);
    if(!round?.pending?.some(p=>p.index===index))throw Error('這筆候選已核對。');
    const p=makeCandidate(input,anchors(note,scope,round.turns),packId,index);
    thread.proposals.push(p);round.pending=round.pending.filter(x=>x.index!==index);return p;
  }
  function adopt(thread,id) {
    const p=thread.proposals.find(x=>x.id===id);if(!p||p.status!=='待選')throw Error('這筆候選已經處理。');
    if(!p.text.trim())throw Error('請先寫下你想保存的文字。');
    if(p.type==='洞察卡'&&!p.action.trim())throw Error('請補上你想觀察或實際執行的事，再保存洞察卡。');
    const item={...p,text:p.text.trim(),action:p.type==='洞察卡'?p.action.trim():'',status:'本人已確認',version:1,uses:[]};
    thread.products.push(item);p.status='已採用';return item;
  }
  function useItem(item,place){
    if(!item.share || !['織光堂','聊解室'].includes(place))throw Error('請先開放這筆成果供其他場域取用。');
    if(item.uses.some(v=>v.place===place&&v.version===item.version))return false;
    item.uses.push({place,version:item.version,text:item.text});return true;
  }
  function productText(book,note,thread,item){
    const round=thread?.rounds.find(r=>r.packId===item.packId);
    const source=[book.book,'第 '+book.read+' 次閱讀',note.label,note.location,round&&'第 '+round.seq+' 輪討論','v'+item.version].filter(Boolean).join(' · ');
    return [
      '【'+(item.type==='觀點'?'我的觀點':'洞察卡')+'】',
      item.text,
      item.type==='洞察卡'&&item.action?'待觀察／執行　'+item.action:'',
      '來源　'+source,
      item.method==='manual'?'手動留卡 · '+item.originLabel+'　'+item.quote:''
    ].filter(Boolean).join('\n');
  }
  function exampleCard(thread,note,scope,status){
    const d=shellCard(thread,note,status);
    d.內建示例=true;
    const first=note.id.endsWith('-a');
    const previous=thread.rounds.at(-1);
    const opening=first?'你會怎麼分辨擔心和準備？':'當你能自己選時，會做哪一個具體決定？';
    const initialAnswer=first?'我想到出門前一直重看時間。先查好班次才是我真的做了的準備。':'我可以先寫下這次想表達的內容，再去看別人期待我寫什麼。';
    const observe=first?'如果要觀察這個差別，下次你會記什麼？':'下次怎麼觀察自己的選擇有沒有改變？';
    const action=first?'下次擔心遲到時，我想記下我反覆想了什麼，以及我實際做了哪一步。':'寫下自己原先想選的方向，再和看過他人的意見後做的決定比對。';
    const view=first?'對我而言，反覆看時間和實際準備是兩件可以分開描述的事。':'我想先說出自己原本想選的方向。';
    const q=previous?.next|| (previous?'回頭看上次的例子，你想怎麼試？':opening);
    const answer=previous?action:initialAnswer;
    const follow=previous?'用你自己的話，你目前會怎麼描述這個差別？':observe;
    const finalAnswer=previous?view:action;
    d.問答=[{角色:'GPT',內容:q},{角色:'我',內容:answer}];
    if(status==='暫存'){d.下次從這裡=follow;return JSON.stringify(d,null,2);}
    const recap=first
      ? (previous?'你打算把反覆擔心和實際做的那一步分開記。':'在你的例子裡，反覆看時間和實際去查班次，是兩件你能分開描述的事。')
      : (previous?'你想把原先的方向和聽過別人意見後的決定放在一起看。':'你想先寫下自己想表達的內容，再看別人期待什麼。');
    d.問答.push({角色:'GPT',內容:recap+'這輪可以整理成完成卡嗎？'},{角色:'我',內容:'可以整理。'+finalAnswer});
    d.候選=[
      {類型:'觀點',內容:view,依據:previous?'T4':'T2',依據原句:previous?finalAnswer:answer,行動:''},
      {類型:'洞察卡',內容:first?'我想觀察自己何時從擔心轉向準備。':'我想觀察他人的意見如何影響我的選擇。',依據:previous?'T2':'T4',依據原句:action,行動:action}];
    return JSON.stringify(d,null,2);
  }
  const api={format,scopes,convergenceUpdate,uid,newThread,newPacket,sourceAnchors,anchors,buildPacket,instructions,readReturn,check,commit,repairCandidate,adopt,useItem,productText,exampleCard};
  root.ReadingTrial=api;
  if(typeof module!=='undefined' && module.exports)module.exports=api;
})(globalThis);
