'use strict';
(function () {
  const C=window.ReadingTrial, R=window.ReadingReturns, book=window.readingBook, key='lumen.xinzhi.reading.public-demo.v11';
  const referenceNotes=[...book.notes], hubModel=window.MindHub, clips=window.ReadingClips;
  const $=id=>document.getElementById(id);
  const fresh=()=>({v:1,note:book.notes[0].id,mode:'my',tab:'home',scopes:{},sessions:{}});
  let db=fresh(),storageOK=true,busyCopy=false;
  try{const raw=localStorage.getItem(key);if(raw){const prior=JSON.parse(raw);if(prior.v===1&&prior.sessions&&prior.scopes)db=prior;}}
  catch{storageOK=false;}
  function store() {
    try{localStorage.setItem(key,JSON.stringify(db));storageOK=true;}catch{storageOK=false;}
    $('warning').hidden=storageOK;
    $('warning').textContent=storageOK?'':'這個瀏覽器目前無法保存本機進度。切換頁面前請保留討論包和 GPT 回傳卡。';
    return storageOK;
  }
  function el(tag,attrs,...children){
    const e=document.createElement(tag);
    for(const [k,v] of Object.entries(attrs||{})){
      if(v==null || v===false)continue;
      if(k==='cls')e.className=v;
      else if(k.startsWith('on') && typeof v==='function')e.addEventListener(k.slice(2),v);
      else if(k==='checked')e.checked=Boolean(v);
      else if(k==='value')e.value=v;
      else e.setAttribute(k,v===true?'':String(v));
    }
    for(const child of children.flat(Infinity)){if(child!=null&&child!==false)e.append(child);}
    return e;
  }
  const div=(cls,...kids)=>el('div',{cls},...kids);
  const para=(text,cls)=>el('p',{cls},text);
  const hd=(n,text)=>el('h'+n,{},text);
  const btn=(label,run,cls='secondary',extra={})=>el('button',{type:'button',cls,onclick:run,...extra},label);
  const a=(label,url,cls)=>el('a',{href:url,cls,target:'_blank',rel:'noopener noreferrer'},label);
  const rule=()=>div('rule');
  const pill=t=>el('span',{cls:'pill'},t);
  const label=(id,text)=>el('label',{cls:'field',for:id},text);
  const details=(title,...kids)=>el('details',{},el('summary',{},title),...kids);
  const mindState=()=>db.mode==='demo'?db.mind.demo:db.mind;
  function note(){return book.notes.find(n=>n.id===db.note)||book.notes[0];}
  const bookInfo=n=>clips.bookInfo(n,book);
  const visibleNotes=()=>book.notes.filter(n=>!n.local||n.owner===db.mode);
  function bookList(){
    const books=new Map();
    for(const n of visibleNotes()){
      const info=bookInfo(n);
      if(!books.has(info.key))books.set(info.key,{...info,notes:[]});
      books.get(info.key).notes.push(n);
    }
    return [...books.values()];
  }
  function bookState(){
    const info=bookInfo(note()),state=mindState();
    if(info.original)return state;
    state.bookDetails??={};return state.bookDetails[info.key]??={};
  }
  async function commitReading(owner,modify){
    const run=()=>{
      const next=JSON.parse(localStorage.getItem(key)||JSON.stringify(db));
      hubModel.init(next);
      const state=owner==='demo'?next.mind.demo:next.mind;
      const value=modify(state,next);
      localStorage.setItem(key,JSON.stringify(next));
      const here=locationFor();db=next;restore(here);
      book.notes=[...referenceNotes,...db.mind.notes,...db.mind.demo.notes];
      return value;
    };
    return navigator.locks? navigator.locks.request('xinzhi-reading-save',run):run();
  }
  function scope(){return db.scopes[note().id]||'both';}
  function currentKey(){return R.activeKey(db,db.mode,note().id,scope());}
  function session(){
    const id=currentKey();
    if(!db.sessions[id])db.sessions[id]=C.newThread();
    return db.sessions[id];
  }
  function flash(text){$('notice').replaceChildren(...(text?[para(text,'status-note')]:[]));}
  function topOfPage(){
    const title=$('page-title');if(title)title.focus({preventScroll:true});
    window.scrollTo({top:0,behavior:'instant'});
  }
  const pages=['map','practice','home','items','item','shelf','clip','read','talk','results','cards','visits'];
  let parents=[];
  const trail=window.MindTrail;
  const pageNames={map:'場域',practice:'修習所',home:'心知首頁',items:'學習項目',item:'學習項目',shelf:'閱讀書架',clip:'心知閱讀截圖',read:'閱讀選段',talk:'GPT 討論',results:'討論成果',cards:'卡片庫',visits:'今日回訪'};
  function route(){
    const page=window.location.hash.slice(1);return pages.includes(page)?page:'home';
  }
  function locationFor(page=db.tab){
    return {page,note:db.note,scope:scope(),key:currentKey(),mode:db.mode,item:mindState().item,itemTab:mindState().itemTab,filter:mindState().cardFilter};
  }
  function syncRoute(replace=false){
    const history=window.history,prior=history.state,same=prior?.page===db.tab;
    const overwrite=replace||same||window.location.hash==='#'+db.tab;
    const value={...locationFor(),parents,id:same&&prior.id?prior.id:C.uid(),chain:prior?.chain||C.uid(),index:(prior?.index||0)+(overwrite?0:1)};
    if(overwrite)history.replaceState(value,'','#'+db.tab);
    else history.pushState(value,'','#'+db.tab);
  }
  function restore(position){
    const switchingMode=position.mode&&db.mode!==position.mode;
    if(position.mode==='my'||position.mode==='demo')db.mode=position.mode;
    const selected=switchingMode||['read','talk','results'].includes(position.page);
    if(selected&&position.key&&db.sessions[position.key]){
      const target=R.sessions(db).find(t=>t.key===position.key);R.select(db,target);
    }else if(selected&&position.note&&book.notes.some(n=>n.id===position.note)){
      db.note=position.note;db.scopes[position.note]=position.scope||'both';
    }
    if(position.item)mindState().item=position.item;
    if(position.itemTab)mindState().itemTab=position.itemTab;
    else if(position.anchor==='item-tools')mindState().itemTab='tools';
    if(position.filter)mindState().cardFilter=position.filter;
    db.tab=position.page;
  }
  function parentLabel(){
    const p=parents.at(-1);if(!p)return '';
    if(p.page==='read')return book.notes.find(n=>n.id===p.note)?.label||pageNames.read;
    if(p.page==='item')return (p.mode==='demo'?db.mind.demo:db.mind).items.find(i=>i.id===p.item)?.name||pageNames.item;
    return pageNames[p.page];
  }
  function returnFocus(anchor){
    const target=anchor&&$(anchor);if(target){target.tabIndex=-1;target.focus({preventScroll:true});target.scrollIntoView({block:'start'});}
    else topOfPage();
  }
  function goUp(){
    const p=parents.at(-1);if(!p)return;
    const here=window.history.state;
    if(p.id&&p.chain===here?.chain&&p.index<here.index){window.history.go(p.index-here.index);return;}
    parents=parents.slice(0,-1);restore(p);store();render();syncRoute(true);flash('');returnFocus(p.anchor);
  }
  function nav(tab,msg){
    const state=window.history.state,from=state?.page===db.tab?{...state}:locationFor();
    delete from.parents;
    if(from.page==='item'&&from.itemTab==='tools'&&['shelf','read'].includes(tab))from.anchor='item-tools';
    if(from.page==='read')from.anchor='reading-selection';
    if(state?.page===from.page&&from.anchor)window.history.replaceState({...state,anchor:from.anchor},'');
    parents=trail.enter(parents,from,locationFor(tab));
    db.tab=tab;if(['read','talk','results','shelf'].includes(tab))delete mindState().resumeItem;
    store();render();syncRoute();flash(msg||'');topOfPage();
  }
  function openThread(target,page,atReturn=false,productId=''){
    R.select(db,target);nav(page);
    if(atReturn){
      const area=$('return-area'),fold=area?.closest('details');if(fold)fold.open=true;
      if(area){reveal(area);$('check-return')?.click();}
    }
    if(productId){
      const card=document.getElementById('product-'+productId);
      if(card){const source=card.querySelector('details');if(source)source.open=true;reveal(card);}
    }
  }
  function changeNote(n){db.note=n.id;store();render();syncRoute();flash('');}
  function openNote(n){
    if(db.tab==='read')changeNote(n);
    else{db.note=n.id;nav('read');}
  }
  function openProduct(t,p){
    if(!t.manual){openThread(t,'results',false,p.id);return;}
    const source=visibleNotes().find(n=>n.id===t.noteId);if(!source)return;
    openNote(source);
    const card=$('product-'+p.id),fold=card?.closest('details');
    if(fold)fold.open=true;
    if(card)reveal(card);
  }
  function isStoredExample(s){
    try{const d=C.readReturn(s.raw);return d.討論ID===s.id&&d.討論包ID===s.pack?.id&&R.isBuiltIn(d,book.notes.find(n=>n.id===d.選段ID));}catch{return false;}
  }
  function changeMode(mode,cardStatus){
    db.mode=mode;if(note().local&&(note().owner!==mode||mode==='demo'&&cardStatus))db.note=referenceNotes[0].id;db.tab='talk';
    let kept=false;
    if(mode==='demo'){
      const s=session();
      if(cardStatus&&s.raw.trim()&&!isStoredExample(s))kept=true;
      else if(cardStatus){
        if(s.pack&&s.rounds.some(r=>r.packId===s.pack.id))C.newPacket(s);
        else if(!s.pack)C.newPacket(s);
        s.pack.scope=scope();
        s.raw=C.exampleCard(s,note(),scope(),cardStatus);
      }
    }
    store();render();syncRoute();flash(mode==='demo'?'你正在使用示例人物的問答，成果另存於示例。':'已回到你自己的討論。');
    if(mode==='demo'&&cardStatus)document.getElementById('return-area')?.scrollIntoView({block:'start'});
    if(kept)$('return-error').textContent='輸入框保留了先前貼上的卡。請按「核對回傳卡」繼續。';
  }
  function manualCopy(text,title){
    const d=$('copy-dialog');$('copy-text').value=text;$('copy-title').textContent=title;
    if(typeof d.showModal==='function'&&!d.open)d.showModal();else d.setAttribute('open','');
    $('copy-text').focus();$('copy-text').select();$('copy-text').setSelectionRange(0,text.length);
  }
  async function copy(text,title){
    if(busyCopy)return;busyCopy=true;
    try{if(!navigator.clipboard||!navigator.clipboard.writeText)throw Error();await navigator.clipboard.writeText(text);flash('已複製「'+title+'」。');}
    catch{manualCopy(text,title);}finally{busyCopy=false;}
  }
  function sourceParts(n,sc){
    const parts=[];
    if(sc==='unknown')return [para('這張舊卡沒有記錄原先帶了哪一部分。這輪以已帶回的問答為依據。','small')];
    if(sc!=='reflection'&&n.excerpt)parts.push(div('stack-tight',el('span',{cls:'label'},n.local?'我的摘錄・作者原文':'示例摘錄'),el('blockquote',{},n.excerpt)));
    if(sc!=='excerpt'&&n.reflection)parts.push(div('alt stack-tight',el('span',{cls:'label'},'我當時寫下的想法'),para(n.reflection,'reflect')));
    return parts;
  }
  function readingQuestion(){return bookState().readingQuestion??bookInfo(note()).opening;}
  function readingOpening(){
    const state=bookState(),field=el('textarea',{id:'reading-opening',rows:2,maxlength:1000});
    const error=div('error');
    error.setAttribute('role','alert');
    field.value=readingQuestion();
    const title=()=> '讀前問題　'+(readingQuestion()||'寫下想弄懂的事');
    const fold=details(title(),div('stack-tight',label(field.id,'這次閱讀想弄懂什麼？'),field,error,btn('保存讀前問題',()=>{
      const question=field.value.trim();
      if(!question){errorHere(error,'請先寫下一個問題。',field);return;}
      const previous=state.readingQuestion;
      state.readingQuestion=question;
      if(!store()){
        state.readingQuestion=previous;
        errorHere(error,'裝置未能保存。請保留這個問題。',field);return;
      }
      error.textContent='';
      field.removeAttribute('aria-invalid');
      fold.firstElementChild.textContent=title();
      flash('讀前問題已保存。新準備的討論包會帶入這個問題。');
    })));
    fold.classList.add('book-question');
    return fold;
  }
  function side(compact){
    const n=note(),info=bookInfo(n),sourceInfo=div('book-panel stack-tight',el('span',{cls:'label'},'心知書架'),el('span',{cls:'book-title'},info.book),
      para(['第 '+info.read+' 次閱讀',info.start].filter(Boolean).join('　·　'),'small'));
    if(!compact)sourceInfo.append(readingOpening());
    const selection=div('stack-tight',el('span',{cls:'note-label'},compact?'本輪選段':'選擇閱讀段落'));
    if(compact){
      selection.append(div('eyeline',pill(n.label),el('span',{cls:'small'},C.scopes[scope()])),btn('換一段閱讀',()=>nav('read'),'ghost'));
    }else{
      const notes=visibleNotes().filter(cand=>bookInfo(cand).key===info.key);
      selection.append(div('topic-list'+(notes.length>2?' many-notes':''),notes.map((cand,i)=>btn(cand.label,()=>changeNote(cand),'source-pick',{'aria-pressed':String(n.id===cand.id),'aria-label':'選擇第 '+(i+1)+' 段 '+cand.label}))));
      if(notes.length>2){
        const pick=selectControl('compact-notes',notes.map(x=>[x.id,x.label]),n.id,id=>changeNote(notes.find(x=>x.id===id)));
        pick.setAttribute('aria-label','選擇閱讀段落');pick.className='compact-notes';selection.append(pick);
      }
      selection.append(newNoteForm(),btn('從行光剪藏加入截圖',()=>nav('clip'),'text-link'));
    }
    const aside=el('aside',{cls:'left stack'+(compact?' small-side':'')},sourceInfo,selection);
    return aside;
  }
  function selectControl(id,options,current,change){
    const select=el('select',{id,onchange:e=>change(e.target.value)});
    for(const [value,text] of options)select.append(el('option',{value},text));
    select.value=current;return select;
  }
  function newNoteForm(quick=false){
    const prefix=quick?'quick-note-':'note-';
    const title=el('input',{id:prefix+'title',type:'text',maxlength:80}),excerpt=el('textarea',{id:prefix+'excerpt',rows:3,maxlength:6000});
    const reflection=el('textarea',{id:prefix+'thought',rows:3,maxlength:6000}),location=el('input',{id:prefix+'location',type:'text',maxlength:120});
    const error=el('div',{cls:'error',role:'alert'});
    const form=div('capture-form',label(title.id,'選段名稱'),title,label(excerpt.id,'書中摘錄'),excerpt,label(reflection.id,'我的心得'),reflection,
      label(location.id,'頁碼或位置（選填）'),location,error,btn('保存選段',()=>{
        if(!title.value.trim()||(!excerpt.value.trim()&&!reflection.value.trim())){
          error.textContent='請填寫選段名稱，並至少留下一段摘錄或心得。';return;
        }
        const info=bookInfo(note());
        const n={id:'local-'+C.uid(),label:title.value.trim(),excerpt:excerpt.value.trim(),reflection:reflection.value.trim(),location:location.value.trim(),local:true,owner:db.mode,bookTitle:info.book,readNumber:info.read};
        mindState().notes.push(n);db.scopes[n.id]=!n.excerpt?'reflection':!n.reflection?'excerpt':'both';
        if(!store()){
          mindState().notes.pop();delete db.scopes[n.id];
          error.textContent='裝置未能保存，請先保留這段文字。';return;
        }
        if(quick){
          $('add-dialog').close();
          if(db.tab==='shelf'||db.tab==='read'&&!['note-title','note-excerpt','note-thought','note-location'].some(id=>$(id)?.value))render();
          flash('已將「'+n.label+'」保存到這本書。');
          $('notice').append(btn('打開新選段',()=>openNote(n),'text-link'));
        }else{changeNote(n);flash('選段已保存在這本閱讀筆記，可以開始討論。');}
      },'primary'));
    return quick?form:details('新增閱讀選段',form);
  }
  function readingDiscussions(n){
    const threads=R.sessions(db).filter(t=>t.mode===db.mode&&t.noteId===n.id&&t.thread.rounds.length);
    if(!threads.length)return null;
    return details('回看這段的問答與成果',threads.map(t=>{
      const {rounds,products}=t.thread,last=rounds.at(-1);
      return div('log-entry stack-tight',
        para([C.scopes[t.scope],'已保存 '+rounds.length+' 輪','最新一輪已'+last.status,products.length+' 筆已確認成果'].join(' · '),'small'),
        div('actions',
          btn('回看問答與成果',()=>openThread(t,'results')),
          last.status==='暫存'?btn('接著談這一段',()=>openThread(t,'talk')):null));
    }));
  }
  function readingRecap(){
    const state=bookState();
    const error=el('p',{cls:'error',role:'alert'});
    const recap=el('textarea',{id:'read-recap',rows:3,maxlength:6000,oninput:()=>{
      state.recap=recap.value;
      state.recapComplete=false;
      error.textContent=store()?'':'裝置未能保存。請保留你的讀後復盤。';
      updateStatus();
    }});
    recap.value=state.recap||'';
    const toggle=btn('',()=>{
      if(!recap.value.trim()){error.textContent='先寫下你的讀後復盤。';recap.focus();return;}
      state.recapComplete=!state.recapComplete;
      if(!store()){
        state.recapComplete=!state.recapComplete;
        error.textContent='裝置未能保存完成狀態。';return;
      }
      error.textContent='';
      updateStatus();
      flash(state.recapComplete?'這次讀後復盤已完成。':'這次讀後復盤已改成待確認。');
    });
    const fold=details('讀後復盤',div('stack-tight',
      para('回到讀前的問題，記下現在的理解，以及還想釐清的地方。','small'),
      label(recap.id,'我的讀後復盤（自動保存）'),recap,error,toggle));
    function updateStatus(){
      const done=state.recapComplete,hasText=!!state.recap?.trim();
      fold.firstElementChild.textContent='讀後復盤'+(done?' · 已完成':hasText?' · 待確認':'');
      toggle.textContent=done?'改為待確認':'標記讀後復盤完成';
    }
    updateStatus();
    return div('box',fold);
  }
  function manualEntry(n){
    const owner=db.mode,uid=C.uid();
    const body=el('textarea',{id:'manual-text',rows:3,maxlength:2400,placeholder:'用自己的話寫下想留下的理解'});
    const action=el('textarea',{id:'manual-action',rows:2,maxlength:2400});
    const actionRow=div('stack-tight',label(action.id,'我想觀察或執行的事'),action);actionRow.hidden=true;
    const kind=selectControl('manual-kind',[['觀點','我的觀點'],['洞察卡','洞察卡']],'觀點',v=>{actionRow.hidden=v!=='洞察卡';});
    const err=el('p',{cls:'form-error',role:'alert'});
    const save=btn('確認留卡',async()=>{
      if(save.disabled)return;save.disabled=true;
      try{
        const card=clips.manualCard(n,{type:kind.value,text:body.value,action:action.value},uid);
        await commitReading(owner,state=>{
          state.manualCards??=[];
          if(!state.manualCards.some(p=>p.id===uid))state.manualCards.unshift(card);
        });
        render();flash('已存入心知卡片庫，來源連回「'+n.label+'」。');
        $('notice').append(btn('查看這張卡',()=>openProduct({manual:true,noteId:n.id},card),'text-link'));
      }catch(e){err.textContent=e?.message||'目前無法保存卡片，請保留你寫的文字。';}
      finally{save.disabled=false;}
    },'primary');
    const form=details('手動留卡',div('stack-tight',para('出處會隨卡保存。','small'),label(kind.id,'卡片類型'),kind,
      label(body.id,'我的理解'),body, n.reflection?btn('帶入我原本的心得',()=>{body.value=n.reflection;body.focus();},'text-link'):null,actionRow,err,save));
    return details('更多',form);
  }
  function reading(){
    const n=note(),s=session(),sc=scope();
    const reader=el('article',{cls:'reader stack',id:'reading-selection'},div('eyeline',pill('閱讀筆記'),el('span',{cls:'small'},bookInfo(n).source)),hd(2,n.label),sourceParts(n,'both'),n.clipId?clipView.attachment(n):null,
      para(n.location?'閱讀位置　'+n.location:'此選段未記錄頁碼與章節。','small'),rule(),div('stack-tight',label('scope','這次想帶哪一部分？'),
        selectControl('scope',Object.entries(C.scopes).filter(([value])=>value===sc||value==='both'&&n.excerpt&&n.reflection||value==='excerpt'&&n.excerpt||value==='reflection'&&n.reflection),sc,v=>{db.scopes[n.id]=v;store();render();syncRoute();flash('');})),
      div('actions',btn(s.rounds.length||s.pack?'回到這段討論':'用這段開始討論',()=>nav('talk'),'primary')));
    const state=mindState();
    const linked=selectControl('note-item',[['','暫不連結'],...hubModel.availableItems(state).map(i=>[i.id,i.name])],state.links[n.id]||'',id=>{
      const previous=state.links[n.id];
      if(id)state.links[n.id]=id;
      else delete state.links[n.id];
      if(!store()){
        if(previous)state.links[n.id]=previous;
        else delete state.links[n.id];
        linked.value=previous||'';
        return;
      }
      flash('已更新這段筆記的學習項目。');
    });
    reader.append(manualEntry(n),details('連結學習項目',label('note-item','這一段和哪個項目有關？'),linked));
    const personal=(state.manualCards||[]).filter(p=>p.noteId===n.id);
    if(personal.length)reader.append(details('手動留下的卡片（'+personal.length+'）',personal.map(p=>product(null,p))));
    const discussions=readingDiscussions(n);
    if(discussions)reader.append(discussions);
    return div('layout',side(false),div('right column-stack',reader,readingRecap()));
  }
  function transcript(turns,focus){
    const list=el('ol',{cls:'transcript'});
    turns.forEach((t,i)=>list.append(el('li',{cls:t.role==='GPT'?'gpt':''},el('b',{},'T'+(i+1)+'　'+t.role+(focus==='T'+(i+1)?' · 這筆成果的依據':'')),para(t.text))));
    return list;
  }
  function history(s){
    if(!s.rounds.length)return null;
    return div('box stack-tight',hd(2,'已保存的問答'),[...s.rounds].reverse().map(r=>
      el('div',{cls:'history-item'},details('第 '+r.seq+' 輪 · '+r.status+' · '+r.turns.length+' 則問答',
        transcript(r.turns),r.next?para('下次從這裡　'+r.next,'alt'):null))));
  }
  function sampleLinks(){
    const wrap=details('先試走一輪示例',para('示例人物的回答會存到獨立的示例區。你可以先試貼回、核對和立卡。','small'),
      div('actions',btn('試完成卡',()=>changeMode('demo','完成')),btn('試暫存卡',()=>changeMode('demo','暫存'))));
    return div('aside-tools',wrap);
  }
  function questionForm(s){
    const paused=s.rounds.at(-1)?.status==='暫存';
    const group=div('choice-group');
    [['gpt','讓 GPT 先問我'],['me','我想先提問']].forEach(([val,txt])=>{
      const inp=el('input',{type:'radio',name:'starter',value:val,checked:s.starter===val,onchange:()=>{
        s.starter=val;store();render();}});
      group.append(el('label',{cls:'choice'},inp,txt));
    });
    const error=div('error');error.id='question-error';error.setAttribute('role','alert');
    const question=el('textarea',{id:'question',rows:3,maxlength:4000,'aria-describedby':'question-error',placeholder:s.starter==='me'?'你想釐清哪一句，或哪個生活例子？':'若已有卡住的地方，可以先寫下來。',oninput:e=>{s.question=e.target.value;store();error.textContent='';}});
    question.value=s.question;
    const start=btn(paused?'準備續談包':'準備討論包',()=>{
      if(s.starter==='me'&&!s.question.trim()){error.textContent='請寫下想問的一句話，或選「讓 GPT 先問我」。';question.focus();return;}
      const shown=R.resume(db,db.mode);
      const packet=C.newPacket(s);
      packet.scope=scope();
      packet.readingQuestion??=readingQuestion();
      if(shown?.kind==='paused'&&shown.key===currentKey())R.pin(db,currentKey());
      store();render();flash('討論包已準備好，可以複製到 ChatGPT。');
    },'primary');
    return div('box stack',hd(2,paused?'從上次停下的地方繼續':s.rounds.length?'這一輪想談什麼？':'你想怎麼開始？'),
      paused&&s.rounds.at(-1)?.next?para('上次停在　'+s.rounds.at(-1).next,'alt'):null,
      group,div('stack-tight',label('question',s.starter==='me'?'我這次的問題':'我想談的方向（選填）'),question,error),
      div('actions',start),db.mode==='my'?sampleLinks():null);
  }
  function errorHere(node,message,input){
    node.textContent=message;node.hidden=false;node.setAttribute('tabindex','-1');node.focus();
    if(input)input.setAttribute('aria-invalid','true');
  }
  function reveal(node){
    node.tabIndex=-1;node.focus({preventScroll:true});node.scrollIntoView({block:'nearest'});
  }
  function returnArea(s,active){
    const sourceKey=currentKey();
    const area=el('section',{id:'return-area',cls:'box stack'},hd(2,'貼回問答'),
      para(db.mode==='demo'?'這裡是示例區。你自己的回傳卡也可以貼在這裡，核對時會顯示要存到哪一段討論。':'貼上 GPT 的整張回傳卡。核對後可以先看問答，再決定保存。','small'));
    if(active)area.append(div('actions',btn('複製暫存指令',()=>copy(C.instructions(s,note(),'暫存'),'暫存指令')),btn('複製整理指令',()=>copy(C.instructions(s,note(),'完成'),'整理指令'))));
    const err=el('div',{cls:'error',id:'return-error',role:'alert'});
    const preview=el('div',{cls:'stack',id:'preview','aria-live':'polite'});
    const raw=el('textarea',{id:'return-text',rows:5,placeholder:'貼上 GPT 給你的暫存卡或完成卡。','aria-describedby':'return-error',spellcheck:'false',oninput:()=>{
      s.raw=raw.value;preview.replaceChildren();err.replaceChildren();raw.removeAttribute('aria-invalid');
      R.trackDraft(db,book.notes,sourceKey);
      const control=$('home-round-action');if(control)control.replaceWith(homeRoundAction());
      if(!store())err.textContent='目前無法保存這份貼文草稿。請先保留 GPT 回傳的原文。';
    }});raw.value=s.raw;
    function problem(e){
      preview.replaceChildren();
      const request='請用我們已完成的這輪問答，修正上一張心知閱讀回傳卡的格式。網站提示「'+e.message+
        '」。請沿用這串對話原討論包的討論ID、討論包ID、選段ID與原狀態，按原順序保留逐字發言。問答每則使用「角色」（我或 GPT）與「內容」，候選每項使用「類型」「內容」「依據」「依據原句」「行動」。只輸出一個有效的 JSON 物件，字串中的引號與換行請正確跳脫。';
      errorHere(err,e.message,raw);
      if(raw.value.trim())err.append(div('actions',btn('複製格式修正指令',()=>copy(request,'格式修正指令'),'secondary')));
    }
    function show(item){preview.replaceChildren(item);reveal(item);}
    function showExisting(target){
      show(div('return-box stack-tight',hd(3,'這一輪已經保存'),para('可以直接回看「'+noteLabel(target)+'」的問答。'),
        btn('查看已保存的討論',()=>{R.select(db,target);nav('results');},'primary')));
    }
    function noteLabel(t){return (t.mode==='demo'?'示例討論':'我的討論')+' · '+book.notes.find(n=>n.id===t.noteId).label;}
    async function saveCard(text,mode,sc,control){
      control.disabled=true;
      try{
        const persist=()=>{
          const stored=localStorage.getItem(key);
          const next=JSON.parse(stored||JSON.stringify(db));hubModel.init(next);
          const card=R.save(next,book.notes,text,sourceKey,mode,sc);
          delete (next.mode==='demo'?next.mind.demo:next.mind).resumeItem;
          localStorage.setItem(key,JSON.stringify(next));db=next;storageOK=true;$('warning').hidden=true;
          const origin=parents.at(-1);
          if(origin?.page==='read'&&(origin.key!==currentKey()||origin.mode!==db.mode)){
            parents=[...parents.slice(0,-1),{...locationFor('read'),anchor:'reading-selection'}];
          }
          render();syncRoute();flash((card.status==='完成'?'本輪討論已完成。':'')+(mode==='demo'?'示例問答':'你的問答')+'已保存到「'+note().label+'」。'+(card.pending.length?'有 '+card.pending.length+' 筆候選的依據待核對。':''));
          topOfPage();
        };
        if(navigator.locks?.request)await navigator.locks.request(key,persist);else persist();
      }catch(e){
        control.disabled=false;
        errorHere(err,e.name==='QuotaExceededError'||e.name==='SecurityError'?'瀏覽器未能寫入本機紀錄。輸入框保留著整張卡，請先複製備份。':e.message);
      }
    }
    function inspect(plan,mode,sc){
      try{
        const target=R.destination(plan,mode,sc),text=raw.value;
        if(R.savedRound(target,plan.d.討論包ID)){showExisting(target);return;}
        const card=C.check(text,target.thread,plan.note,sc);
        const previewTitle=target.mode==='my'?'將存到我的討論':'將存到示例討論';
        const saveButton=btn(card.status==='暫存'?'保存暫存卡':'保存完成卡',()=>saveCard(text,mode,sc,saveButton),'primary');
        show(div('return-box stack-tight',hd(3,previewTitle+' · '+plan.note.label),para(C.scopes[sc]+' · '+card.status+'卡','small'),
          details('查看本輪 '+card.turns.length+' 則問答',transcript(card.turns)),
          card.next?para('下次從這裡　'+card.next):null,
          card.status==='完成'?para(card.candidates.length+' 筆候選可供挑選。'+(card.pending.length?'另有 '+card.pending.length+' 筆依據待核對，保存後可以對照原句補上。':''),'small'):null,
          div('actions',saveButton)));
      }catch(e){problem(e);}
    }
    function checkCard(){
      preview.replaceChildren();err.replaceChildren();raw.removeAttribute('aria-invalid');
      try{
        const plan=R.locate(db,book.notes,raw.value);
        if(plan.known&&!plan.chooseOwner){inspect(plan,plan.known.mode,plan.scope);return;}
        const mode=plan.sample?'demo':'my';
        const heading=plan.chooseOwner?'這輪用的是示例討論包':'找到了「'+plan.note.label+'」的回傳卡';
        const info=plan.chooseOwner?'如果卡裡記的是你實際和 GPT 說過的話，可以把這輪問答帶回自己的紀錄。':
          (plan.sample?'這張卡帶有內建示例問答，可以帶回示例區。':'這個瀏覽器找不到原討論包。確認是你的問答後，可以按原卡的識別碼保存一份獨立討論。');
        let sc=plan.scope||'unknown';
        const box=div('return-box stack-tight',hd(3,heading),para(info,'small'));
        if(!plan.scope)box.append(label('return-scope','原討論包帶了哪一部分？'),
          selectControl('return-scope',Object.entries(C.scopes),sc,v=>{sc=v;err.replaceChildren();}));
        const take=btn(mode==='my'?'這是我的討論，核對內容':'核對示例內容',()=>{
          if(!sc){err.textContent='請先選擇原討論包所寫的範圍。';$('return-scope').focus();return;}
          inspect(plan,mode,sc);
        },'primary');
        box.append(div('actions',take,plan.chooseOwner?btn('留在示例討論',()=>inspect(plan,'demo',sc),'ghost'):null));show(box);
      }catch(e){problem(e);}
    }
    area.append(div('stack-tight',label('return-text','GPT 回傳卡'),raw),div('actions',btn('核對回傳卡',checkCard,'primary',{id:'check-return'})),err,preview);
    if(db.mode==='demo')area.append(div('actions',btn('填入完成卡示例',()=>changeMode('demo','完成'),'ghost'),btn('填入暫存卡示例',()=>changeMode('demo','暫存'),'ghost')));
    else if(active)area.append(sampleLinks());
    return area;
  }
  function threadPicker(){
    const options=R.sessions(db).filter(t=>t.mode===db.mode&&t.noteId===note().id&&t.scope===scope());
    if(options.length<2)return null;
    return div('stack-tight',label('thread-picker','這個選段的討論'),selectControl('thread-picker',options.map(t=>{
      const hint=t.thread.rounds[0]?.turns.find(turn=>turn.role==='我')?.text||t.thread.question;
      const title=t.thread.recovered?'從回傳卡帶回':'原本的討論';
      return [t.key,title+(hint?' · '+hint.slice(0,28):'')];
    }),currentKey(),key=>{R.select(db,options.find(t=>t.key===key));store();render();syncRoute();flash('');}));
  }
  function otherDrafts(){
    const drafts=R.sessions(db).filter(t=>t.key!==currentKey()&&t.thread.raw?.trim()&&!isStoredExample(t.thread));
    if(!drafts.length)return null;
    return details('找回先前貼上的卡（'+drafts.length+'）',drafts.map(t=>{
      const name=book.notes.find(n=>n.id===t.noteId)?.label||t.noteId;
      return btn('核對'+(t.mode==='demo'?'示例區':'我的討論')+'裡的草稿 · '+name+' · '+C.scopes[t.scope],()=>{
        openThread(t,'talk',true);
      },'ghost');
    }));
  }
  function homeRoundAction(){
    const key=currentKey(),s=session(),shown=R.resume(db,db.mode);
    const listed=shown?.key===key&&(shown.kind==='draft'||shown.packId===s.pack?.id);
    const control=btn(listed?'先收起來':'下次接著談',()=>{
      if(listed)R.dismiss(db,db.mode,shown);
      else R.pin(db,key);
      delete mindState().resumeItem;
      store();render();flash(listed?'已從首頁收起，問答仍在這段閱讀筆記。':'已放到心知首頁，下次可以從這輪接著談。');
    },'ghost',{id:'home-round-action'});
    return control;
  }
  function talk(){
    const s=session(),n=note(),sc=scope();
    const info=bookInfo(n);
    const right=div('right stack',details('查看本輪選段與來源',...sourceParts(n,sc),para(info.source+' · 第 '+info.read+' 次閱讀 · '+(n.location||'頁碼未記錄'),'small')),
      details('GPT 何時會收斂？',
        para('你用自己的話回答，再說出一個理由、例子、區別、適用界線或待查之處，GPT 就可以小結。它會先問「這輪可以整理成完成卡嗎？」你同意後才會出卡。','small'),
        para('新的討論包和續談包都已帶入這個規則。已經在 ChatGPT 談到一半，可以把提示貼回同一串對話。','small'),
        div('actions',btn('複製收斂提示',()=>copy(C.convergenceUpdate,'收斂提示')),
          btn('手動選取提示',()=>manualCopy(C.convergenceUpdate,'收斂提示原文'),'ghost'))));
    const picker=threadPicker(),drafts=otherDrafts();if(picker)right.prepend(picker);if(drafts)right.prepend(drafts);
    const active=s.pack&&!s.rounds.some(r=>r.packId===s.pack.id);
    if(!s.pack)right.append(questionForm(s));
    else if(s.rounds.some(r=>r.packId===s.pack.id)){
      const last=s.rounds.at(-1);
      right.append(div('box stack-tight',pill('第 '+last.seq+' 輪 · 已'+last.status),hd(2,last.status==='暫存'?'這段討論可以繼續':'本輪討論已完成'),
        last.next?para('下次從這裡　'+last.next,'alt'):null,div('actions',
          btn(last.status==='暫存'?'接著談這一段':'開新一輪',()=>{s.pack=null;s.question='';store();render();flash(last.status==='暫存'?'續談包會帶入上次的問答與續談點。':'前一輪已保存在問答紀錄。可以從新的問題開始。');},'primary'),
          last.status==='暫存'?homeRoundAction():null,
          btn('查看討論成果',()=>nav('results'))),db.mode==='my'?sampleLinks():null));
    }else{
      const packet=C.buildPacket(info,n,sc,s);
      right.append(div('box stack-tight',pill('第 '+s.pack.sequence+' 輪'),hd(2,'把討論帶去 ChatGPT'),
        para('先複製，再開啟 ChatGPT 貼上。談完後回這裡貼卡，這頁便會留下本輪問答。'),
        div('actions',btn(s.rounds.at(-1)?.status==='暫存'?'複製續談包':'複製討論包',()=>copy(packet,'討論包'),'primary'),a('開啟 ChatGPT ↗','https://chatgpt.com/','link-btn'),homeRoundAction()),
        details('查看帶出的討論內容',para(packet,'preserve small'))),returnArea(s,true));
    }
    if(!active){
      const fold=details('貼回已有的回傳卡',returnArea(s,false));
      fold.open=!!s.raw;right.append(fold);
    }
    const hist=history(s);if(hist)right.append(hist);
    return div('layout',side(true),right);
  }
  function evidence(s,p){
    if(p.method==='manual')return details('回看原句',para(p.originLabel,'small'),para(p.quote,'note-quote preserve'));
    const r=s.rounds.find(x=>x.packId===p.packId);
    return details('回看依據與問答',para('第 '+(r?.seq||1)+' 輪 · '+p.originLabel,'small'),para(p.quote,'note-quote preserve'),
      r?transcript(r.turns,p.anchor):null);
  }
  function typeLabel(p){return p.type==='觀點'?'我的觀點':'洞察卡';}
  function pendingEvidence(s,round,item){
    const n=note(),sc=scope(),refs=C.anchors(n,sc,round.turns),original=item.original||{};
    const id='fix-'+round.seq+'-'+item.index;
    const err=el('div',{cls:'error',role:'alert'});
    const type=selectControl(id+'-type',[['觀點','觀點'],['洞察卡','洞察卡']],original.類型==='洞察卡'?'洞察卡':'觀點',()=>{});
    const text=el('textarea',{id:id+'-text',rows:2});text.value=typeof original.內容==='string'?original.內容:'';
    const quote=el('textarea',{id:id+'-quote',rows:2});quote.value=typeof original.依據原句==='string'?original.依據原句:'';
    const passage=para('','note-quote preserve');
    const selected=Object.hasOwn(refs,original.依據)?original.依據:'';
    function updateSource(anchor){passage.textContent=refs[anchor]?.text||'';passage.hidden=!anchor;}
    const anchor=selectControl(id+'-anchor',[['','選擇筆記或發言'],...Object.entries(refs).map(([k,r])=>[k,k+' · '+r.label+' · '+r.text.slice(0,22)])],selected,updateSource);
    updateSource(selected);
    const panel=details('核對候選 '+(item.index+1)+' · '+(text.value||'未填候選內容'),para(item.reason,'small'),
      label(type.id,'候選類型'),type,label(text.id,'候選文字'),text,
      label(anchor.id,'這句話出自哪裡？'),anchor,passage,
      btn('引用所選的整則原文',()=>{if(anchor.value){quote.value=refs[anchor.value].text;err.textContent='';}else{anchor.focus();}},'ghost'),
      label(quote.id,'依據原句'),quote,err,btn('核對並放入待選',()=>{
        try{
          C.repairCandidate(s,n,sc,round.packId,item.index,{類型:type.value,內容:text.value,依據:anchor.value,依據原句:quote.value,行動:original.行動});
          store();render();flash('依據已核對。你可以決定是否留下這筆候選。');
        }catch(e){errorHere(err,e.message);}
      },'secondary'));
    return div('request stack-tight',panel);
  }
  function candidate(s,p){
    const serial=s.proposals.indexOf(p);
    const fieldId='p-'+serial,err=el('div',{cls:'error',role:'alert'});
    const originLabel=p.origin==='本人'?(db.mode==='demo'?'依據・示例人物發言':'依據・你的發言'):p.origin==='GPT'?'GPT 提議・待本人確認':'從作者原文延伸';
    const form=el('article',{cls:'request stack-tight'},div('candidate-head',hd(3,typeLabel(p)),pill(originLabel)),evidence(s,p));
    const text=el('textarea',{id:fieldId,rows:3,oninput:e=>{p.text=e.target.value;store();err.textContent='';}});text.value=p.text;
    form.append(label(fieldId,'想留下的文字'),text);
    if(p.type==='洞察卡'){
      const action=el('textarea',{id:fieldId+'-action',rows:2,oninput:e=>{p.action=e.target.value;store();err.textContent='';}});action.value=p.action;
      form.append(label(fieldId+'-action','我想觀察或執行的事'),action);
    }
    const share=el('input',{type:'checkbox',checked:p.share,onchange:e=>{p.share=e.target.checked;store();}});
    form.append(el('label',{cls:'checkline'},share,'開放給其他場域取用'),err,div('actions',btn('確認存成'+typeLabel(p),()=>{
      try{C.adopt(s,p.id);store();render();flash('已保存'+typeLabel(p)+'，來源和依據可一起回查。');}
      catch(e){errorHere(err,e.message);}
    },'primary'),btn('略過',()=>{p.status='已略過';store();render();flash('已略過，仍可從下方重新挑選。');},'ghost')));
    return form;
  }
  function product(s,p){
    const n=note(),info=bookInfo(n);
    const share=el('input',{type:'checkbox',checked:p.share,onchange:e=>{p.share=e.target.checked;store();render();flash(p.share?'已開放這筆測試成果供取用。':'已關閉新的取用。');}});
    const card=el('article',{id:'product-'+p.id,cls:'product stack-tight'},div('candidate-head',hd(3,typeLabel(p)),pill(db.mode==='demo'?'示例成果':'本人已確認')),
      para(p.text,'preserve body-md'),p.type==='洞察卡'?para('待觀察／執行　'+p.action,'alt preserve'):null,para([p.method==='manual'?'手動留下':'討論成果',info.book,'第 '+info.read+' 次閱讀',n.label,n.location,'v'+p.version].filter(Boolean).join(' · '),'small'),evidence(s,p),
      el('label',{cls:'checkline'},share,'開放給其他場域取用'));
    if(p.share)card.append(div('actions',
      btn('複製成果與出處',()=>copy(C.productText(info,n,s,p),'成果與出處')),
      ['織光堂','聊解室'].map(place=>btn(p.uses.some(x=>x.place===place)?place+'已取用':'在'+place+'試用',()=>{
        const added=C.useItem(p,place);store();render();flash(added?'已留下'+place+'的模擬取用紀錄。':'這個場域已經取用這一版。');
      }))));
    card.append(hub.schedule(null,p));
    if(p.uses.length)card.append(details('已取用的場域（'+p.uses.length+'）',p.uses.map(u=>para(u.place+' · v'+u.version+'　'+u.text,'small'))));
    return card;
  }
  function results(){
    const s=session(),pending=s.proposals.filter(p=>p.status==='待選'),skipped=s.proposals.filter(p=>p.status==='已略過');
    const right=div('right stack');
    const picker=threadPicker();if(picker)right.append(picker);
    const unresolved=s.rounds.flatMap(r=>(r.pending||[]).map(item=>({r,item})));
    if(!pending.length&&!s.products.length&&!skipped.length&&!unresolved.length){
      const done=s.rounds.at(-1)?.status==='完成';
      right.append(div('box stack-tight',hd(2,done?'本輪討論已完成':'這一段還沒有成果'),para(done?'問答已保存，這一輪沒有待挑選的候選。可以在下方回看當時的對話。':s.rounds.length?'已保存的問答可以接續。想留下觀點或洞察卡時，請 GPT 輸出完成卡。':'把 GPT 的完成卡帶回來，就能在這裡挑選與改寫。'),div('actions',btn('前往 GPT 討論',()=>nav('talk'),'primary'))));
    }
    if(pending.length)right.append(hd(2,'待你挑選（'+pending.length+'）'),...pending.map(p=>candidate(s,p)));
    if(unresolved.length)right.append(hd(2,'依據待核對（'+unresolved.length+'）'),...unresolved.map(({r,item})=>pendingEvidence(s,r,item)));
    if(s.products.length)right.append(hd(2,'已留下的成果（'+s.products.length+'）'),...s.products.map(p=>product(s,p)));
    if(skipped.length)right.append(div('box',details('已略過（'+skipped.length+'）',skipped.map(p=>div('stack-tight',para(p.text),btn('重新挑選',()=>{p.status='待選';store();render();flash('已放回待選清單。');},'ghost'))))));
    const hist=history(s);if(hist)right.append(hist);
    return div('layout',side(true),right);
  }
  function openAdd(context={}){
    if(db.tab==='clip'){$('clip-files')?.click();return;}
    const dialog=$('add-dialog'),body=$('add-content'),heading=$('add-title');
    const reading=['shelf','read','talk','results','cards','visits'].includes(db.tab);
    if(reading){
      heading.textContent='新增閱讀選段';body.replaceChildren(para(bookInfo(note()).book,'small'),
        btn('從行光剪藏加入截圖',()=>{dialog.close();nav('clip');},'secondary'),newNoteForm(true));
    }else if(db.tab==='map'){
      heading.textContent='道場新增';body.replaceChildren(a('開啟正式版新增 ↗','https://lumen-dojo.up.railway.app/add','link-btn'));
    }else{
      const state=mindState(),item=db.tab==='item'?state.items.find(i=>i.id===state.item):null;
      const field=el('textarea',{id:'quick-record',rows:4,maxlength:6000}),error=el('p',{cls:'error',role:'alert'});
      const stages=hubModel.pathFor(item);
      let stage='',topic='';
      const stageChoices=[['','暫不指定'],...stages.map(s=>[s.name,s.name])];
      const topicBox=div('stack-tight');
      function pickStage(name){
        stage=name;const ref=stages.find(s=>s.name===stage),choices=ref?.topics||[];
        topic=choices.some(t=>t.name===context.topic)?context.topic:'';
        topicBox.replaceChildren(...(ref?[label('record-topic','練習主題'),selectControl('record-topic',[['','暫不指定'],...choices.map(t=>[t.name,t.name])],topic,v=>{topic=v;})]:[]));
      }
      pickStage(stages.some(s=>s.name===context.stage)?context.stage:'');
      const pathFields=stages.length?div('stack-tight',label('record-stage','練習階段'),selectControl('record-stage',stageChoices,stage,pickStage),topicBox):null;
      heading.textContent=item?'新增學習紀錄':'新增修習紀錄';
      body.replaceChildren(div('stack-tight',para(item?item.name:'修習所','small'),pathFields,label(field.id,'這次練了什麼？'),field,error,btn('保存紀錄',()=>{
        const text=field.value.trim();if(!text){error.textContent='請寫下一句這次的練習。';field.focus();return;}
        const logs=item?item.logs:(state.practiceLogs??=[]);logs.unshift({date:hubModel.day(),text,...(stage?{stage}:{}),...(topic?{topic}:{})});
        if(!store()){logs.shift();error.textContent='裝置未能保存，請保留這段文字。';return;}
        dialog.close();if(db.tab==='practice'||db.tab==='item'&&state.itemTab==='logs')render();
        flash(item?'已保存到「'+item.name+'」的學習紀錄。':'已保存到修習所的修習紀錄。');
      },'primary')));
    }
    dialog.showModal();
  }
  const hub=hubModel.create({db:()=>db,C,R,book,bookInfo,bookList,el,div,para,hd,btn,pill,details,label,selectControl,store,render,nav,flash,openNote,openThread,openProduct,goUp,parentLabel,syncRoute,openAdd});
  const clipView=window.ReadingClipView.create({el,div,para,hd,btn,label,details,mode:()=>db.mode,bookList,openNote,
    defaultBook:()=>['read','talk','results'].includes(parents.at(-1)?.page)?bookInfo(note()):mindState().lastClipBook,
    findNote:id=>mindState().notes.find(n=>n.clipId===id),
    saveNote:async (n,open=true)=>{
      const saved=await commitReading(n.owner,(state,next)=>{
        const old=state.notes.find(item=>item.clipId===n.clipId);
        if(old)return old;
        state.notes.push(n);next.scopes[n.id]=n.reflection?'both':'excerpt';
        state.lastClipBook={book:n.bookTitle,read:n.readNumber};return n;
      });
      if(!open)return;
      openNote(saved);flash('已將「'+saved.label+'」存到《'+saved.bookTitle+'》。');
      $('notice').append(btn('回到截圖核對',()=>nav('clip'),'text-link'));
    }});
  function render(){
    clipView.dispose();
    hubModel.init(db);book.notes=[...referenceNotes,...db.mind.notes,...db.mind.demo.notes];R.initResume(db,book.notes);
    const funcs={map:hub.map,practice:hub.practice,shelf:hub.shelf,clip:clipView.page,home:hub.home,items:hub.items,item:hub.item,read:reading,talk,results,cards:hub.cards,visits:hub.visits};
    if(!Object.hasOwn(funcs,db.tab))db.tab='home';
    if(db.tab==='item'&&!mindState().items.some(i=>i.id===mindState().item))db.tab='items';
    const isBook=['read','talk','results'].includes(db.tab);
    const section=isBook||['shelf','clip'].includes(db.tab)?'read':db.tab==='visits'?'cards':db.tab==='item'?'items':db.tab;
    document.body.dataset.section=section;document.body.dataset.page=db.tab;
    $('mode-tag').textContent=db.mode==='demo'?'示例模式':'模擬版';
    $('hero').replaceChildren(hub.hero(db.tab));$('book-nav').hidden=!isBook;
    document.title=$('page-title').textContent+'｜心知模擬版';
    const bar=$('sample-banner');bar.hidden=db.mode!=='demo';bar.className='sample-banner';
    bar.replaceChildren(...(db.mode==='demo'?[el('span',{},'正在試用示例人物的問答與成果。'),btn('返回我的討論',()=>changeMode('my'),'ghost')]:[]));
    document.querySelectorAll('[data-tab]').forEach(b=>{
      if(b.dataset.tab===db.tab)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');
    });
    $('app').replaceChildren(funcs[db.tab]());
  }
  document.addEventListener('click',e=>{
    const link=e.target.closest('a[href^="#"]');if(!link||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;
    const page=link.hash.slice(1);if(pages.includes(page)){e.preventDefault();nav(page);}
  });
  document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>nav(b.dataset.tab)));
  window.addEventListener('popstate',e=>{
    const state=e.state;
    if(state?.page===route())restore(state);
    db.tab=route();parents=state?.page===db.tab&&Array.isArray(state.parents)?state.parents:trail.defaults(db.tab,locationFor());
    render();store();flash('');returnFocus(state?.anchor);
  });
  function fitKeyboard(){
    const viewport=window.visualViewport;
    const editor=document.activeElement?.matches('input,textarea,select,[contenteditable="true"]');
    document.body.toggleAttribute('data-keyboard',!!(viewport&&editor&&window.innerHeight-viewport.height>140));
  }
  window.visualViewport?.addEventListener('resize',fitKeyboard);
  document.addEventListener('focusin',fitKeyboard);
  document.addEventListener('focusout',()=>requestAnimationFrame(fitKeyboard));
  $('global-add').onclick=openAdd;
  $('close-add').onclick=()=>$('add-dialog').close();
  $('close-copy').onclick=()=>{const d=$('copy-dialog');if(typeof d.close==='function')d.close();else d.removeAttribute('open');};
  $('select-copy').onclick=()=>{const t=$('copy-text');t.focus();t.select();t.setSelectionRange(0,t.value.length);};
  window.addEventListener('storage',e=>{
    if(e.key!==key||!e.newValue)return;
    try{
      const now=JSON.parse(e.newValue);
      if(now.v===1&&now.sessions&&now.scopes){
        const position=locationFor();db=now;hubModel.init(db);restore(position);
        render();flash('已載入另一個分頁保存的進度。');
      }
    }catch{}
  });
  hubModel.init(db);book.notes=[...referenceNotes,...db.mind.notes,...db.mind.demo.notes];
  db.tab=route();const initial=window.history.state;
  if(initial?.page===db.tab)restore(initial);
  parents=initial?.page===db.tab&&Array.isArray(initial.parents)?initial.parents:trail.defaults(db.tab,locationFor());
  render();store();window.history.replaceState({...locationFor(),parents,id:initial?.id||C.uid(),chain:initial?.chain||C.uid(),index:initial?.index||0,anchor:initial?.anchor},'');

})();
