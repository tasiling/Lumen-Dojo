# 心知閱讀討論試習 v11

開啟本目錄的靜態首頁，從「打開書架」選《走一段陌生的路》，接著測試選段、討論包、回傳卡與成果回訪。「心理學」學習路徑的第一個主題可連回相關選段。示例書籍、摘錄、讀後筆記和學習計畫皆為虛構資料。新的個人輸入與截圖存在目前瀏覽器中。

在本目錄啟動預覽與測試。

```sh
python3 -m http.server 8011 --bind 127.0.0.1
# 瀏覽 http://127.0.0.1:8011/
```

```sh
node --test tests/*.test.cjs
```

## 截圖 OCR

要測試橫排或直排繁體中文辨識，先從行光道場 repo 根目錄執行 `npm ci`，再執行此目錄下的 `prepare-ocr.mjs`（例如 `node simulations/reading-discussion/prepare-ocr.mjs`，依檔案實際位置調整）。請保持工作目錄在 repo 根目錄，以便腳本找到套件。

腳本會複製 repo 鎖定的 Tesseract.js 7.0.0 與 WebAssembly 引擎，並從上游固定 commit 下載這個版本使用的兩份 tessdata_fast 模型。兩份模型經 SHA-256 核對後存入本目錄的 `ocr/`。準備完成後，從書架進入「從行光剪藏加入截圖」，可在本機辨識、校對、保存選段。討論與書架可在準備 OCR 之前使用。介面上另開正式站或 ChatGPT 的連結需要網路。
