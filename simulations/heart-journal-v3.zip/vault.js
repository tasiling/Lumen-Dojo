/* Local example records use a browser-generated key for the existing persistence flow. */
(() => {
  "use strict";
  const encode = bytes => {
    let binary="";
    for(let i=0;i<bytes.length;i+=0x4000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x4000));
    return btoa(binary);
  };
  const decode = str => Uint8Array.from(atob(str),c=>c.charCodeAt(0));
  const cryptoApi=()=>globalThis.crypto;
  async function openKey(base64){
    return cryptoApi().subtle.importKey("raw",decode(base64),{name:"AES-GCM"},false,["encrypt","decrypt"]);
  }
  async function seal(key,id,db){
    const iv=cryptoApi().getRandomValues(new Uint8Array(12));
    const data=new TextEncoder().encode(JSON.stringify(db));
    const cipher=await cryptoApi().subtle.encrypt({name:"AES-GCM",iv,additionalData:new TextEncoder().encode(id)},key,data);
    return JSON.stringify({v:1,iv:encode(iv),data:encode(new Uint8Array(cipher))});
  }
  async function unseal(key,id,record){
    const envelope=JSON.parse(record);
    if(envelope.v!==1||!envelope.iv||!envelope.data)throw Error("format");
    const plain=await cryptoApi().subtle.decrypt({name:"AES-GCM",iv:decode(envelope.iv),additionalData:new TextEncoder().encode(id)},key,decode(envelope.data));
    return JSON.parse(new TextDecoder().decode(plain));
  }
  const api={openKey,seal,unseal};
  globalThis.HeartVault=api;
  if(typeof module!=="undefined"&&module.exports)module.exports=api;
})();
