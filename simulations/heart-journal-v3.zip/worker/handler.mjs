// The Sites dispatcher supplies identity headers after authenticating the visitor.
const guardHeaders = {
  "Cache-Control":"private, no-store, max-age=0",
  "Vary":"Cookie",
  "Referrer-Policy":"no-referrer",
  "X-Content-Type-Options":"nosniff",
  "Cross-Origin-Resource-Policy":"same-origin"
};
function reply(body, status, type, extra) {
  return new Response(body,{status,headers:{...guardHeaders,"Content-Type":type,...extra}});
}
function reject(status,message) {
  return reply(JSON.stringify({error:message}),status,"application/json; charset=utf-8");
}
function conversationHistory(data,env){
  const count=Number(env.HEART_PREVIEW_HISTORY_COUNT||0);
  if(!count)return {};
  if(!Number.isInteger(count)||count<1||count>32)throw Error();
  let value="";
  for(let i=1;i<=count;i++){
    const chunk=env["HEART_PREVIEW_HISTORY_"+i];
    if(typeof chunk!=="string"||!chunk.length)throw Error();
    value+=chunk;
  }
  const record=JSON.parse(value);
  const matches=data.sources.filter(s=>s.ref.kind==="conversation"&&s.title===record.title&&s.date===record.date);
  if(matches.length!==1||record.v!==1||!Array.isArray(record.groups)||!record.groups.length)throw Error();
  return {[matches[0].id]:record.groups};
}
function personalExamples(request, env) {
  if(request.method!=="GET")return reject(405,"無法使用這個操作。");
  const identity=request.headers.get("oai-authenticated-user-id")?.trim();
  const email=request.headers.get("oai-authenticated-user-email")?.trim().toLowerCase();
  if(!identity||!email)return reject(401,"請先登入你的 ChatGPT 帳號。");
  const owner=env.HEART_PREVIEW_OWNER?.trim().toLowerCase();
  if(!owner)return reject(503,"個人紀錄暫時無法載入。");
  if(owner!==email)return reject(403,"這個帳號無法開啟這份個人紀錄。");
  if(request.headers.get("X-Heart-Preview")!=="1"||request.headers.get("Sec-Fetch-Site")==="cross-site")return reject(403,"請從心・情頁面開啟。");
  try{
    const data=JSON.parse(env.HEART_PREVIEW_SOURCES);
    if(data.v!==1||!data.storageId||!Array.isArray(data.sources)||!data.sources.length||!env.HEART_PREVIEW_DEVICE_KEY)throw Error();
    return reply(JSON.stringify({v:1,storageId:data.storageId,sources:data.sources,histories:conversationHistory(data,env),deviceKey:env.HEART_PREVIEW_DEVICE_KEY}),200,"application/json; charset=utf-8");
  }catch{return reject(503,"個人紀錄暫時無法載入。");}
}
export function makeSite(assets) {
  return {async fetch(request,env){
    const url=new URL(request.url);
    if(url.pathname==="/api/personal-examples")return personalExamples(request,env);
    if(!["GET","HEAD"].includes(request.method))return reject(405,"無法使用這個操作。");
    const path=url.pathname==="/"?"/index.html":url.pathname;
    const file=Object.hasOwn(assets,path)?assets[path]:null;
    if(!file)return reject(404,"找不到這個頁面。");
    return reply(request.method==="HEAD"?null:file.body,200,file.type,{
      "Content-Security-Policy":"default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; base-uri 'none'; form-action 'none'; object-src 'none'"
    });
  }};
}
