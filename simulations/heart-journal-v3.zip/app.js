(() => {
  "use strict";
  const M=globalThis.HeartModel, A=globalThis.HeartArchive, $=id=>document.getElementById(id);
  const enc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const paths={
    sun:'<circle cx="12" cy="12" r="5"/><path d="M12 1v3m0 16v3M1 12h3m16 0h3M4.2 4.2l2.1 2.1m11.4 11.4 2.1 2.1M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>',
    heart:'<path d="M20.6 4.7a5.2 5.2 0 0 0-7.4 0L12 5.9l-1.2-1.2a5.2 5.2 0 0 0-7.4 7.4L12 20.7l8.6-8.6a5.2 5.2 0 0 0 0-7.4Z"/>',
    pen:'<path d="m4 15-1 6 6-1L21 8l-5-5L4 15Zm9-9 5 5M4 15l5 5"/>',
    talk:'<path d="M21 11c0 5-5 8-11 7l-6 3 2-5a7 7 0 0 1-3-6c0-4 4-7 9-7s9 3 9 8Z"/><path d="M8 10h1m3 0h1m3 0h1"/>',
    turn:'<path d="M4 8h10a5.5 5.5 0 0 1 0 11h-2M8 4 4 8l4 4"/>',
    right:'<path d="m9 5 7 7-7 7"/>',arrow:'<path d="M4 12h15m-6-6 6 6-6 6"/>',back:'<path d="m14 5-7 7 7 7"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v5m10-5v5M3 11h18"/>',
    plus:'<path d="M12 4v16M4 12h16"/>',week:'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M9 3v18m6-18v18M3 9h18M3 15h18"/>',
    book:'<path d="M12 5C8 3 5 3 2 4v15c4-1 7 0 10 2 3-2 6-3 10-2V4c-3-1-6-1-10 1Zm0 0v16"/>',
    bookmark:'<path d="M6 3h12v18l-6-4-6 4z"/>',lock:'<rect x="5" y="10" width="14" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2"/>',
    timer:'<circle cx="12" cy="14" r="7.5"/><path d="M12 2v4m-3-4h6m3 5 2-2m-8 5v4l3 1"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.5"/>',close:'<path d="m5 5 14 14M19 5 5 19"/>',
    copy:'<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M15 8V4a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h4"/>',
    search:'<circle cx="10" cy="10" r="6.5"/><path d="m15 15 6 6"/>',check:'<path d="m3 12 6 6L21 6"/>',
    pause:'<path d="M8 5v14m8-14v14"/>',edit:'<path d="m3 17 1 4 4-1L20 8l-4-4L3 17Z"/>',
    leaf:'<path d="M5 19c-2-7 1-14 15-15 0 12-5 17-12 14m-3 2L16 9"/>',
    link:'<path d="m9 15 6-6m-4-1 2-2a4 4 0 0 1 6 6l-3 3m-3 1-2 2a4 4 0 0 1-6-6l3-3"/>'
  };
  const ico=(key)=>'<svg class="i" viewBox="0 0 24 24" aria-hidden="true">'+(paths[key]||"")+'</svg>';
  const btn=(a,label,opt={})=>'<button type="button" data-act="'+a+'"'+(opt.id?' data-id="'+enc(opt.id)+'"':'')+(opt.extra||'')+' class="'+(opt.cls||'btn')+'">'+(opt.icon?ico(opt.icon):'')+enc(label)+(opt.after?ico(opt.after):'')+'</button>';
  const days=["日","一","二","三","四","五","六"];
  const dateLabel=(d,weekday=false)=>{const [y,m,day]=String(d).split("-").map(Number);return m+" 月 "+day+" 日"+(weekday?"・星期"+days[new Date(y,m-1,day).getDay()]:"");};
  const legacyKey="lumen-dojo.public-heart-example.offline-v1";
  const clone=x=>JSON.parse(JSON.stringify(x));
  let baseline=[], db=null, deviceKey=null, keepKey="", seen="", storageOK=false, stale=false, busy=false, ready=false;
  let histories={},transcriptDraft="";
  const groupsFor=id=>histories[id]||[];
  const validDb=v=>v?.version===1&&Array.isArray(v.sources)&&Array.isArray(v.threads)&&Array.isArray(v.links);
  const sourceCopy=()=>M.fromSources(baseline);
  const sourceOriginal=id=>baseline.find(s=>s.id===id);
  async function fetchMine(){ return globalThis.heartExample(); }
  function accessScreen(title,message,deviceIssue=false){
    ready=false;$("top").replaceChildren();$("nav").replaceChildren();$("notice").replaceChildren();if($("dialog").open)$("dialog").close();
    $("main").innerHTML='<div class="container inner"><div class="page-head"><h1>'+enc(title)+'</h1><p>'+enc(message)+'</p></div><div class="actions">'+btn("retry-boot","重新讀取",{cls:"btn soft"})+
      (deviceIssue?btn("view-without-device","這次只查看來源",{cls:"link"}):'')+'</div></div>';
  }
  async function initialize(memoryOnly=false){
    ready=false;db=null;baseline=[];histories={};transcriptDraft="";seen="";stale=false;storageOK=false;deviceKey=null;
    let data;
    try{data=await fetchMine();}catch(err){
      const denied=err.status===401||err.status===403;
      accessScreen(denied?"本機示例無法載入":"暫時讀不到你的紀錄",denied?"請在瀏覽器重新開啟本機示例。":"重新整理後可載入本機示例。");return;
    }
    baseline=data.sources;histories=data.histories||{};keepKey="lumen-dojo.public-heart-example.records.v2."+data.storageId;
    db=sourceCopy();
    if(!memoryOnly){
      try{deviceKey=await HeartVault.openKey(data.deviceKey);seen=localStorage.getItem(keepKey)||"";storageOK=true;}catch{storageOK=false;}
      if(storageOK&&seen){
        try{const saved=await HeartVault.unseal(deviceKey,keepKey,seen);if(!validDb(saved))throw Error();db=saved;}
        catch{accessScreen("這台裝置的測試紀錄暫時讀不到","可以先查看原始選段。上次儲存的版本會留在這台裝置。",true);return;}
      }
    }
    ready=true;render();
  }
  async function commit(fn){
    if(!ready||busy)return false;
    if(stale){alertBox("另一個分頁已更新紀錄","請重新載入這個測試頁，再繼續儲存。");return false;}
    busy=true;
    try{
      const next=clone(db);fn(next);
      if(storageOK){
        const encrypted=await HeartVault.seal(deviceKey,keepKey,next);
        const write=()=>{
          if((localStorage.getItem(keepKey)||"")!==seen){stale=true;return false;}
          localStorage.setItem(keepKey,encrypted);seen=encrypted;return true;
        };
        const saved=navigator.locks?.request?await navigator.locks.request(keepKey,write):write();
        if(!saved){alertBox("另一個分頁已更新紀錄","請重新載入後再儲存，輸入仍留在頁面上。");return false;}
      }
      db=next;return true;
    }catch{alertBox("這次沒有儲存","輸入仍在這個頁面上。請確認裝置尚有儲存空間，再按一次儲存。");return false;}
    finally{busy=false;}
  }
  window.addEventListener("storage",e=>{if(e.key===keepKey)stale=true;});
  window.addEventListener("pagehide",e=>{if(e.persisted)document.documentElement.classList.add("checking-identity");});
  window.addEventListener("pageshow",async e=>{
    if(!e.persisted)return;
    try{const data=await fetchMine();if(!keepKey.endsWith("."+data.storageId))throw Error();}
    catch{db=null;baseline=[];histories={};transcriptDraft="";deviceKey=null;accessScreen("請重新開啟示例","請重新載入本機示例後再繼續。");}
    finally{document.documentElement.classList.remove("checking-identity");}
  });
  let trial=null, writer=null, session=null, returned=null, raw="", editor=null, sourceEdit=null, beforeDialog=null, noticeTimer;
  let filter={q:"",date:"",status:"全部"};
  const frames=[{name:"home",args:{}}];let index=0, view=frames[0];
  function rememberFlow(){Object.assign(frames[index],{flow:{writer,session,returned,raw,editor,sourceEdit,trial}});}
  function restoreFlow(frame){if(frame.flow)({writer,session,returned,raw,editor,sourceEdit,trial}=frame.flow);}
  history.replaceState({hj:0},"",location.href);
  const source=id=>db.sources.find(x=>x.id===id);
  const threadsFor=id=>db.threads.filter(x=>x.sourceId===id);
  const thread=id=>db.threads.find(x=>x.id===id);
  const byDate=(a,b)=>b.date.localeCompare(a.date);
  const sortedSources=()=>[...db.sources].sort(byDate);
  const latestThread=id=>[...threadsFor(id)].sort((a,b)=>M.latest(b).date.localeCompare(M.latest(a).date))[0];
  const docTitle={home:"心・情",write:"留下心／情的紀錄",choose:"開始內在覺察",prepare:"這次想談哪一段？",exchange:"把整理帶回來",preview:"核對這次整理",history:"回顧覺察紀錄",detail:"日記與覺察",edit:"編輯這輪整理",sourceEdit:"編輯這篇紀錄",trytalk:"在這裡試談一輪"};
  function go(name,args={},replace=false){
    if(replace){frames[index]={name,args};view=frames[index];history.replaceState({hj:index},"",location.pathname);}
    else{frames.splice(index+1);frames.push({name,args});index=frames.length-1;view=frames[index];history.pushState({hj:index},"",location.pathname);}
    rememberFlow();render(true);
  }
  window.addEventListener("popstate",e=>{if($("dialog").open)$("dialog").close();rememberFlow();const k=e.state?.hj;if(Number.isInteger(k)&&frames[k]){index=k;view=frames[k];restoreFlow(view);render(true);}else{index=0;view=frames[0];render(true);}});
  function toast(s){$("notice").textContent=s;clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>$("notice").textContent="",3100);}
  function modal(title,body){
    const dlg=$("dialog");beforeDialog=document.activeElement;
    $("dialog-body").innerHTML='<div class="between"><h2 id="dialog-title">'+enc(title)+'</h2>'+btn("close","",{cls:"close",icon:"close",extra:' aria-label="關閉"'})+'</div>'+body;
    if(!dlg.open)dlg.showModal();
  }
  $("dialog").addEventListener("close",()=>{if(document.contains(beforeDialog))beforeDialog?.focus?.({preventScroll:true});});
  $("dialog").addEventListener("click",e=>{if(e.target===$("dialog"))$("dialog").close();});
  const alertBox=(title,message)=>modal(title,'<p>'+enc(message)+'</p>'+btn("close","知道了",{cls:"btn soft"}));
  const close=()=>{if($("dialog").open)$("dialog").close();};
  const pageHead=(name,sub="")=>'<div class="page-head"><h1>'+enc(name)+'</h1>'+(sub?'<p>'+enc(sub)+'</p>':'')+'</div>';
  const empty=txt=>'<p class="empty">'+enc(txt)+'</p>';
  function headAndNav(){
    $("top").innerHTML='<div class="head-inner"><button class="brand" type="button" data-act="home" aria-label="行光道場，回心情首頁">'+ico("sun")+'<span><b>行光道場</b><small>修習所</small></span></button><div class="head-right"><span class="head-date">'+dateLabel(M.today(),true)+'</span>'+btn("timer","計時",{cls:"preview-btn",icon:"timer"})+btn("about","本機示例",{cls:"preview-btn",icon:"info"})+'</div></div>';
    const nav=[["today","sun","今天"],["calendar","calendar","行事曆"],["new","plus","新增"],["week","week","週盤"],["history","book","回看"]];
    $("nav").innerHTML='<div class="nav-inner">'+nav.map(([a,ic,l])=>'<button type="button" data-act="'+a+'" class="nav-btn '+(a==="new"?"add ":"")+((a==="new"&&view.name==="write")||(a==="history"&&["history","detail"].includes(view.name))?"active":"")+'"><span class="glyph">'+ico(ic)+'</span><span>'+l+'</span></button>').join("")+'</div>';
  }
  const trail=(home=false)=>'<div class="trail">'+(home?btn("realm","修習所",{cls:"trail-realm"})+ico("right")+'<span>心・情</span>':btn("home","心・情",{cls:"link",icon:"back"})+ico("right")+'<span>'+enc(docTitle[view.name])+'</span>')+'</div>';
  function row(s,action="detail"){
    const t=latestThread(s.id), m=Number(s.date.slice(5,7)), d=Number(s.date.slice(8,10));
    return '<button type="button" data-act="'+action+'" data-id="'+enc(s.id)+'" class="row"><span class="date-box"><b>'+d+'</b><small>'+m+' 月</small></span><span class="row-copy"><span class="row-title">'+enc(s.title||M.head(s.text))+'</span><span class="row-sub">'+enc(s.ref?s.origin:s.category)+' · '+enc(t?M.stateText(t):groupsFor(s.id).length?"覺察對話":s.ref?.kind==="conversation"?"本人原話":s.ref?"原日記選段":M.stateText(t))+'</span></span>'+ico("right")+'</button>';
  }
  const localNote=()=>'<p class="local-note">'+ico("lock")+'<span>'+(storageOK?'這是虛構的日記與問答示例。你做的修改只存到這個瀏覽器。':'原始選段可再開啟。這個瀏覽器目前只能暫留這次修改，關閉頁面後會清除。')+'</span></p>';
  function art(){return '<div class="hero-art" aria-hidden="true"><svg class="orbits" viewBox="0 0 260 260" fill="none" stroke="currentColor" stroke-width="1">'+[34,66,98,130].map(r=>'<circle cx="130" cy="130" r="'+r+'"/>').join("")+'<path d="M130 0v260"/><circle cx="130" cy="130" r="4" fill="currentColor"/></svg><div class="book"><svg class="seal" viewBox="0 0 52 58" fill="none" stroke="currentColor" stroke-width="1.2"><circle cx="26" cy="25" r="17"/><circle cx="26" cy="25" r="10"/><path d="M26 2v44M15 51h22m-18 3h14"/><circle cx="26" cy="25" r="2" fill="currentColor"/></svg><i class="ribbon"></i></div></div>';}
  function firstPersonalCard(s){
    if(groupsFor(s.id).length)return '<article class="resume"><div class="resume-head"><span class="icon-box">'+ico("talk")+'</span><div><div class="meta">'+dateLabel(s.date)+' · '+enc(s.origin)+'</div><h3>'+enc(s.title)+'</h3></div></div><p class="resume-q">從當時寫下的經過開始，回看每一輪怎麼問、怎麼答。</p>'+btn("detail","從頭回看這次覺察",{id:s.id,cls:"link"})+'</article>';
    return '<article class="resume"><div class="resume-head"><span class="icon-box">'+ico(s.ref?.kind==="conversation"?"talk":"book")+'</span><div><div class="meta">'+dateLabel(s.date)+' · '+enc(s.origin)+'</div><h3>'+enc(s.title)+'</h3></div></div><p class="resume-q">'+(s.ref?.kind==="conversation"?"你在那次對話留下的原話，可以選一句接著談。":"查看當時留下的文字，再決定想從哪一句開始。")+'</p>'+btn("detail","查看我的原文",{id:s.id,cls:"link",after:"right"})+'</article>';
  }
  function home(){
    const open=db.threads.filter(t=>!t.archived&&["waiting","paused"].includes(M.latest(t).status)).sort((a,b)=>byDate(M.latest(a),M.latest(b)))[0];
    const s=open&&source(open.sourceId), r=M.latest(open), rows=sortedSources().slice(0,4);
    const featured=sortedSources().find(x=>x.ref?.kind==="conversation")||rows[0];
    return trail(true)+'<section class="hero">'+art()+'<div class="hero-copy"><div class="hero-kicker">'+ico("heart")+'覺察日記</div><h1>心・情</h1><p class="sub">此刻，有什麼想記下來？</p><div class="hero-actions">'+btn("new","留下心／情的紀錄",{cls:"btn primary",icon:"pen"})+btn("choose","開始內在覺察",{icon:"talk"})+'</div></div></section><div class="desk"><section><div class="section-head"><h2>'+(s?"接著上次談":"從示例紀錄開始")+'</h2></div>'+(s?'<article class="resume"><div class="resume-head"><span class="icon-box amber">'+ico("bookmark")+'</span><div><div class="meta">'+dateLabel(r.date)+' · '+enc(M.stateText(open))+'</div><h3>'+enc(s.title)+'</h3></div></div><div class="resume-q"><span>'+(r.status==="waiting"?"目前進度":"上次停在這裡")+'</span>'+enc(r.question||"討論包已暫存，等你把 GPT 的整理貼回來。")+'</div>'+btn("resume",r.status==="waiting"?"回來貼整理":"繼續這次覺察",{cls:"link",id:open.id,after:"arrow"})+'</article>':featured?firstPersonalCard(featured):'<div class="resume">'+empty("可以先留下一篇日記，再從自己的文字開始。")+'</div>')+'</section><section><div class="section-head"><h2>最近的紀錄</h2>'+btn("history","回顧覺察紀錄",{cls:"link",after:"right"})+'</div><div class="history-list">'+(rows.length?rows.map(s=>row(s)).join(""):empty("你寫下的第一篇日記會出現在這裡。"))+'</div></section></div>'+localNote();
  }
  const field=(id,label,control,extra="")=>'<div class="field"><label for="'+id+'">'+label+'</label>'+control+extra+'</div>';
  const tx=(id,value,rows,placeholder="",attrs="")=>'<textarea id="'+id+'" rows="'+rows+'" placeholder="'+enc(placeholder)+'" '+attrs+'>'+enc(value)+'</textarea>';
  const inp=(id,value,type="text",attrs="")=>'<input id="'+id+'" type="'+type+'" value="'+enc(value)+'" '+attrs+'>';
  const chip=(a,id,l,selected)=>btn(a,l,{id,cls:"chip",extra:' aria-pressed="'+Boolean(selected)+'"'});
  const err=id=>'<p class="error" role="alert" id="'+id+'"></p>';
  function writerPage(){
    const w=writer;
    return pageHead("留下心／情的紀錄","一句話也可以。")+ '<section class="card">'+field("wt","此刻想記下什麼？",tx("wt",w.text,6,"從當下發生的一件事，或一句心裡話開始。"))+
    '<fieldset class="field"><legend>這篇屬於</legend><div class="pills">'+M.categories.map(c=>chip("cat",c,c,w.category===c)).join("")+'</div></fieldset>'+
    '<details'+(w.showMore?' open':'')+' id="writer-more"><summary>標題與日期</summary>'+field("wtitle",'標題 <small>選填，留白會用第一句</small>',inp("wtitle",w.title))+field("wd","日記日期",inp("wd",w.date,"date"))+'</details>'+err("write-error")+'<div class="actions">'+btn("save-source","只存日記",{cls:"btn primary",icon:"check"})+btn("from-writer","開始內在覺察",{icon:"talk"})+'</div></section>'+localNote();
  }
  function choosePage(){
    return pageHead("開始內在覺察","先選一篇日記，下一步可以只帶其中一句。")+'<section class="card">'+btn("new","寫一篇新的",{cls:"btn soft",icon:"pen"})+'</section><section class="card"><h2>從舊日記開始</h2>'+(sortedSources().map(s=>row(s,"select-source")).join("")||empty("目前沒有日記。"))+'</section>';
  }
  function sourceCaption(s){return '<div class="source-name">'+ico("book")+enc(s.origin)+' · '+enc(s.title||M.head(s.text))+'</div>';}
  function preparePage(){
    const {s,w}=session;
    const picked=w.sourceLabel?'<p class="source-passage">'+enc(w.sourceLabel)+' · 我的發言</p>':'';
    const question=session.availableQuestion?'<div class="question-option"><label class="check"><input id="bring-original-question" type="checkbox"'+(w.originalQuestion?' checked':'')+'><span>一併帶入當時 GPT 的提問</span></label><details><summary>查看當時的提問'+(session.questionForm==="summary"?"（大意）":session.questionForm==="mixed"?"（含背景大意）":"")+'</summary><p class="read-text">'+enc(session.availableQuestion)+'</p></details></div>':'';
    return pageHead("這次想談哪一段？","以下文字會放進討論包。你可以刪掉名字，只留下想談的部分。")+'<section class="card">'+sourceCaption(s)+picked+field("ex","給 GPT 的選段",tx("ex",w.excerpt,4))+question+
      field("goal",'這次我想弄清楚什麼 <small>選填</small>',tx("goal",w.purpose,2,"例如：當下我在顧慮什麼？"))+
      (session.hasContext?field("ctx","這次一起帶入的上次整理",tx("ctx",w.context,4),'<p class="fine">可直接刪改。</p>'):"")+
      '<details id="method-details"><summary>談的方式 · '+enc(w.method)+'</summary><p class="fine">預設讓 GPT 讀過選段和目的後，用一句話推薦。討論中也可以說「換一種」或「我想自由聊」。</p>'+field("method","這次偏好的方式",'<select id="method">'+[["自動推薦","讓 GPT 推薦"],...M.methods].map(([v,label])=>'<option value="'+enc(v)+'"'+(w.method===v?' selected':'')+'>'+enc(v==="自動推薦"?label:label+"（"+v+"）")+'</option>').join("")+'</select>')+'</details>'+
      '<details id="outbound"><summary>預覽完整討論包</summary>'+tx("outtext",M.packet(w),9,"","readonly")+'</details>'+err("prep-error")+
      '<div class="actions">'+btn("copy","複製給 GPT",{cls:"btn primary",icon:"copy"})+btn("stash","暫存後複製",{icon:"bookmark"})+'</div><p class="fine" style="margin-top:8px">想關掉頁面再回來，請選「暫存後複製」。</p><div class="test-link">'+btn("try-talk","在這裡試談一輪",{cls:"link",icon:"talk"})+'<span class="fine">使用模擬對話</span></div></section>'+localNote();
  }
  function exchangePage(){
    const {s,w}=session;
    return pageHead("把整理帶回來","在 ChatGPT 談到想停的地方，說「整理貼回」，再把回覆貼在這裡。")+'<section class="card">'+sourceCaption(s)+
      '<div class="actions" style="margin:0 0 14px">'+btn("recopy","再複製討論包",{cls:"link",icon:"copy"})+'<a class="link" href="https://chatgpt.com/" target="_blank" rel="noopener noreferrer">開啟 ChatGPT ↗</a></div>'+
      field("returned","貼上這一輪的整理",tx("returned",raw,5,"貼上 GPT 回傳的整段 JSON。"))+err("paste-error")+btn("validate","預覽整理",{cls:"btn primary",icon:"book"})+
      '<div class="test-link">'+btn("try-talk","在這裡試談一輪",{cls:"link",icon:"talk"})+'<span class="fine">使用模擬對話</span></div><details open><summary>用這次的選段試填</summary><p class="fine">先取你選的一句原文填入格式。問答、假設與本人理解都留白。</p><div class="actions">'+btn("example-paused","試填暫存格式",{cls:"btn soft",icon:"pause"})+btn("example-done","試填完成格式",{cls:"btn soft",icon:"check"})+'</div></details></section>'+localNote();
  }
  const returnLabel=k=>({template:"用選段試填的格式",trial:"這次在頁內試談",pasted:"手動貼回的討論"}[k]||"已儲存的討論");
  const ul=arr=>arr.length?'<ul>'+arr.map(x=>'<li class="read-text">'+enc(x)+'</li>').join("")+'</ul>':'<p class="fine">這輪沒有列出。</p>';
  function sourcedFacts(o,form){
    if(!o.factSources?.length)return "";
    return '<div class="chunk"><h3>有來源可核對的事</h3><p class="fine">看過依據後，勾選自己核對過的項目。</p>'+o.factSources.map((f,i)=>'<label class="check"><input type="checkbox" data-verified="'+i+'"'+(form.onlySummary?' disabled':'')+(form.verified.includes(i)?' checked':'')+'><span>'+enc(f.text)+'<br><small class="fine">依據　'+enc(f.source)+'</small></span></label>').join("")+'</div>';
  }
  function previewPage(){
    const {o,form}=returned;
    return pageHead("核對這次整理","可以修正摘要，也可以只留摘要。")+'<section class="card">'+sourceCaption(session.s)+
      '<div class="meta">'+enc(returnLabel(form.returnKind))+' · '+enc(o.method)+' · '+(o.status==="paused"?"這輪先停在這裡":"這輪已整理完成")+'</div><div class="chunk">'+field("summ","討論摘要",tx("summ",form.summary,3))+'<label class="check"><input type="checkbox" id="only-summary"'+(form.onlySummary?' checked':'')+'><span>只保留摘要和來源'+(o.status==="paused"?'，以及續談問題':'')+'。</span></label></div>'+
      '<div class="chunk"><h3>發生了什麼 <small class="optional">據我描述</small></h3>'+ul(o.facts)+'</div>'+sourcedFacts(o,form)+
      '<div class="chunk">'+field("under","我的理解",tx("under",form.understanding,2,"可以用自己的話寫，也可以留白。"))+
      '<label class="check"><input type="checkbox" id="confirm-under"'+(form.onlySummary?" disabled":"")+ (form.confirmed?" checked":"")+'><span>這是我確認的理解，存進這輪紀錄。</span></label></div>'+
      '<div class="chunk hyp"><h3>GPT 的推測 <small class="optional">尚待確認</small></h3>'+ul(o.hypotheses)+'</div><div class="chunk">'+field("nextq",'還想談的事'+(o.status==="paused"?'':' <small>選填</small>'),tx("nextq",form.question,2,"下次想從哪一句繼續？"))+'</div>'+
      '<details><summary>查看回傳的問答（'+o.dialogue.length+' 組）</summary>'+questionAnswers(o.dialogue,form.returnKind)+'</details>'+
      '<label class="check"><input type="checkbox" id="save-full"'+(form.onlySummary?" disabled":"")+ (form.full?" checked":"")+'><span>一併保存這份回傳中的完整問答</span></label>'+err("confirm-error")+
      '<div class="actions">'+btn("save-result",o.status==="paused"?"暫存，下次再談":"確認儲存",{cls:"btn primary",icon:o.status==="paused"?"bookmark":"check"})+btn("back-paste","回去看貼上的文字",{cls:"link"})+'</div></section>'+localNote();
  }
  function questionAnswers(arr,kind="pasted"){
    return arr.length?arr.map(x=>'<div class="chunk"><p class="fine">'+(kind==="trial"?"試談問句":"討論中的問題")+'</p><p class="read-text">'+enc(x.q)+'</p><p class="fine">我說</p><p class="read-text">'+enc(x.a)+'</p></div>').join(""):'<p class="fine">沒有附上完整問答。</p>';
  }
  function searchResults(){
    const q=filter.q.trim().toLocaleLowerCase();
    return sortedSources().filter(s=>{
      const ts=threadsFor(s.id);
      const searchBody=q?[M.searchable(s,ts),A.forSearch(groupsFor(s.id)),s.deviceTranscript?.raw||""].join(" ").toLocaleLowerCase():"";
      return (!filter.date||s.date===filter.date)&&(!q||searchBody.includes(q))&&(filter.status==="全部"||(ts.length?ts.some(t=>M.stateText(t)===filter.status):filter.status==="尚未在此試談"));
    });
  }
  function resultList(){
    const list=searchResults();
    return '<div class="between"><h2 class="group-title">日記與覺察</h2><span class="meta">'+list.length+' 篇</span></div><div class="history-list" style="margin-top:9px">'+(list.length?list.map(s=>row(s)).join(""):empty("沒有找到符合的紀錄。可以換個關鍵字，或清除篩選。"))+'</div>';
  }
  function historyPage(){
    return pageHead("回顧覺察紀錄")+'<section class="card"><div class="two-fields">'+field("query","關鍵字",inp("query",filter.q,"search",'placeholder="找原文、摘要、理解…"'))+field("ondate","日記日期",inp("ondate",filter.date,"date"))+'</div><div class="filters">'+["全部","尚未在此試談","待貼回","暫存","已完成","已封存"].map(l=>chip("filter",l,l,filter.status===l)).join("")+'</div>'+btn("clear-filters","清除篩選",{cls:"link"})+'</section><section id="found">'+resultList()+'</section>';
  }
  function describeRound(t,r,ix){
    const summary=r.summary||"已保留這一輪的選段與討論包。";
    const understand=r.understanding?'<p class="read-text">'+enc(r.understanding)+'</p>':'<p class="fine">這輪未保存本人確認的理解。</p>';
    const refs=db.links.filter(l=>l.kind==="belief"&&(l.aRound===r.id||l.bRound===r.id)).map(l=>{
      const otherId=l.aRound===r.id?l.bRound:l.aRound;
      const ot=db.threads.find(g=>g.rounds.some(z=>z.id===otherId)),other=ot?.rounds.find(z=>z.id===otherId),os=ot&&source(ot.sourceId);
      return ot&&os&&other?btn("jump-round",os.title+" · "+other.date,{id:otherId,cls:"link",after:"right"}):"";
    }).join("");
    const historyLink=r.archiveGroup&&!r.archiveGroup.startsWith("mine-")&&groupsFor(t.sourceId).some(g=>g.id===r.archiveGroup)
      ?btn("history-scroll","回到當時這一輪",{id:"history-"+r.archiveGroup,cls:"link",icon:"book"})
      :btn("show-original",groupsFor(t.sourceId).length?"查看原對話":"查看目前原日記",{cls:"link",icon:"book"});
    const passageInfo=(r.sourceLabel?'<p class="fine">'+enc(r.sourceLabel)+' · 我的發言</p>':'')+
      (r.originalQuestion?'<p class="fine">當時一併帶入的 GPT 提問'+(r.originalQuestionForm==="summary"?'（大意）':r.originalQuestionForm==="mixed"?'（含背景大意）':'')+'</p><p class="read-text">'+enc(r.originalQuestion)+'</p>':'');
    const actions=t.archived?'':(r.status==="waiting"?btn("resume-round","回來貼整理",{id:r.id,cls:"btn soft",icon:"turn"}):btn("edit-round","編輯整理",{id:r.id,cls:"link",icon:"edit"}));
    return '<article class="chunk" id="round-'+enc(r.id)+'"><div class="between"><h3>第 '+(ix+1)+' 輪</h3><span class="meta">'+enc(r.date)+(r.returnKind?' · '+enc(returnLabel(r.returnKind)):'')+' · '+({waiting:"待貼回",paused:"暫存",done:"已完成"}[r.status])+'</span></div><p class="read-text">'+enc(summary)+'</p>'+
      (r.question?'<div class="return-quote"><span class="fine">還想談的事</span><p>'+enc(r.question)+'</p></div>':'')+
      '<details><summary>查看本輪選段與整理</summary><div class="chunk"><h3>當時交給 GPT 的選段</h3><p class="meta">原文第 '+r.sourceVersion+' 版 · '+enc(r.method)+'</p><p class="passage">'+enc(r.excerpt)+'</p>'+passageInfo+historyLink+(r.purpose?'<p class="fine">當時想釐清</p><p class="read-text">'+enc(r.purpose)+'</p>':'')+(r.context?'<details><summary>當時一起帶入的上次整理</summary><p class="read-text">'+enc(r.context)+'</p></details>':'')+'</div>'+
      (r.status!=="waiting"?'<div class="chunk"><h3>發生了什麼 <small class="optional">據我描述</small></h3>'+ul(r.facts)+'</div>'+(r.verifiedFacts?.length?'<div class="chunk"><h3>我核對過的事與依據</h3>'+ul(r.verifiedFacts.map(f=>f.text+'（'+f.source+'）'))+'</div>':'')+'<div class="chunk"><h3>我確認的理解</h3>'+understand+(r.versions.length?'<details><summary>理解的歷史版本（'+r.versions.length+'）</summary>'+r.versions.map((v,i)=>'<div class="chunk"><p class="meta">'+enc(v.date)+' · 第 '+(i+1)+' 版</p><p class="read-text">'+enc(v.text)+'</p></div>').join("")+'</details>':'')+(refs?'<div class="chunk"><h3>同一信念的其他紀錄</h3>'+refs+'</div>':'')+(r.understanding&&!t.archived?btn("belief","連結同一信念的紀錄",{id:r.id,cls:"link",icon:"link"}):'')+'</div><div class="chunk hyp"><h3>GPT 的推測 · 尚待確認</h3>'+ul(r.hypotheses)+'</div><div class="chunk"><h3>討論來源</h3>'+questionAnswers(r.dialogue,r.returnKind)+(r.answers?.length&&!r.dialogue.length?'<p class="fine">保留的本人引句</p>'+ul(r.answers):'')+'</div>':'')+'</details>'+actions+'</article>';
  }
  function threadCard(t){
    const r=M.latest(t);
    const next=t.archived?btn("unarchive","重新開啟",{id:t.id,cls:"btn soft",icon:"turn"}):
      (r.status!=="waiting"?btn("resume",r.status==="paused"?"繼續這次覺察":"接著談一輪",{id:t.id,cls:"btn soft",icon:"talk"}):'');
    return '<section class="card"><div class="between"><h2>這次內在覺察</h2><span class="mini-tag">'+enc(M.stateText(t))+'</span></div>'+
      t.rounds.map((item,i)=>({item,i})).reverse().map(({item,i})=>describeRound(t,item,i)).join("")+
      '<div class="actions">'+next+(t.archived?'':btn("archive","封存這次覺察",{id:t.id,cls:"link"}))+btn("ask-delete-thread","刪除這次覺察",{id:t.id,cls:"link danger"})+'</div></section>';
  }
  function related(s){
    const endorsed=db.links.filter(l=>l.kind==="related"&&(l.a===s.id||l.b===s.id)).map(l=>source(l.a===s.id?l.b:l.a)).filter(Boolean);
    const subject=M.searchable(s,threadsFor(s.id));
    const matches=sortedSources().filter(x=>x.id!==s.id&&!endorsed.some(y=>y.id===x.id)).map(x=>({x,words:M.shared(subject,M.searchable(x,threadsFor(x.id)))})).filter(x=>x.words.length).slice(0,3);
    if(!endorsed.length&&!matches.length)return "";
    return '<section class="card"><h2>相關紀錄</h2>'+endorsed.map(x=>'<div class="between">'+btn("detail",x.title,{id:x.id,cls:"link",icon:"link"})+btn("unlink","解除連結",{id:x.id,cls:"link"})+'</div>').join("")+matches.map(({x,words})=>'<div class="chunk"><p class="row-title">'+enc(x.title)+'</p><p class="fine">兩篇都提到「'+words.map(enc).join("」、「")+'」</p><div class="actions">'+btn("relate","連結這篇",{id:x.id,cls:"btn soft",icon:"link"})+btn("detail","先看原文",{id:x.id,cls:"link"})+'</div></div>').join("")+'</section>';
  }
  function originDetails(s){
    const original=sourceOriginal(s.id);
    if(!original)return "";
    const ref=original.ref;
    let outbound="";
    if(ref.url){
      try{
        const url=new URL(ref.url);
        if(url.protocol==="https:"&&["app.notion.com","www.notion.so","notion.so"].includes(url.hostname))
          outbound='<a class="link" target="_blank" rel="noopener noreferrer" href="'+enc(url.href)+'">在 Notion 開啟原頁 ↗</a>';
      }catch{}
    }
    const text=s.text===original.text?"":'<p class="fine">取用時的原文</p><blockquote class="passage">'+enc(original.text)+'</blockquote>';
    return '<details class="provenance"><summary>查看來源與原文</summary><p>'+enc(ref.place)+' · '+enc(ref.field)+'</p><p class="fine">'+enc(original.date)+' · '+enc(ref.note)+'</p>'+text+outbound+'</details>';
  }
  function suppliedGroups(s){
    if(!s.deviceTranscript?.raw)return [];
    return A.readTranscript(s.deviceTranscript.raw).map((item,i)=>({id:"mine-"+i,title:"逐字稿第 "+(i+1)+" 則",stage:"supplied",items:[item]}));
  }
  function historyItem(group,item,i){
    const summary=item.form==="summary";
    const speaker=item.role==="user"?"我":item.role==="assistant"?"GPT":"說話者未標示";
    const basis=summary?"大意":item.form==="supplied"?"本人補上的原文":"原文摘錄";
    const action=item.role==="user"&&!summary?btn("pick-history","選這段接著談",{id:group.id,cls:"link passage-action",extra:' data-part="'+i+'"'}):"";
    return '<div class="history-voice '+(summary?"paraphrase":"")+'"><div class="voice-label"><b>'+enc(speaker)+'</b><small>'+basis+'</small></div><p class="read-text">'+enc(item.text)+'</p>'+action+'</div>';
  }
  function historyGroup(group,i){
    if(group.stage==="opening"){
      const quotes=group.items.filter(item=>item.role==="user"&&item.form==="quote");
      return '<article class="archive-group opening-group" id="history-'+enc(group.id)+'" tabindex="-1"><h2>'+enc(group.title)+'</h2>'+
        group.items.filter(item=>item.form==="summary").map(item=>'<p class="voice-label"><small>開場日記 · 大意</small></p><p class="read-text">'+enc(item.text)+'</p>').join("")+
        (quotes.length?'<div class="opening-excerpts"><div class="voice-label"><b>我的原話</b><small>依原有順序摘錄</small></div>'+quotes.map(item=>'<p class="read-text">'+enc(item.text)+'</p>').join("")+btn("pick-opening","選開場的一段接著談",{id:group.id,cls:"link passage-action"})+'</div>':'')+'</article>';
    }
    const h=group.stage==="round"?"h3":"h2";
    return '<article class="archive-group" id="history-'+enc(group.id)+'" tabindex="-1">'+(group.stage==="round"?'<span class="round-index">第 '+i+' 輪</span>':'')+
      '<'+h+'>'+enc(group.title)+'</'+h+'>'+group.items.map((item,j)=>historyItem(group,item,j)).join("")+'</article>';
  }
  function recoveredReader(groups){
    const rounds=groups.filter(g=>g.stage==="round");
    return '<div class="archive-body">'+groups.filter(g=>g.stage==="opening").map(g=>historyGroup(g)).join("")+
      (rounds.length?'<section class="round-list" id="history-rounds" tabindex="-1"><h2>逐輪問答</h2>'+rounds.map((g,i)=>historyGroup(g,i+1)).join("")+'</section>':'')+
      groups.filter(g=>g.stage==="closing").map(g=>historyGroup(g)).join("")+'</div>';
  }
  function archiveCard(s,groups){
    const rounds=groups.filter(g=>g.stage==="round").length;
    const pasted=suppliedGroups(s);
    const nav=btn("history-scroll","起點",{id:"history-start",cls:"link"})+btn("history-scroll","逐輪問答",{id:"history-rounds",cls:"link"})+btn("history-scroll","收尾",{id:"history-end",cls:"link"});
    const originalInfo='<div class="archive-intro"><h2>原對話回顧</h2><p class="archive-scope">開場日記、'+rounds+' 輪問答與收尾。逐字取回的部分標為「原文摘錄」，其餘標為「大意」。</p><nav class="archive-jumps" aria-label="跳至原對話段落">'+nav+'</nav></div>';
    const archived=originalInfo+recoveredReader(groups);
    const contents=pasted.length?'<div class="archive-intro"><h2>我補上的原對話</h2><p class="fine">依貼入順序顯示。說話者沿用文字裡的標示。</p></div>'+pasted.map(g=>'<div class="archive-group supplied-entry" id="history-'+g.id+'" tabindex="-1">'+historyItem(g,g.items[0],0)+'</div>').join("")+
      '<details class="prior-archive"><summary>查看先前找回的對話</summary>'+archived+'</details>':archived;
    const local=s.version>1?'<div class="archive-copy"><h3>我編輯過的選段副本</h3><p class="read-text">'+enc(s.text)+'</p>'+btn("edit-source","編輯這段副本",{id:s.id,cls:"link",icon:"edit"})+'</div>':'';
    const originalActions='<details class="provenance"><summary>來源與逐字稿</summary><p class="fine">虛構對話〈'+enc(sourceOriginal(s.id).title)+'〉 · '+enc(sourceOriginal(s.id).date)+'</p><p>你可以補上原對話文字，保留在這個瀏覽器。</p><div class="actions">'+btn("paste-transcript",pasted.length?"編輯補上的逐字稿":"貼上原對話",{id:s.id,cls:"btn soft"})+(s.version===1?btn("edit-source","編輯上版選段副本",{id:s.id,cls:"link"}):'')+'</div></details>';
    return '<section class="card conversation-archive" id="original">'+contents+local+originalActions+'</section>';
  }
  function pasteTranscript(s,preview=false){
    if(!s)return;
    const groups=A.readTranscript(transcriptDraft);
    if(preview){
      const user=groups.filter(g=>g.role==="user").length,assistant=groups.filter(g=>g.role==="assistant").length,unknown=groups.length-user-assistant;
      const counts=[user&&"我 "+user+" 則",assistant&&"GPT "+assistant+" 則",unknown&&"說話者未標示 "+unknown+" 段"].filter(Boolean).join("、");
      modal("核對貼上的逐字稿",'<p>'+enc(counts)+'。請核對文字和說話者，再決定是否儲存。</p><div class="transcript-sample">'+groups.map(it=>'<div class="chunk"><b>'+enc(it.role==="user"?"我":it.role==="assistant"?"GPT":"說話者未標示")+'</b><p class="read-text">'+enc(it.text)+'</p></div>').join("")+'</div><div class="actions">'+btn("save-transcript","儲存到這個瀏覽器",{id:s.id,cls:"btn primary"})+btn("revise-transcript","回去編輯",{id:s.id,cls:"link"})+'</div>');
    }else{
      modal("貼上原對話",'<p>整段貼上即可。有「你說：」或「ChatGPT 說：」時，會依標示分開。其餘文字保留原樣。</p>'+field("transcript-body","對話原文",tx("transcript-body",transcriptDraft,8))+
        (s.deviceTranscript?'<p class="fine">儲存後會更新這個瀏覽器裡的逐字稿。</p>':'')+err("transcript-error")+'<div class="actions">'+btn("review-transcript","預覽逐字稿",{id:s.id,cls:"btn primary"})+btn("close","取消",{cls:"link"})+'</div>');
    }
  }
  function detailPage(){
    const s=source(view.args.id);
    if(!s)return pageHead("這篇測試紀錄已移除")+btn("history","回顧其他紀錄",{cls:"btn soft"});
    const imported=!!sourceOriginal(s.id);
    const groups=groupsFor(s.id);
    const title=imported?(s.ref.kind==="conversation"?"我的對話原話":"原日記選段"):"原日記";
    return pageHead(s.title||M.head(s.text),dateLabel(s.date)+" · "+s.category+" · "+s.origin)+
      (groups.length?archiveCard(s,groups):'<section class="card" id="original"><div class="between"><h2>'+enc(imported&&s.version>1?"編輯後的測試副本":title)+'</h2><span class="meta">'+(imported?"測試副本 · ":"")+'第 '+s.version+' 版</span></div><p class="read-text">'+enc(s.text)+'</p>'+originDetails(s)+'<div class="actions">'+btn("select-source","從這篇開始覺察",{id:s.id,cls:"btn soft",icon:"talk"})+btn("edit-source",imported?"編輯這裡的副本":"編輯原日記",{id:s.id,cls:"link",icon:"edit"})+'</div></section>')+
      threadsFor(s.id).map(threadCard).join("")+related(s)+'<details><summary>管理這篇紀錄</summary>'+btn("ask-delete-source","移除這篇測試紀錄",{id:s.id,cls:"link danger"})+'</details>'+localNote();
  }
  function editPage(){
    return pageHead("編輯這輪整理","修改已確認的理解會保留前一版。")+'<section class="card">'+field("edit-sum","討論摘要",tx("edit-sum",editor.summary,3))+field("edit-under","我確認的理解",tx("edit-under",editor.understanding,3))+
    '<label class="check"><input type="checkbox" id="edit-ok"'+(editor.ok?' checked':'')+'>我確認上面的理解是自己的說法。</label>'+field("edit-q","還想談的事",tx("edit-q",editor.question,2))+err("edit-error")+btn("store-edit","確認儲存修改",{cls:"btn primary",icon:"check"})+'</section>';
  }
  function sourceEditPage(){const copy=!!sourceOriginal(sourceEdit.id);return pageHead(copy?"編輯這裡的副本":"編輯原日記",copy?"修改存到本機，來源頁保留原文。":"已進入討論的選段，會保留當時的文字。")+'<section class="card">'+field("et","標題",inp("et",sourceEdit.title))+field("eb","原文",tx("eb",sourceEdit.text,6))+field("ed","日記日期",inp("ed",sourceEdit.date,"date"))+err("edit-error")+btn("store-source-edit",copy?"儲存副本":"儲存原日記",{cls:"btn primary",icon:"check"})+'</section>';}
  function render(focus=false){
    if(!ready)return;
    if(view.name==="trytalk"&&(!trial||!session)||["prepare","exchange"].includes(view.name)&&!session || view.name==="preview"&&(!returned||!session) || view.name==="write"&&!writer || view.name==="edit"&&!editor || view.name==="sourceEdit"&&!sourceEdit){view=frames[index]={name:"home",args:{}};}
    headAndNav();
    const pages={home,write:writerPage,choose:choosePage,prepare:preparePage,exchange:exchangePage,preview:previewPage,history:historyPage,detail:detailPage,edit:editPage,sourceEdit:sourceEditPage,trytalk:trialPage};
    const isHome=view.name==="home";
    $("main").innerHTML='<div class="container'+(isHome?'':' inner')+'">'+(isHome?'':trail())+(pages[view.name]||home)()+'</div>';
    document.title=docTitle[view.name]+"｜行光道場・修習所";
    if(focus){$("main").focus({preventScroll:true});window.scrollTo(0,0);}
  }
  function flag(id,text){const el=$(id);if(el){el.textContent=text;el.scrollIntoView({block:"nearest"});}else toast(text);}
  function newWriter(){if(writer?.text.trim()&&!source(writer.id)){go("write");return;}writer=M.src(M.uid(),M.today(),"","",M.categories[0],"心／情手記");go("write");}
  function validWriter(){if(!writer.text.trim()){flag("write-error","先寫下一句想留下的話。");$("wt").focus();return false;}if(!writer.date){flag("write-error","請選擇日記日期。");return false;}return true;}
  function startSession(s,t=null,prev=null,savedRound=null,picked=null){
    const w=savedRound?{threadId:t.id,roundId:savedRound.id,sourceId:s.id,sourceVersion:savedRound.sourceVersion,date:savedRound.date,excerpt:savedRound.excerpt,purpose:savedRound.purpose,method:savedRound.method,context:savedRound.context,sourceLabel:savedRound.sourceLabel||"",archiveGroup:savedRound.archiveGroup||"",originalQuestion:savedRound.originalQuestion||"",originalQuestionForm:savedRound.originalQuestionForm||""}:M.newRound(s,t,prev);
    if(picked)Object.assign(w,{excerpt:picked.text,sourceLabel:picked.label,archiveGroup:picked.group});
    session={s:{...s},w,hasContext:Boolean(w.context),returnKind:"pasted",availableQuestion:picked?.question||w.originalQuestion||"",questionForm:picked?.questionForm||w.originalQuestionForm||""};
    returned=null;raw="";go(savedRound?"exchange":"prepare");
  }
  function engage(t){
    if(!t||t.archived)return;
    const r=M.latest(t), s=source(t.sourceId);
    if(!s)return;
    startSession(s,t,r,r.status==="waiting"?r:null);
  }
  function forRound(id){
    const t=db.threads.find(t=>t.rounds.some(r=>r.id===id));
    return t?{t,r:t.rounds.find(r=>r.id===id),s:source(t.sourceId)}:null;
  }
  function jumpRound(id){
    const hit=forRound(id);if(!hit)return;
    go("detail",{id:hit.s.id});
    const elem=$("round-"+id);if(elem){const det=elem.querySelector("details");if(det)det.open=true;elem.scrollIntoView({block:"start"});}
  }
  async function clipboard(text){
    try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(text);return true;}}catch{}
    const ta=document.createElement("textarea");ta.value=text;ta.setAttribute("readonly","");ta.style.cssText="position:fixed;left:0;top:0;opacity:0;font-size:16px";document.body.append(ta);ta.focus();ta.select();ta.setSelectionRange(0,ta.value.length);
    let ok=false;try{ok=document.execCommand("copy");}catch{}ta.remove();return ok;
  }
  async function copyFlow(stash=false,again=false){
    const {s,w}=session;
    if(!w.excerpt.trim()){flag("prep-error","請留下一句要交給 GPT 的選段。");$("ex")?.focus();return;}
    if(!again){
      const content=JSON.stringify([w.excerpt.trim(),w.purpose.trim(),w.context.trim(),w.method,w.sourceLabel||"",w.originalQuestion||"",w.originalQuestionForm||""]);
      if(session.sent&&session.sent!==content){w.roundId=M.uid();w.date=M.today();}
      session.sent=content;
    }
    const text=M.packet(w);
    if(stash&&!await commit(d=>M.persistRound(d,s,w)))return;
    const ok=await clipboard(text);
    if(view.name!=="exchange")go("exchange");
    if(ok)toast(stash?"已暫存並複製，可以切到 ChatGPT。":"已複製，可以切到 ChatGPT。");
    else{
      modal("手動複製討論包",'<p>長按下方文字，選擇「全選」和「複製」。</p>'+tx("manual-copy",text,7,"","readonly")+'<div class="actions">'+btn("select-all","選取整段文字",{cls:"btn soft"})+btn("close","回到貼回頁",{cls:"link"})+'</div>');
      $("manual-copy").focus();$("manual-copy").select();
    }
  }
  function requirePreview(){
    try{
      const o=M.parse(raw,session.w);
      const saved=db.threads.find(t=>t.id===o.threadId)?.rounds.find(r=>r.id===o.roundId&&r.status!=="waiting");
      if(saved){flag("paste-error","這份整理已保存過。可從回顧查看原紀錄。");return;}
      returned={o,form:{returnKind:session.returnKind||"pasted",summary:o.summary,understanding:o.understanding,question:o.question,confirmed:false,full:false,onlySummary:false,verified:[]}};go("preview");
    }catch(err){flag("paste-error",err.message);}
  }
  async function saveResult(){
    const {o,form}=returned,w=session.w;
    if(!form.summary.trim()||(o.status==="paused"&&!form.question.trim())||(form.confirmed&&!form.understanding.trim())){flag("confirm-error","請補上摘要、暫存的續談問題，或取消空白理解的勾選。");return;}
    if(!await commit(d=>M.persistRound(d,session.s,w,o,form)))return;
    go("detail",{id:session.s.id});toast(o.status==="paused"?"已暫存，下次可以從原問題繼續。":"已保存這輪覺察。");
  }
  function confirmDialog(title,msg,action,id){modal(title,'<p>'+enc(msg)+'</p><div class="actions">'+btn("close","保留紀錄",{cls:"btn soft"})+btn(action,"確認刪除",{id,cls:"btn danger"})+'</div>');}
  const official={today:["今天","/"],calendar:["行事曆","/calendar"],week:["週盤","/bingo"]};
  let timerStart=0,timerSaved=0;
  const elapsed=()=>Math.floor((timerSaved+(timerStart?Date.now()-timerStart:0))/1000);
  const timerText=()=>{const s=elapsed();return String(Math.floor(s/60)).padStart(2,"0")+":"+String(s%60).padStart(2,"0");};
  function timerModal(){modal("修習計時",'<p class="read-text" style="font-size:32px" id="clock-read">'+timerText()+'</p><div class="actions">'+btn("timer-toggle",timerStart?"暫停":"開始計時",{cls:"btn primary",icon:"timer"})+btn("timer-reset","歸零",{cls:"btn"})+'</div>');}
  setInterval(()=>{if($("clock-read"))$("clock-read").textContent=timerText();},500);
  function selectBelief(roundId){
    const hit=forRound(roundId);if(!hit)return;
    const existing=db.links.filter(l=>l.kind==="belief"&&(l.aRound===roundId||l.bRound===roundId));
    const others=db.threads.flatMap(t=>t.rounds.map(r=>({t,r}))).filter(({r})=>r.id!==roundId&&r.understanding&&!existing.some(l=>l.aRound===r.id||l.bRound===r.id));
    modal("連結同一個信念",'<p>選一則你已確認、屬於同一個信念的理解。每一則都保留自己的原文與討論。</p>'+
      (others.length?others.map(({t,r})=>'<button type="button" class="option" data-act="add-belief" data-id="'+enc(r.id)+'" data-from="'+enc(roundId)+'"><span class="row-copy"><span class="row-title">'+enc(r.understanding)+'</span><span class="row-sub">'+enc(source(t.sourceId)?.title)+' · '+enc(r.date)+'</span></span>'+ico("link")+'</button>').join(""):empty("還沒有其他可連結的本人理解。")));
  }
  const pathsForTalk=[
    {cue:/顧慮|擔心|害怕|怎麼想|信念/,why:"選段提到了心裡的顧慮，可以從當時冒出的念頭談起。",q:"回到那一刻，你心裡先冒出了哪一句話？"},
    {cue:/選擇|決定|下一步|想做|在意的事/,why:"你提到了選擇，從自己在意的事開始，比較容易看見下一步。",q:"在這個選擇裡，你最想顧到什麼？"},
    {cue:/經過|回顧|學到|回頭|過程/,why:"選段裡有一段經過，可以先找到最值得回頭看的一刻。",q:"回頭看這段經過，哪一刻最影響後來的事？"},
    {cue:/衝動|忍不住|生氣|情緒起伏|身體反應/,why:"感受和行動都出現在選段裡，可以先看看它們的先後。",q:"做出那個動作之前，你最先注意到什麼變化？"},
    {cue:/責怪|責備|太差|怪自己|自責|對自己溫柔/,why:"這段文字提到對自己的責備，可以先試著用體諒的語氣說一次。",q:"如果此刻能對自己說一句體諒的話，你會說什麼？"},
    {cue:null,why:"先從你挑出來的一句話開始，一個問題就能試出這次想談的重點。",q:"在這段文字裡，你最想留下哪一點？"},
    {cue:null,why:"可以讓你決定先談哪一部分。",q:"如果從你最想說的地方開始，你會先說什麼？"}
  ];
  function chooseMethod(w){
    const fixed=M.methods.findIndex(([code])=>w.method===code);
    if(fixed>=0)return fixed;
    for(const str of [w.purpose,w.excerpt,w.context]){const i=pathsForTalk.findIndex(p=>p.cue?.test(str));if(i>=0)return i;}
    return 5;
  }
  function openTrial(){
    if(!session.w.excerpt.trim()){flag("prep-error","先留下一句想談的話。");return;}
    const method=chooseMethod(session.w);
    trial={method,stage:"recommend",switching:false,asked:[],turns:[],pending:"",answer:"",resumed:false};
    go("trytalk");
  }
  function trialPage(){
    const h=trial,w=session.w,method=M.methods[h.method],guide=pathsForTalk[h.method];
    let inner='<div class="source-name">'+ico("talk")+'模擬對話 · 文字留在此頁</div>';
    if(h.turns.length)inner+='<details><summary>剛才談過的內容（'+h.turns.length+'）</summary>'+questionAnswers(h.turns,"trial")+'</details>';
    if(h.stage==="recommend"){
      inner+='<h2>先'+enc(method[1])+'</h2><p>'+enc(guide.why)+'</p><p class="meta" style="margin-top:6px">'+enc(method[0])+'</p><div class="actions">'+btn("accept-method","照這個談",{cls:"btn primary",icon:"talk"})+btn("switch-method","換個方式",{cls:"btn"})+(h.method===6?"":btn("free-method","我想自由聊",{cls:"link"}))+'</div>';
      if(h.switching)inner+='<div class="chunk"><h3>選一種談法</h3>'+M.methods.map(([c,label],i)=>'<button type="button" class="option" data-act="pick-method" data-id="'+i+'"><span class="row-copy"><span class="row-title">'+enc(label)+'</span><span class="row-sub">'+enc(c)+'</span></span>'+ico("right")+'</button>').join("")+'</div>';
      inner+='<div class="actions">'+btn("finish-trial","原文已經說清楚，直接整理",{cls:"link",after:"right"})+'</div>';
    }else if(h.stage==="question"){
      inner+='<h2>'+enc(h.pending)+'</h2>'+field("trial-answer","我的回答",tx("trial-answer",h.answer,4,"用自己的話說就好。"))+err("talk-error")+'<div class="actions">'+btn("answer-trial","送出這句",{cls:"btn primary",after:"arrow"})+btn("pause-trial","先停在這裡",{cls:"btn",icon:"pause"})+'</div><div class="actions">'+btn("change-trial","換個談法",{cls:"link"})+btn("finish-trial","我已經說清楚了",{cls:"link"})+'</div>';
    }else{
      inner+='<h2>這裡可以先收尾</h2><p>你已說出想留下的理解。接下來可以核對這一輪要保存的內容。</p><div class="return-quote">'+enc(h.turns[h.turns.length-1]?.a||w.excerpt)+'</div><div class="actions">'+btn("finish-trial","整理貼回",{cls:"btn primary",icon:"book"})+'</div>';
    }
    return pageHead("在這裡試談一輪","這裡用預設問句示範談法。想和 GPT 討論時，可以複製討論包。")+'<section class="card">'+inner+'</section>';
  }
  function askTrial(){
    const h=trial,w=session.w;
    const prev=thread(w.threadId),previous=M.latest(prev);
    if(previous?.question&&w.context.includes(previous.question)&&!h.resumed&&!h.asked.includes(previous.question)){
      h.pending=previous.question;h.resumed=true;
    }else{
      const past=new Set([...(prev?.rounds.flatMap(r=>r.dialogue?.filter(x=>x.q&&x.a).map(x=>x.q)||[])||[]),...h.asked]);
      const qs=[pathsForTalk[h.method].q,"你怎麼知道這一點對自己重要？"];
      h.pending=qs.find(q=>!past.has(q))||"";
    }
    h.switching=false;h.stage=h.pending?"question":"wrap";render();
  }
  function captureAnswer(){
    const h=trial,answer=h.answer.trim();
    if(!answer)return false;
    h.turns.push({q:h.pending,a:answer});h.asked.push(h.pending);h.answer="";return true;
  }
  function answerTrial(){
    if(!captureAnswer()){flag("talk-error","先寫下你的回答，或選「先停在這裡」。");return;}
    const evidence=/因為|所以|由於|例如|像是|當時|我發現|我看到|我注意|有一次|才知道|還不確定|我看|怕|取決於|但|雖然|對我來說|為了/;
    if(trial.turns.some(x=>evidence.test(x.a))||trial.turns.length>=2){trial.stage="wrap";render();return;}
    askTrial();
  }
  function finishTrial(paused){
    const h=trial,w=session.w;
    const hadAnswer=h.stage==="question"&&captureAnswer();
    const output=M.template(w,paused?"paused":"done");
    const last=h.turns[h.turns.length-1]?.a||"";
    Object.assign(output,{method:M.methods[h.method][0],summary:last?"這輪我留下的話："+last:"這輪先留下選段中的一句話："+w.excerpt.trim().split(/\n/)[0],understanding:last,
      hypotheses:[],question:paused?(!hadAnswer&&h.pending?h.pending:"下次你最想再釐清哪一點？"):"",dialogue:h.turns.map(x=>({...x}))});
    session.returnKind="trial";raw=JSON.stringify(output,null,2);requirePreview();
  }

  document.addEventListener("input",e=>{
    const el=e.target,v=el.value;
    const map={wt:[writer,"text"],wtitle:[writer,"title"],wd:[writer,"date"],ex:[session?.w,"excerpt"],goal:[session?.w,"purpose"],ctx:[session?.w,"context"],method:[session?.w,"method"],summ:[returned?.form,"summary"],under:[returned?.form,"understanding"],nextq:[returned?.form,"question"],"edit-sum":[editor,"summary"],"edit-under":[editor,"understanding"],"edit-q":[editor,"question"],et:[sourceEdit,"title"],eb:[sourceEdit,"text"],ed:[sourceEdit,"date"]};
    if(map[el.id]?.[0])map[el.id][0][map[el.id][1]]=v;
    if(el.id==="under"&&returned){returned.form.confirmed=false;$("confirm-under").checked=false;}
    if(el.id==="edit-under"&&editor){editor.ok=false;$("edit-ok").checked=false;}
    if(el.id==="returned"){raw=v;if(!v.trim())session.returnKind="pasted";rememberFlow();}
    if(el.id==="trial-answer"&&trial)trial.answer=v;
    if(el.id==="query"||el.id==="ondate"){filter[el.id==="query"?"q":"date"]=v;$("found").innerHTML=resultList();}
    if(["ex","goal","ctx","method"].includes(el.id)&&$("outtext")){$("outtext").value=M.packet(session.w);if(el.id==="method")$("method-details").querySelector("summary").textContent="談的方式 · "+v;}
  });
  document.addEventListener("change",e=>{
    const el=e.target;
    if(el.id==="bring-original-question"&&session){
      session.w.originalQuestion=el.checked?session.availableQuestion:"";
      session.w.originalQuestionForm=el.checked?session.questionForm:"";
      if($("outtext"))$("outtext").value=M.packet(session.w);
    }
    if(el.dataset.verified!==undefined&&returned){const id=Number(el.dataset.verified);returned.form.verified=returned.form.verified.filter(i=>i!==id);if(el.checked)returned.form.verified.push(id);}
    if(el.id==="confirm-under")returned.form.confirmed=el.checked;
    if(el.id==="save-full")returned.form.full=el.checked;
    if(el.id==="only-summary"){returned.form.onlySummary=el.checked;if(el.checked){returned.form.confirmed=false;returned.form.full=false;returned.form.verified=[];}for(const item of document.querySelectorAll("[data-verified]")){item.disabled=el.checked;if(el.checked)item.checked=false;}for(const k of ["confirm-under","save-full"]){$(k).disabled=el.checked;if(el.checked)$(k).checked=false;}}
    if(el.id==="edit-ok")editor.ok=el.checked;
    if(["ondate","wd","ed","method"].includes(el.id))el.dispatchEvent(new Event("input",{bubbles:true}));
  });
  document.addEventListener("toggle",e=>{if(e.target.id==="writer-more"&&writer)writer.showMore=e.target.open;},true);
  function previousLocal(){
    try{const value=JSON.parse(localStorage.getItem(legacyKey)||"null");return validDb(value)?value:null;}
    catch{return null;}
  }
  function previousSources(data){
    const oldFixtures=new Set(["s-mint","s-rain","s-window","s-note"]);
    return (data?.sources||[]).filter(s=>typeof s.id==="string"&&typeof s.text==="string"&&!oldFixtures.has(s.id)&&!source(s.id));
  }
  async function importPrevious(){
    const old=previousLocal(),wanted=previousSources(old);if(!old||!wanted.length)return;
    const ids=new Set(wanted.map(s=>s.id));
    const ok=await commit(next=>{
      const localIds=new Set(next.threads.map(t=>t.id));
      const ts=old.threads.filter(t=>ids.has(t.sourceId)&&!localIds.has(t.id)&&t.rounds?.length);
      const roundIds=new Set(ts.flatMap(t=>t.rounds.map(r=>r.id)));
      for(const s of wanted)M.putSource(next,{...s,ref:undefined});
      next.threads.push(...ts);
      next.links.push(...old.links.filter(l=>l.kind==="related"?ids.has(l.a)&&ids.has(l.b):roundIds.has(l.aRound)&&roundIds.has(l.bRound)));
    });
    if(ok){close();go("history");toast("已取回 "+wanted.length+" 篇上版自寫日記。");}
  }
  function about(){
    const n=previousSources(previousLocal()).length;
    modal("心・情本機示例",'<p>這次帶入 '+baseline.length+' 筆虛構示例。每篇都能查看取用日期與來源，你可以改寫副本或另外開一輪覺察。</p><p>這裡的儲存只作用在這個瀏覽器。要交給 GPT 的文字，可以先在「預覽完整討論包」逐句核對。</p><div class="actions">'+(n?btn("import-previous","取回上版自寫日記（"+n+" 篇）",{cls:"btn soft"}):'')+btn("ask-reset","還原這次帶入的紀錄",{cls:"link"})+btn("close","回到心・情",{cls:"btn soft"})+'</div>');
  }

  document.addEventListener("click",async e=>{
    const b=e.target.closest("[data-act]");if(!b)return;
    const a=b.dataset.act,id=b.dataset.id;
    if(a==="retry-boot"||a==="view-without-device"){await initialize(a==="view-without-device");return;}
    if(!ready)return;
    switch(a){
      case "close":close();break;
      case "home":go("home");break;
      case "realm":modal("修習所",'<p>身心靈修習</p><button class="option" data-act="realm-heart" type="button"><span class="icon-box">'+ico("heart")+'</span><span class="row-copy"><span class="row-title">心・情</span><span class="row-sub">情緒覺察、感恩與心裡小語</span></span>'+ico("right")+'</button><p><a class="link" href="https://lumen-dojo.up.railway.app/practice" target="_blank" rel="noopener noreferrer">查看正式版修習所 ↗</a></p>');break;
      case "realm-heart":close();if(view.name!=="home")go("home");break;
      case "ask-reset":modal("還原這次帶入的紀錄？",'<p>會清除這個瀏覽器內這版的手寫日記、試談及修改，重新顯示最初帶入的選段。內建示例會還原至初始內容。</p><div class="actions">'+btn("close","先保留",{cls:"btn soft"})+btn("reset-fixtures","確認還原",{cls:"btn danger"})+'</div>');break;
      case "reset-fixtures":close();if(await commit(next=>Object.assign(next,sourceCopy()))){writer=session=trial=returned=sourceEdit=editor=null;raw="";frames.splice(0,frames.length,{name:"home",args:{}});index=0;view=frames[0];history.replaceState({hj:0},"",location.pathname);render(true);toast("已還原本人紀錄的測試副本。");}break;
      case "about":about();break;
      case "import-previous":await importPrevious();break;
      case "timer":timerModal();break;
      case "timer-toggle":if(timerStart){timerSaved+=Date.now()-timerStart;timerStart=0;}else timerStart=Date.now();timerModal();break;
      case "timer-reset":timerStart=0;timerSaved=0;timerModal();break;
      case "today":case "calendar":case "week":{
        const [name,path]=official[a];modal(name,'<p>這個入口通往正式版的「'+name+'」。可另開頁面，之後回來繼續測試心・情。</p><div class="actions">'+btn("close","留在模擬版",{cls:"btn soft"})+'<a class="link" href="https://lumen-dojo.up.railway.app'+path+'" target="_blank" rel="noopener noreferrer">前往正式版 ↗</a></div>');break;}
      case "new":if(view.name!=="write")newWriter();break;
      case "choose":go("choose");break;
      case "history":filter={q:"",date:"",status:"全部"};go("history");break;
      case "detail":go("detail",{id});break;
      case "cat":writer.category=id;for(const c of b.parentNode.querySelectorAll("button"))c.setAttribute("aria-pressed",String(c===b));break;
      case "save-source":if(validWriter()&&await commit(d=>M.putSource(d,writer))){go("detail",{id:writer.id});toast("已存為日記。");}break;
      case "from-writer":if(validWriter())startSession(writer);break;
      case "select-source":if(groupsFor(id).length)go("detail",{id});else if(source(id))startSession(source(id));break;
      case "history-scroll":{
        const target=$(id);if(target){const folded=target.closest("details");if(folded)folded.open=true;target.focus({preventScroll:true});target.scrollIntoView({block:"start"});}break;}
      case "pick-opening":{
        const group=groupsFor(view.args.id).find(g=>g.id===id);
        if(group)modal("想從開場的哪一段談起？",'<div class="opening-picker">'+group.items.map((item,i)=>item.role==="user"&&item.form==="quote"?btn("pick-history",item.text,{id,cls:"pick-quote",extra:' data-part="'+i+'"'}):"").join("")+'</div>');break;}
      case "pick-history":{
        const s=source(view.args.id);if(!s)break;
        const groups=id.startsWith("mine-")?suppliedGroups(s):groupsFor(s.id);
        const passage=A.sourcePassage(groups,id,Number(b.dataset.part));
        if(passage){close();startSession(s,null,null,null,passage);}break;}
      case "paste-transcript":{
        const s=source(id);if(s){transcriptDraft=s.deviceTranscript?.raw||"";pasteTranscript(s);}break;}
      case "revise-transcript":pasteTranscript(source(id));break;
      case "review-transcript":{
        transcriptDraft=$("transcript-body").value;
        if(!A.readTranscript(transcriptDraft).length){flag("transcript-error","請先貼入要保留的對話。");break;}
        pasteTranscript(source(id),true);break;}
      case "save-transcript":{
        if(!transcriptDraft.trim())break;
        if(await commit(d=>{const s=d.sources.find(x=>x.id===id);s.deviceTranscript={raw:transcriptDraft};})){
          transcriptDraft="";close();go("detail",{id},true);toast("已保留你補上的逐字稿。");}break;}
      case "resume":engage(thread(id));break;
      case "resume-round":{const hit=forRound(id);if(hit)startSession(hit.s,hit.t,null,hit.r);break;}
      case "copy":await copyFlow(false);break;
      case "stash":await copyFlow(true);break;
      case "recopy":await copyFlow(false,true);break;
      case "select-all":$("manual-copy").focus();$("manual-copy").select();$("manual-copy").setSelectionRange(0,$("manual-copy").value.length);break;
      case "example-paused":case "example-done":session.returnKind="template";raw=JSON.stringify(M.template(session.w,a==="example-paused"?"paused":"done"),null,2);$("returned").value=raw;$("paste-error").textContent="";toast("已用這次的選段試填，可以預覽。");break;
      case "try-talk":openTrial();break;
      case "accept-method":askTrial();break;
      case "switch-method":trial.switching=!trial.switching;render();break;
      case "pick-method":trial.method=Number(id);trial.switching=false;render();break;
      case "free-method":trial.method=6;askTrial();break;
      case "change-trial":trial.stage="recommend";trial.switching=true;render();break;
      case "answer-trial":answerTrial();break;
      case "finish-trial":finishTrial(false);break;
      case "pause-trial":finishTrial(true);break;
      case "validate":requirePreview();break;
      case "back-paste":go("exchange");break;
      case "save-result":await saveResult();break;
      case "filter":filter.status=id;for(const c of b.parentNode.querySelectorAll("button"))c.setAttribute("aria-pressed",String(c===b));$("found").innerHTML=resultList();break;
      case "clear-filters":filter={q:"",date:"",status:"全部"};render();break;
      case "show-original":$("original")?.scrollIntoView({block:"start"});break;
      case "jump-round":jumpRound(id);break;
      case "edit-source":sourceEdit=clone(source(id));go("sourceEdit");break;
      case "store-source-edit":{
        if(!sourceEdit.text.trim()||!sourceEdit.date){flag("edit-error","請保留原文，並選擇日記日期。");break;}
        const s=sourceEdit;
        if(await commit(d=>{const x=d.sources.find(v=>v.id===s.id);Object.assign(x,{text:s.text,title:s.title.trim()||M.head(s.text),date:s.date,version:x.version+1});})){go("detail",{id:s.id});toast(sourceOriginal(s.id)?"已儲存測試副本。":"已儲存原日記。");}break;}
      case "edit-round":{
        const {r,t}=forRound(id);editor={id,source:t.sourceId,summary:r.summary,understanding:r.understanding,initial:r.understanding,question:r.question,status:r.status,ok:!!r.understanding};go("edit");break;}
      case "store-edit":{
        const v=editor;
        if(!v.summary.trim()||(v.status==="paused"&&!v.question.trim())||(v.understanding.trim()&&!v.ok)){flag("edit-error","請補齊摘要與續談問題，並確認你要保留的理解。");break;}
        if(await commit(d=>{const r=d.threads.flatMap(t=>t.rounds).find(r=>r.id===v.id);const u=v.understanding.trim();if(u!==r.understanding)r.versions.push({text:u||"（已移除這版理解）",date:M.today()});Object.assign(r,{summary:v.summary.trim(),understanding:u,question:v.question.trim()});})){jumpRound(v.id);toast("已儲存修改。");}break;}
      case "archive":case "unarchive":{
        const tid=thread(id);if(await commit(d=>{d.threads.find(t=>t.id===id).archived=a==="archive";})){go("detail",{id:tid.sourceId},true);toast(a==="archive"?"已封存，仍可在回顧中找到。":"這次覺察已重新開啟。");}break;}
      case "ask-delete-thread":confirmDialog("刪除這次覺察？","將刪除這次覺察的所有輪次、引句、理解版本及信念連結。原日記會保留。","delete-thread",id);break;
      case "delete-thread":{
        const t=thread(id);if(!t)break;const ids=new Set(t.rounds.map(r=>r.id));close();
        if(await commit(d=>{d.threads=d.threads.filter(x=>x.id!==id);d.links=d.links.filter(l=>!ids.has(l.aRound)&&!ids.has(l.bRound));})){go("detail",{id:t.sourceId},true);toast("已刪除這次覺察。");}break;}
      case "ask-delete-source":{
        const ts=threadsFor(id),nr=ts.reduce((n,t)=>n+t.rounds.length,0),ids=new Set(ts.flatMap(t=>t.rounds.map(r=>r.id))),links=db.links.filter(l=>l.a===id||l.b===id||ids.has(l.aRound)||ids.has(l.bRound)).length;
        confirmDialog("移除這篇測試紀錄？","會從這個瀏覽器移除這篇紀錄，連同 "+nr+" 輪覺察的選段、問答、理解版本，以及 "+links+" 個關聯一起移除。來源頁仍會保留。","delete-source",id);break;}
      case "delete-source":{
        const ids=new Set(threadsFor(id).flatMap(t=>t.rounds.map(r=>r.id)));close();
        if(await commit(d=>{d.sources=d.sources.filter(s=>s.id!==id);d.threads=d.threads.filter(t=>t.sourceId!==id);d.links=d.links.filter(l=>l.a!==id&&l.b!==id&&!ids.has(l.aRound)&&!ids.has(l.bRound));})){go("history",{},true);toast("已移除這篇測試紀錄及其覺察。");}break;}
      case "relate":case "unlink":{
        const orig=view.args.id;if(await commit(d=>{
          const match=l=>l.kind==="related"&&((l.a===orig&&l.b===id)||(l.a===id&&l.b===orig));
          if(a==="unlink")d.links=d.links.filter(l=>!match(l));else if(!d.links.some(match))d.links.push({kind:"related",a:orig,b:id});
        })){render();toast(a==="unlink"?"已解除連結。":"已連結兩篇紀錄。");}break;}
      case "belief":selectBelief(id);break;
      case "add-belief":{
        const from=b.dataset.from;close();if(await commit(d=>{
          const exists=d.links.some(l=>l.kind==="belief"&&((l.aRound===from&&l.bRound===id)||(l.aRound===id&&l.bRound===from)));
          if(!exists)d.links.push({kind:"belief",aRound:from,bRound:id});
        })){jumpRound(from);toast("已連結兩次理解，各自保留原文與討論。");}break;}
    }
  });
  if(window.visualViewport){
    const syncKeyboard=()=>{const el=document.activeElement;const typing=!!el&&el.matches('textarea,input:not([type=checkbox]),select');document.body.classList.toggle("keyboard",typing&&innerHeight-visualViewport.height>120);};
    visualViewport.addEventListener("resize",syncKeyboard);window.addEventListener("focusout",syncKeyboard);
  }
  initialize();
})();
