/* The original conversation stays separate from new reflections and device edits. */
(() => {
  "use strict";

  function readTranscript(text) {
    const pieces=[];
    let role="unknown",lines=[];
    function finish(){
      const body=lines.join("\n").trim();
      if(body)pieces.push({role,text:body,form:"supplied"});
      lines=[];
    }
    for(const line of text.replace(/\r\n?/g,"\n").split("\n")){
      const label=line.match(/^\s*(?:(?:#{1,4}\s+)|(?:\*\*))?(我|你說|你說了|您說|使用者|本人|我說|You said|User|ChatGPT(?:\s*(?:說了|說|回答|said))?|GPT(?:\s*(?:說|回答))?|Assistant|助理|助手)(?:\*\*)?\s*[:：]\s*(?:\*\*)?(.*)$/i);
      if(!label){lines.push(line);continue;}
      finish();
      role=/^(?:我|你|您|使用者|本人|you|user)/i.test(label[1])?"user":"assistant";
      if(label[2])lines.push(label[2]);
    }
    finish();
    return pieces;
  }

  function sourcePassage(groups,groupId,position) {
    const group=groups.find(x=>x.id===groupId);
    if(!group)return null;
    const item=group.items[position];
    if(item?.role!=="user"||item.form==="summary"||!item.text)return null;
    const prompts=[];
    for(let j=position-1;j>=0&&group.items[j].role==="assistant";j--)prompts.unshift(group.items[j]);
    const mixed=prompts.length>1&&prompts.some(p=>p.form!==prompts[0].form);
    const question=prompts.map(p=>(mixed?(p.form==="summary"?"提問背景（大意）\n":"問句摘錄\n"):"")+p.text).join("\n\n");
    return {text:item.text,label:group.title,group:group.id,question,questionForm:mixed?"mixed":prompts[0]?.form||""};
  }

  function forSearch(groups) {
    return groups.flatMap(g=>[g.title,...g.items.map(item=>item.text)]).join(" ");
  }

  const api={readTranscript,sourcePassage,forSearch};
  globalThis.HeartArchive=api;
  if(typeof module!=="undefined"&&module.exports)module.exports=api;
})();
