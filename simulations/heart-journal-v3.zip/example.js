// Fictional records for the public preview. The browser generates its own device key.
(() => {
  const keySlot = 'lumen-dojo.public-heart-example.device.v1';
  let sessionKey;
  function deviceKey() {
    if (!sessionKey) {
      const bytes = crypto.getRandomValues(new Uint8Array(32));
      const fresh = btoa(String.fromCharCode(...bytes));
      try {
        sessionKey = localStorage.getItem(keySlot) || fresh;
        localStorage.setItem(keySlot, sessionKey);
      } catch {
        sessionKey = fresh;
      }
    }
    return sessionKey;
  }

  const opening = '等候排練時，我反覆檢查手上的節目單。輪到我說第一句前，肩膀一直抬得很高。';
  const note = '今早替陽臺的盆栽澆水時，看見新葉比昨天舒展了一點。我停下來畫了一張草圖。';
  const sources = [
    { id: 'practice', date: '2026-01-12', title: '排練前的五分鐘', category: '情緒覺察',
      text: opening, origin: '虛構對話', version: 1,
      ref: { kind: 'conversation', place: '本機虛構對話', field: '開場選段', note: '本例專為測試選段與逐輪問答而寫。' } },
    { id: 'leaf', date: '2026-01-11', title: '一片新葉', category: '感恩',
      text: note, origin: '虛構日記', version: 1,
      ref: { kind: 'journal', place: '本機虛構手札', field: '日記原文', note: '本例專為測試回顧與編輯而寫。' } }
  ];

  const histories = { practice: [
    { id: 'start', stage: 'opening', title: '排練開始前', items: [
      { role: 'user', form: 'summary', text: '等待上場時，示例中的敘事者開始留意身體的變化。' },
      { role: 'user', form: 'quote', text: opening }
    ] },
    { id: 'round-one', stage: 'round', title: '注意到什麼', items: [
      { role: 'assistant', form: 'quote', text: '什麼時候發現肩膀開始緊了？' },
      { role: 'user', form: 'quote', text: '前一個人放下樂譜時，我抬頭看了看大家，才發現手也握得很緊。' }
    ] },
    { id: 'round-two', stage: 'round', title: '試試另一個動作', items: [
      { role: 'assistant', form: 'summary', text: '邀請敘事者找一個當下做得到的小動作。' },
      { role: 'user', form: 'quote', text: '我把節目單放在椅子上，兩隻腳踩著地，慢慢說了第一句。' }
    ] },
    { id: 'end', stage: 'closing', title: '排練結束後', items: [
      { role: 'user', form: 'quote', text: '下次也想在等待的時候，留一點時間看看自己站得怎麼樣。' }
    ] }
  ] };

  globalThis.heartExample = () => ({ v: 1, storageId: 'synthetic-v1', sources, histories, deviceKey: deviceKey() });
})();
