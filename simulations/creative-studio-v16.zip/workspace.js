'use strict';

const scriptTools = {
  text:  { name: '研究與主文調整', hint: '從原稿與確認意圖，準備研究依據和主文。' },
  page:  { name: '生成逐頁圖文腳本', hint: '逐頁分開上版文字、圖像和製作備註。' },
  comic: { name: '生成漫畫分格腳本', hint: '按格安排可畫出的動作、對白與轉折。' },
  film:  { name: '生成分鏡與時間腳本', hint: '安排鏡頭、動作、時長、字幕與聲音。' },
  audio: { name: '生成口播稿或訪綱', hint: '按段準備口播、主問、追問及聲音提示。' }
};

function studioAction(w, label, module, detail) {
  const b = module === 'B';
  return '<button class="studio-tool'+(b?' main-tool':'')+'" title="'+esc(detail)+'"'+act('creativeTool', w.id, module)+'>'+
    '<span class="module-letter">'+esc(module.charAt(0))+'</span>'+
    '<span><strong>'+esc(label)+'</strong><small>'+esc(detail)+'</small></span></button>';
}

function studioCollaboration(w) {
  const tool=scriptTools[w.type];
  const actions=[[tool.name,'B',tool.hint],
    ['診斷'+aForm(w).draft,'A','從本件取材起稿，或用現有稿辨認結構問題、確認意圖。']];
  if(w.type==='text'&&w.versions.length)actions.push(['轉譯確定稿','C','選長文節奏擴寫，或濃縮成限動金句。']);
  const buttons=actions.map(([label,mod,hint])=>studioAction(w,label,mod,hint)).join('');
  const guide='<details class="tool-guide"><summary>工具用法</summary>'+
    actions.map(([label,mod,hint])=>'<p><b>'+esc(mod+' · '+label)+'</b>　'+esc(hint)+'</p>').join('')+'</details>';
  return '<section class="panel collab-panel"><div class="sectionhead"><h2>作品協作</h2></div><div class="studio-tools">'+
    buttons+'</div>'+guide+workCardButton(w)+'</section>';
}

function versionTools(w, v) {
  const action=(label,mod)=>btn(label,'creativeTool',[w.id,mod,v.n],'tiny');
  return (w.type==='text'?action('C · 長文節奏擴寫','C-expand')+action('C · 濃縮限動金句','C-auto'):'')+
    action('D · 建立知識脈絡','D')+
    btn('作品心智圖','dOpenMap',[w.id,v.n],'tiny');
}

function shuttleWorkRows(s) {
  const items=state.works.filter(w=>w.shuttle===s.id).sort((a,b)=>b.updated-a.updated);
  const rows=items.map(w=>{
    const v=w.versions.filter(v=>v.data.shuttle===s.id).at(-1);
    return '<div class="shuttle-work">'+workRow(w)+(v?'<div class="actions">'+
      btn('下載定稿 V'+v.n,'downloadEdition',[w.id,v.n],'tiny')+
      btn('從 V'+v.n+' 建立知識脈絡','creativeTool',[w.id,'D',v.n],'tiny')+
      (dMappedRounds(w,v.n).length?btn('查看作品心智圖','dOpenMap',[w.id,v.n],'tiny'):'')+'</div>':'')+'</div>';
  });
  const visible=rows.slice(0,3).join('')+(rows.length>3?more('其餘 '+(rows.length-3)+' 件作品',rows.slice(3).join('')):'');
  const earlier=state.works.filter(w=>w.shuttle!==s.id).flatMap(w=>
    w.versions.filter(v=>v.data.shuttle===s.id).map(v=>row(v.data.title+' · V'+v.n,'定稿時歸入這把杼',TYPES[w.type].icon,'seeVer',[w.id,v.n]))).join('');
  return (visible||'<p>還沒有作品，可以從這把杼開始第一件。</p>')+(earlier?more('曾在這把杼定稿',earlier):'');
}

handlers.continueWork = id => {
  const w=findW(id);
  if(!w)return;
  wk=id;
  tab=stateOf(w)==='已定稿'?'預覽與定稿':'製作';
  go('edit/'+id);
};

handlers.creativeTool=(id,module,n)=>{
  const w=findW(id);
  if(!w)return;
  if(module==='B'&&w.type!=='text')openMediaB(w);
  else openDiamond(w,module,n);
};
function workManage(w){
  const buttons=w.shelf?btn('還原作品','moveWork',[w.id,'']):btn('封存作品','moveWork',[w.id,'已封存']);
  return '<div class="work-management" role="group" aria-label="作品管理">'+buttons+
    (w.shelf==='最近刪除'?'':btn('刪除作品','askDeleteWork',[w.id],'delete-work'))+'</div>';
}
handlers.askDeleteWork=id=>{
  const w=findW(id);
  if(w)modal('刪除作品？','<p>「'+esc(nameW(w))+'」將移至「最近刪除」，可在我的作品中還原。</p>'+
    btn('取消','cancelWorkDelete')+' '+btn('確認刪除','moveWork',[id,'最近刪除'],'primary'));
};
handlers.cancelWorkDelete=()=>$('dialog').close();
handlers.moveWork=(id,shelf)=>{
  const w=findW(id);
  if(!w||!['','已封存','最近刪除'].includes(shelf))return;
  const active=state.works,stored=state.workShelf||[],previous=w.shelf;
  state.works=active.filter(item=>item.id!==id);
  state.workShelf=stored.filter(item=>item.id!==id);
  w.shelf=shelf;
  (shelf?state.workShelf:state.works).unshift(w);
  save();
  if(!storageOK){state.works=active;state.workShelf=stored;w.shelf=previous;toast('未能保存這次操作，請重試');return;}
  delete drafts[id];
  filter=topicFilter=seriesFilter='全部';progressFilter=shelf||'全部';
  go('works');toast(shelf||'已還原作品');
};
const studioVisit=window.history?.state;
if(studioVisit?.studioPath===location.hash.slice(1)&&studioVisit?.studioPath?.startsWith('edit/')&&studioVisit.workTab){
  wk=studioVisit.studioPath.split('/')[1];tab=studioVisit.workTab;
}
render();
