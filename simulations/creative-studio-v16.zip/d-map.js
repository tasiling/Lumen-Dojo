'use strict';

const dAxes = ['垂直深挖','水平平移','反面驗證','跨系統嫁接'];
const dPaths = ['想更深入這個主題','想探索其他方向','準備好行動了'];
const dViews = {topics:'四軸題目',links:'跨題連結',paths:'讀者路徑'};

function dExample(w,v) {
  const quote='紙橋中央放入第一顆積木，再觀察彎曲的位置。';
  if(w.id!=='return-text'||v.n!==1||!v.data.body?.includes(quote))return null;
  const nodes=[
    ['紙橋最先從哪裡彎曲？','固定橋距，記下加入第一顆積木時的變形位置。'],
    ['把同樣的紙折成波浪會有什麼變化？','保持紙張和橋距相同，測試第二種折法。'],
    ['縮短橋距後，原先的觀察還成立嗎？','換用較短的橋距，再測量兩種折法。'],
    ['在週盤記錄兩輪測試','在週盤填寫兩次觀察時間與紙橋承重。']
  ].map(([title,detail],i)=>({axis:dAxes[i],title,detail,source:quote}));
  return {id:'example',n:v.n,mode:'D',checked:true,example:true,title:v.data.title,shuttleId:v.data.shuttle,
    source:v.data.body,nodes,connections:'「'+nodes[1].title+'」↔「'+nodes[2].title+'」｜兩題都要確認，改動哪個條件會影響紙橋的承重。',
    futures:dPaths.map((p,i)=>[p,nodes[[0,2,3][i]].title,nodes[[0,2,3][i]].detail].join('\n')).join('\n\n')};
}
function dMappedRounds(w,n) {
  return (w.diamondRuns||[]).filter(r=>r.mode==='D'&&r.n===n&&r.checked&&Array.isArray(r.nodes)&&r.nodes.length);
}
function dTryExample(c) {
  if(!c?.example||c.w.shelf)return;
  const {w,v,example}=c;
  let run=c.runs.find(r=>r.fromMapExample);
  if(!run){
    const first=example.nodes.map(n=>[n.axis,n.title,n.detail,'來源：「'+n.source+'」'].join('\n')).join('\n\n');
    const raw=['第一層：候選節點清單\n'+first,'第二層：跨主題連接\n'+example.connections,'第三層：優先順序建議\n'+example.futures].join('\n\n');
    run={...example,id:uid(),example:false,fromMapExample:true,workId:w.id,baseBody:w.body,stage:'示例試作',
      prompt:diamondOriginalPrompt('D',{body:v.data.body,systems:'週盤'}),raw};
    (w.diamondRuns||=[]).push(run);keep(w);
  }
  go(dMapURL(w,v.n,run.id));
}
function dMapURL(w,n,rid='') {
  return 'd-map/'+[w.id,n,...(rid?[rid]:[])].map(encodeURIComponent).join('/');
}
function dMapContext(params=args) {
  const [id,num,rid]=params.map(x=>{try{return decodeURIComponent(x)}catch{return ''}});
  const w=findW(id),v=version(w,num);
  if(!v)return null;
  const runs=dMappedRounds(w,v.n),example=dExample(w,v);
  const r=rid==='example'?example:rid?runs.find(x=>x.id===rid):runs.at(-1);
  return {w,v,r,runs,example,rid,readOnly:!!w.shelf||!!r?.example};
}
function dTitleKey(value) {
  return String(value||'').trim().replace(/^[#\s>*•-]+/,'').replace(/\*\*/g,'')
    .replace(/^[「『【《（(]+|[」』】》）)]+$/g,'').trim();
}
function dPathEntries(r) {
  const bodies=dPaths.map(()=>[]);let section=-1;
  for(const line of (r.futures||'').split(/\r?\n/)){
    const label=dTitleKey(line).replace(/[：:]$/,'').trim();
    const index=dPaths.indexOf(label);
    if(index>=0){section=index;continue;}
    if(section>=0&&line.trim())bodies[section].push(line.trim());
  }
  return bodies.map((lines,i)=>{
    const original=lines.join('\n'),key=dTitleKey(lines[0]);
    const matches=r.nodes.flatMap((node,n)=>key&&dTitleKey(node.title)===key?[n]:[]);
    return {label:dPaths[i],text:original,index:matches.length===1?matches[0]:null,detail:lines.slice(1).join('\n')};
  });
}
function dRelationships(r) {
  const lines=(r.connections||'').split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  const records=[];
  for(const line of lines){
    const quoted=[...line.matchAll(/「([^」]+)」|『([^』]+)』|《([^》]+)》/g)].map(m=>m[1]||m[2]||m[3]);
    const named=r.nodes.map((n,i)=>({i,title:n.title})).filter(n=>n.title&&(quoted.length?quoted.includes(n.title):line.includes(n.title)));
    const titles=named.map(n=>n.title);
    const unambiguous=named.length===2&&titles[0]!==titles[1]&&(quoted.length>0||
      (!titles[0].includes(titles[1])&&!titles[1].includes(titles[0])));
    const negative=/沒有.{0,16}(關聯|關係|連接|連結|呼應)|(?:並無|尚無|無法確認|看不出).{0,10}(關係|關聯|連結|連接)|彼此無關/.test(line);
    // An unlabelled explanation belongs to the preceding pair. Preserve unassigned text as a note.
    if(!named.length&&!negative&&records.length&&records.at(-1).pair&&!/^[#•*-]|^這幾個節點|^目前/.test(line)){
      records.at(-1).text+='\n'+line;
    }else{
      records.push({pair:unambiguous&&!negative?named.map(n=>n.i):null,text:line});
    }
  }
  return records;
}
function dPoolNode(w,r,node) {
  return (w.diamondPool||[]).find(o=>o.n===r.n&&o.axis===node.axis&&o.title===node.title&&o.source===node.source);
}
function dVerified(r,node){return !!node?.source&&typeof r.source==='string'&&r.source.includes(node.source);}
function dNodeStatus(c,node){
  if(!dVerified(c.r,node))return '原句待核對';
  const saved=!c.r.example&&dPoolNode(c.w,c.r,node);
  if(saved?.understandings?.length)return '已用於方向理解';
  if(saved?.direction)return '已發展為方向';
  return saved?'已留待寫':'候選';
}
function dFindQuote(c,node) {
  if(!dVerified(c.r,node))return [];
  const source=c.r.source,quote=node.source, isText=c.w.type==='text';
  const positions=[], breaks=isText?/\r?\n[ \t]*\r?\n+/g:/\r?\n/g;
  let start=0,tag='',part=0,match;
  function segment(end){
    const text=source.slice(start,end);
    if(!text.trim())return;
    part++;
    if(isText)tag='第 '+part+' 段';
    else {
      const marks=text.match(/第\s*[\d一二三四五六七八九十百兩]+\s*[頁格鏡章段]|(?:\d{1,2}:){1,2}\d{2}(?:\s*[-–～至]\s*(?:\d{1,2}:){1,2}\d{2})?/g);
      if(marks)tag=marks.join(' · ');
    }
    positions.push({start,end,tag:tag||'本輪核對的文字',text});
  }
  while((match=breaks.exec(source))){segment(match.index);start=breaks.lastIndex;}
  segment(source.length);
  const found=[];
  for(let offset=source.indexOf(quote);offset!==-1;offset=source.indexOf(quote,offset+quote.length)){
    const begin=positions.find(p=>p.end>offset),last=positions.find(p=>p.end>=offset+quote.length);
    if(!begin||!last)continue;
    const tag=begin.tag===last.tag?begin.tag:begin.tag+' 至 '+last.tag;
    found.push({tag,before:source.slice(begin.start,offset),after:source.slice(offset+quote.length,last.end)});
  }
  return found;
}
function dDecisionKey(kind,entry,r){
  const ids=kind==='links'?entry.pair:[entry.index];
  if(!ids||!ids.every(i=>Number.isInteger(i)&&dVerified(r,r.nodes[i])))return '';
  return JSON.stringify([kind,entry.label||'',entry.text,ids.map(i=>[r.nodes[i].axis,r.nodes[i].title,r.nodes[i].source])]);
}
function dAccepted(c,key){return !c.r.example&&!!key&&(c.r.mapDecisions||[]).includes(key);}
function dCandidate(c){return c.r.example||c.r.fromMapExample?'示例候選':'GPT 候選';}
function dUnderstandingSource(d,n) {
  const src=d.mapSources?.[n],w=src&&findW(src.workId);
  return w?btn('來源作品 V'+src.n+' · 查看心智圖','dOpenMap',[w.id,src.n,src.runId,src.index],'link'):'';
}
function dMapPage(params) {
  const c=dMapContext(params);
  if(!c)return missing();
  const {w,v,r,runs,example}=c;
  const backButton=btn('‹　預覽與定稿','dBackToEdition',[w.id],'back');
  const heading='<header class="pagehead"><h1>作品心智圖</h1><p>'+esc(v.data.title||nameW(w))+' · 定稿 V'+v.n+'</p></header>';
  const start=()=>w.shelf?'':btn('用這個版本開始 D 分析','creativeTool',[w.id,'D',v.n],'primary');
  if(!r){
    const resume=(w.diamondRuns||[]).filter(z=>z.mode==='D'&&z.n===v.n&&!z.checked).at(-1);
    const next=resume&&!w.shelf?btn('接續這輪 D 分析','diamondRun',[w.id,resume.id],'primary'):start();
    return backButton+heading+panel(c.rid?'這輪心智圖未儲存在此瀏覽器':'這版還沒有 D 分析',
      '<p>把 D 的三層分析貼回來，核對後就能在圖上追到每個題目的原句。</p><div class="actions">'+next+
      (example?btn('看這件作品的示例圖','dOpenMap',[w.id,v.n,'example'],'light'):'')+
      (runs.length?btn('查看本版已保存的心智圖','dOpenMap',[w.id,v.n],'light'):'')+'</div>');
  }
  const roundLabel=r.example?'示例分析':((r.fromMapExample?'示例試作':'D 分析')+' · 第 '+(runs.indexOf(r)+1)+' 輪');
  const switcher=runs.length>1||r.example&&runs.length?'<label class="d-round">分析輪次 <select id="dMapRound">'+
    (r.example?'<option value="example">示例分析</option>':'')+
    runs.map((x,i)=>'<option value="'+esc(x.id)+'"'+(x.id===r.id?' selected':'')+'>第 '+(i+1)+' 輪</option>').join('')+'</select></label>':'';
  return '<div class="d-map">'+backButton+heading+'<section class="panel d-surface"><div class="d-map-head"><span>'+esc(roundLabel)+'</span>'+switcher+'</div>'+
    '<div class="d-view-tabs" role="group" aria-label="心智圖內容">'+Object.entries(dViews).map(([k,l])=>choiceButton(l,'dMapView',[k],k==='topics')).join('')+
    '</div><div id="dMapBody"></div></section><div class="d-foot">'+
    more('匯出心智圖','<div class="actions">'+btn('下載 Markdown','dMapExport',['md'],'light')+btn('下載 SVG 圖檔','dMapExport',['svg'],'light')+'</div>')+
    (r.example?'<p>這份示例取自作品 V'+v.n+'。另存一輪就可以試著採用連結或補入自己的理解。</p>'+
      (w.shelf?'':btn(runs.some(x=>x.fromMapExample)?'接續我的示例試作':'另存示例，開始試作','dMapTry',[],'primary')):
      btn('查看這輪完整 D 回覆','diamondRun',[w.id,r.id],'link'))+'</div></div>';
}

let dMapView='topics', dMapAt='', dMapFocus=null, dCollapsed=new Set(), dResize=null;
function mountDMap() {
  const host=$('dMapBody'),c=dMapContext();
  dResize?.disconnect();dResize=null;
  if(!host||!c?.r)return;
  const key=JSON.stringify([c.w.id,c.r.n,c.r.id]);
  if(dMapAt!==key){dMapView='topics';dCollapsed=new Set();dMapAt=key;}
  const picker=$('dMapRound');
  if(picker)picker.onchange=()=>go(dMapURL(c.w,c.v.n,picker.value));
  dPaint(c);
  if(window.ResizeObserver){
    let width=host.clientWidth;
    const observer=new ResizeObserver(()=>{
      if(!host.isConnected){observer.disconnect();return;}
      if(host.clientWidth!==width){width=host.clientWidth;if(dMapView==='topics')dPaint(c);}
    });
    dResize=observer;observer.observe(host);
  }
  if(dMapFocus!==null){
    const index=dMapFocus;dMapFocus=null;
    if(c.r.nodes[index])dShowNode(c,index);
  }
}
function dGraphItems(c) {
  return dAxes.map(a=>[a,c.r.nodes.flatMap((node,i)=>node.axis===a?[{id:i,group:a,label:node.title,body:node.detail,source:node.source}]:[])]).filter(([,items])=>items.length);
}
function dPaint(c){
  const host=$('dMapBody');if(!host||!c?.r)return;
  document.querySelectorAll('.d-view-tabs button').forEach(b=>{
    const on=JSON.parse(b.dataset.args)[0]===dMapView;b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on));
  });
  host.replaceChildren();
  if(dMapView==='topics'){
    const groups=dGraphItems(c);
    const screenGroups=groups.map(([axis,items])=>[axis,items.map(it=>{const status=dNodeStatus(c,c.r.nodes[it.id]);
      return status==='候選'?it:{...it,label:it.label+'（'+status+'）'};})]);
    const image=drawDMap({width:Math.max(240,Math.min(960,host.clientWidth||360)),title:(c.v.data.title||nameW(c.w))+' · V'+c.v.n,
      groups:screenGroups,collapsed:dCollapsed,activeId:null,exporting:false,activate:i=>dShowNode(c,i),toggle:name=>{
        if(dCollapsed.has(name))dCollapsed.delete(name);else dCollapsed.add(name);
        dPaint(c);[...host.querySelectorAll('[aria-expanded]')].find(e=>e.getAttribute('aria-label').startsWith(name+'，'))?.focus({preventScroll:true});
      }});
    host.append(image);
    const hint=document.createElement('p');hint.className='sub';hint.textContent='點題目看原句，點軸線名稱可收合。';host.append(hint);
  }else if(dMapView==='links'){
    host.innerHTML=dRelationships(c.r).map((link,i)=>{
      if(!link.pair)return '<p class="d-unmatched">'+esc(link.text)+'</p>';
      const key=dDecisionKey('links',link,c.r);
      return '<article class="d-relation"><div class="d-ends">'+dNodeButton(c,link.pair[0])+'<span aria-label="相互連結">↔</span>'+dNodeButton(c,link.pair[1])+'</div>'+
        '<p>'+esc(dLinkReason(link))+'</p>'+dDecisionAction(c,'links',i,key)+'</article>';
    }).join('')||'<p>這輪尚無跨題連結。</p>';
  }else{
    host.innerHTML=dPathEntries(c.r).map((path,i)=>{
      const linked=path.index!==null,key=dDecisionKey('paths',path,c.r);
      return '<article class="d-path"><h3>'+esc(path.label)+'</h3>'+
        (linked?dNodeButton(c,path.index)+(path.detail?'<p>'+esc(path.detail)+'</p>':'')+dDecisionAction(c,'paths',i,key):
          '<p>'+esc(path.text||'本輪尚無對應題目。')+'</p>')+'</article>';
    }).join('');
  }
}
function dNodeButton(c,i){return btn(c.r.nodes[i].title,'dMapNode',[i],'d-node-link');}
function dLinkReason(link){const cut=link.text.indexOf('｜');return cut>=0?link.text.slice(cut+1).trim()||link.text:link.text;}
function dDecisionAction(c,kind,i,key){
  const accepted=dAccepted(c,key),label=kind==='links'?'這條連結':'這條路徑';
  return '<div class="d-decision"><small>'+(!key?'來源待核對':accepted?'本人已採用':dCandidate(c))+'</small>'+
    (!c.readOnly&&key?btn(accepted?'撤回採用':'採用'+label,'dMapDecision',[kind,i],'link'):'')+'</div>';
}
function dShowNode(c,i){
  const node=c.r.nodes[i];if(!node)return;
  const clips=dFindQuote(c,node),saved=!c.r.example&&dPoolNode(c.w,c.r,node);
  let sources=clips.length?'<blockquote>'+esc(node.source)+'</blockquote>'+more('查看原句上下文',
    clips.map(x=>'<div class="d-passage"><b>'+esc(x.tag)+'</b><p>'+esc(x.before)+'<mark>'+esc(node.source)+'</mark>'+esc(x.after)+'</p></div>').join('')):
    '<blockquote>'+esc(node.source)+'</blockquote><p class="sub">這段引句與本輪帶出的定稿文字對不上。</p>';
  const same=c.v.data.shuttle&&findS(c.v.data.shuttle);
  const actions=!c.readOnly&&clips.length?'<div class="actions">'+
    (!saved?btn('留在待寫池','dMapKeep',[i],'light'):'')+
    (same?.dirs.length?btn('接回既有方向','dMapUse',[i],'primary'):'')+'</div>':'';
  const uses=(saved?.understandings||[]).map(u=>{const s=findS(u.shuttleId),d=s?.dirs.find(z=>z.id===u.directionId);
    return d?'<p class="d-used">'+esc(d.name)+' · 理解 V'+u.revision+'<br>'+esc(d.vs[u.revision-1])+'</p>':'';}).join('');
  modal(node.title,'<div class="d-node-detail"><p class="d-meta">'+esc(node.axis)+' · '+esc(dNodeStatus(c,node))+'</p><p>'+esc(node.detail)+'</p>'+
    '<h3>這個題目從哪裡來</h3><p class="sub">'+esc(c.v.data.title||nameW(c.w))+' · V'+c.v.n+(clips.length?' · '+esc([...new Set(clips.map(x=>x.tag))].join('、')):'')+'</p>'+sources+
    btn('查看這版成品','seeVer',[c.w.id,c.v.n],'link')+uses+actions+'</div>');
}
function dKeepNode(c,node){
  let saved=dPoolNode(c.w,c.r,node);
  if(!saved){saved={...node,id:uid(),n:c.v.n,workId:c.w.id,shuttleId:c.v.data.shuttle||'',workTitle:c.v.data.title||nameW(c.w),runId:c.r.id};
    (c.w.diamondPool||=[]).push(saved);}
  return saved;
}
function dUseForm(c,i) {
  const s=findS(c.v.data.shuttle),node=c.r.nodes[i];
  if(!s?.dirs.length||!dVerified(c.r,node)||c.readOnly)return;
  modal('接回既有方向','<p>'+esc(s.title)+'</p><blockquote>'+esc(node.source)+'</blockquote>'+
    diamondSelect('這次補進哪一個方向？','dUseDirection',{'':'請選方向',...Object.fromEntries(s.dirs.map(d=>[d.id,d.name]))},'')+
    '<div id="dOldUnderstanding"></div>'+field('用過這件作品後，我對這個方向多懂了什麼？','dUseText','',true)+
    btn('保存為新版理解','dMapSaveUse',[i],'primary')+' '+btn('回到題目','dMapNode',[i],'tiny'));
  $('dUseDirection').onchange=()=>{const d=s.dirs.find(x=>x.id===val('dUseDirection'));$('dOldUnderstanding').textContent=d?.vs.length?'目前理解 V'+d.vs.length+' · '+d.vs.at(-1):'';};
}
function dSaveUse(c,i){
  const s=findS(c.v.data.shuttle),d=s?.dirs.find(x=>x.id===val('dUseDirection')),note=val('dUseText'),node=c.r.nodes[i];
  if(c.readOnly||!dVerified(c.r,node))return;
  if(!d||!note){toast('請選一個方向，並用自己的話留下這次的理解。');return;}
  const saved=dKeepNode(c,node);
  const again=(saved.understandings||[]).find(x=>x.shuttleId===s.id&&x.directionId===d.id&&d.vs[x.revision-1]===note);
  if(!again){
    const revision=d.vs.push(note);
    (d.mapSources||={})[revision]={workId:c.w.id,n:c.v.n,runId:c.r.id,index:i,quote:node.source};
    (saved.understandings||=[]).push({shuttleId:s.id,directionId:d.id,revision});
    c.r.locked=true;c.r.stage='已用於方向理解';
    save();
  }
  dPaint(c);dShowNode(c,i);toast(storageOK?'已接回「'+d.name+'」':'這次的理解暫存在本次開啟期間。');
}

// Keep the additional two layers in exports, even when the author views one branch at a time.
function dExportGroups(c) {
  const {r}=c;
  const groups=dGraphItems(c).map(([axis,items])=>[axis,items.map(item=>{
    const node=r.nodes[item.id],places=[...new Set(dFindQuote(c,node).map(p=>p.tag))].join('、');
    const saved=!r.example&&dPoolNode(c.w,r,node);
    const uses=(saved?.understandings||[]).map(u=>{
      const d=findS(u.shuttleId)?.dirs.find(x=>x.id===u.directionId);
      return d?'本人理解 · '+d.name+' V'+u.revision+' · '+(d.vs[u.revision-1]||''):'';
    }).filter(Boolean);
    return {...item,label:item.label+'（'+dNodeStatus(c,node)+'）',body:[node.detail,...uses].join('\n'),
      source:(places?places+' · ':'')+node.source};
  })]);
  groups.push(['跨題連結',dRelationships(r).map((link,i)=>{
    const pair=link.pair,key=dDecisionKey('links',link,r);
    return {id:'l'+i,label:pair?pair.map(n=>r.nodes[n].title).join(' ↔ '):'本輪說明',
      body:(pair?(!key?'來源待核對':dAccepted(c,key)?'本人已採用':dCandidate(c))+' · ':'')+dLinkReason(link),source:''};
  })],['讀者路徑',dPathEntries(r).map((p,i)=>({
    id:'p'+i,label:p.label,body:(p.index!==null?(!dVerified(r,r.nodes[p.index])?'來源待核對':dAccepted(c,dDecisionKey('paths',p,r))?'本人已採用':dCandidate(c))+' · ':'')+(p.text||'本輪尚無對應題目。'),source:''
  }))]);
  return groups.filter(([,items])=>items.length);
}
function dCleanMarkdown(text) {
  return String(text||'').replace(/\s+/g,' ').trim().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/([\\\[\]*_\x60#|~!])/g,'\\$1');
}
function dExport(c,format) {
  const roundName=c.r.example?'示例':(c.r.fromMapExample?'示例試作 · ':'')+'第 '+(c.runs.indexOf(c.r)+1)+' 輪';
  const title=(c.v.data.title||nameW(c.w))+' · V'+c.v.n+' · '+roundName;
  const groups=dExportGroups(c);
  let data,mime,ext;
  if(format==='md'){
    const lines=['---','title: '+JSON.stringify(title.replace(/\s+/g,' ').trim()),'markmap:','  colorFreezeLevel: 2','  maxWidth: 300','---','','# '+dCleanMarkdown(title)];
    for(const [group,items] of groups){
      lines.push('','## '+dCleanMarkdown(group));
      for(const item of items){
        lines.push('- '+dCleanMarkdown(item.label));
        for(const line of item.body.split('\n').filter(Boolean))lines.push('  - '+dCleanMarkdown(line));
        if(item.source)lines.push('  - 來源 · '+dCleanMarkdown(item.source));
      }
    }
    data=lines.join('\n')+'\n';mime='text/markdown;charset=utf-8';ext='.mindmap.md';
  }else if(format==='svg'){
    // SVG descriptions retain the full evidence. Embed link reasons and reader destinations visibly.
    const printable=groups.map(([group,items])=>[group,items.map(it=>it.source?it:{...it,label:it.label+' · '+it.body})]);
    const svg=drawDMap({width:850,title,groups:printable,collapsed:new Set(),activeId:null,exporting:true});
    data=new XMLSerializer().serializeToString(svg);mime='image/svg+xml;charset=utf-8';ext='.svg';
  }else return;
  releaseDownload();
  downloadUrl=URL.createObjectURL(new Blob([data],{type:mime}));
  modal('匯出作品心智圖','<p>'+esc(title)+'</p><a class="download-file" id="dMapFile">下載'+(format==='md'?' Markmap 大綱':' SVG 圖檔')+'</a>');
  const file=$('dMapFile');file.href=downloadUrl;file.download=title.replace(/[\\/:*?"<>|\u0000-\u001f]/g,'_').slice(0,96)+ext;
}
Object.assign(handlers,{
  dOpenMap:(id,n,rid,index)=>{
    const w=findW(id);if(!version(w,n))return;
    dMapFocus=Number.isInteger(index)?index:null;go(dMapURL(w,n,rid));
  },
  dBackToEdition:id=>handlers.diaReview(id),
  dMapTry:()=>dTryExample(dMapContext()),
  dMapView:view=>{
    if(!Object.hasOwn(dViews,view))return;
    const c=dMapContext();if(!c?.r)return;
    dMapView=view;dPaint(c);
  },
  dMapNode:i=>{const c=dMapContext();if(c?.r)dShowNode(c,i);},
  dMapDecision:(kind,i)=>{
    const c=dMapContext();if(!c?.r||c.readOnly||!['links','paths'].includes(kind))return;
    const entry=(kind==='links'?dRelationships(c.r):dPathEntries(c.r))[i];
    const key=entry&&dDecisionKey(kind,entry,c.r);if(!key)return;
    const decisions=c.r.mapDecisions||[];
    const previously=dAccepted(c,key);
    c.r.mapDecisions=previously?decisions.filter(x=>x!==key):[...decisions,key];
    c.r.locked=true;c.r.stage='已核對心智圖';save();dPaint(c);
    const matching=[...$('dMapBody').querySelectorAll('[data-act="dMapDecision"]')].find(b=>b.dataset.args===JSON.stringify([kind,i]));matching?.focus({preventScroll:true});
    if(storageOK)toast(previously?'已改回候選。':'已記下你的採用決定。');
  },
  dMapKeep:i=>{
    const c=dMapContext();if(!c?.r||c.readOnly||!dVerified(c.r,c.r.nodes[i]))return;
    dKeepNode(c,c.r.nodes[i]);c.r.locked=true;c.r.stage='已存入待寫池';save();dPaint(c);dShowNode(c,i);
    toast(storageOK?'已留在這件作品的待寫池。':'暫存在本次開啟期間。');
  },
  dMapUse:i=>{const c=dMapContext();if(c?.r)dUseForm(c,i);},
  dMapSaveUse:i=>{const c=dMapContext();if(c?.r)dSaveUse(c,i);},
  dMapExport:format=>{const c=dMapContext();if(c?.r)dExport(c,format);}
});

