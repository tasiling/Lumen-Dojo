'use strict';

function hasUnitContent(type,u) {
  return !!(u.image||u.body?.trim()||(type!=='comic'&&u.heading?.trim()));
}

function saveWorkEdition(id,n) {
  const w=current();
  if(!w||w.shelf||(id&&w.id!==id)||(n&&n!==w.versions.length+1)||!findS(w.shuttle)||
    !actionable(w)||stateOf(w)==='已定稿')return;
  const previous={title:w.title,review:w.review,updated:w.updated};
  if(!w.title.trim())w.title='未命名'+TYPES[w.type].name;
  const v=snapshot(w);
  v.origin=workContext(w);
  w.versions.push(v);w.review=false;keep(w);
  if(!storageOK){w.versions.pop();Object.assign(w,previous);toast('未能保存定稿，請重試');return;}
  closeRefresh('已定稿 V'+v.n);
}

function editionOrigin(v) {
  const d=v.data,origin=v.origin||workContext(d);
  if(!origin.shuttle)return '';
  const details=[origin.shuttle,origin.direction,d.understanding?'理解 V'+d.understanding.n:''].filter(Boolean);
  const cards=origin.cards.map(c=>'<article><b>'+esc(c.title)+'</b><small>'+esc([c.source,c.location,c.author].filter(Boolean).join(' · '))+
    '</small><blockquote>'+esc(c.quote)+'</blockquote></article>').join('');
  return '<details class="creation-reference"><summary>定稿時的歸屬與取材</summary><p>'+esc(details.join(' ／ '))+'</p>'+
    (d.coreSnapshot?.text?'<p>經線 V'+d.coreSnapshot.n+' · '+esc(d.coreSnapshot.text)+'</p>':'')+
    (d.understanding?.text?'<p>'+esc(d.understanding.text)+'</p>':'')+cards+'</details>';
}

function graphicEdition(data,images) {
  const comic=data.type==='comic';
  const items=data.units.map((u,i)=>{
    const alt=(comic?'第 '+(i+1)+' 格':'第 '+(i+1)+' 頁')+'圖片';
    const img=u.image?'<img '+(images?'src="'+esc(images.get(u.image))+'"':'data-blob="'+esc(u.image)+'"')+' alt="'+alt+'">':'';
    const caption=[u.body&&u.speaker,u.body].filter(Boolean).join('　');
    // Older trial versions could fix a storyboard with scene instructions alone.
    const sketch=comic&&!img&&!caption?'<p class="folio-sketch">分鏡稿 · '+esc(u.heading)+'</p>':'';
    const heading=!comic&&u.heading?'<strong>'+esc(u.heading)+'</strong>':'';
    const classes=[comic?'comic-frame':'graphic-page',u.tone==='墨藍'?'ink':u.tone==='青綠'?'green':'',
      u.layout==='封面'?'cover':u.layout==='對話'?'dialogue':u.layout==='雜誌'?'magazine':''].join(' ');
    return '<figure class="'+classes+'">'+img+heading+sketch+(caption?'<figcaption>'+esc(caption)+'</figcaption>':'')+'</figure>';
  }).join('');
  return '<div class="fixed-book '+(comic?(data.mode==='四格漫畫'?'comic-book four':'comic-book'):'page-book')+'">'+items+'</div>';
}

async function mediaBlob(id) {
  const url=await blobURL(id);
  if(!url)throw Error('找不到這一版使用的檔案。請在原先保存作品的瀏覽器下載。');
  const response=await fetch(url);
  if(!response.ok)throw Error('讀取檔案失敗，請重新開啟這一版。');
  return response.blob();
}
function fileDataURL(blob) {
  return new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onload=()=>resolve(reader.result);
    reader.onerror=()=>reject(Error('圖片無法讀取，請重新確認原檔。'));
    reader.readAsDataURL(blob);
  });
}
function loadPicture(url) {
  return new Promise((resolve,reject)=>{
    const img=new Image();
    img.onload=()=>resolve(img);img.onerror=()=>reject(Error('有一張格圖無法解碼，可改下載完整排版檔。'));
    img.src=url;
  });
}

async function graphicDocument(data) {
  const images=new Map();
  for(const id of new Set(data.units.map(u=>u.image).filter(Boolean)))
    images.set(id,await fileDataURL(await mediaBlob(id)));
  const style=await fetch('edition.css');
  if(!style.ok)throw Error('無法載入作品版面，請再試一次。');
  const html='<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+
    esc(data.title)+'</title><style>'+await style.text()+'</style><body class="standalone-edition"><main><h1>'+
    esc(data.title)+'</h1>'+graphicEdition(data,images)+'</main></body></html>';
  return new Blob([html],{type:'text/html;charset=utf-8'});
}

function wrapCanvas(ctx,text,width) {
  const lines=[];
  for(const paragraph of text.split(/\r?\n/)){
    let line='';
    for(const char of Array.from(paragraph)){
      if(line&&ctx.measureText(line+char).width>width){lines.push(line);line='';}
      line+=char;
    }
    lines.push(line);
  }
  return lines;
}
function containImage(ctx,img,x,y,w,h) {
  const scale=Math.min(w/img.naturalWidth,h/img.naturalHeight);
  const iw=img.naturalWidth*scale,ih=img.naturalHeight*scale;
  ctx.drawImage(img,x+(w-iw)/2,y+(h-ih)/2,iw,ih);
}
function canvasBlob(canvas) {
  return new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(Error('圖片超過此瀏覽器可處理的大小，可改下載完整排版檔。')),'image/png'));
}

async function comicImage(data) {
  const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');
  if(!ctx)throw Error('此瀏覽器無法輸出 PNG，可改下載完整排版檔。');
  const cols=data.mode==='四格漫畫'?2:1,width=960,gap=16,pad=18;
  const cell=(width-gap*(cols+1))/cols,font='28px system-ui, sans-serif';
  ctx.font=font;
  const title=wrapCanvas(ctx,data.title,width-2*gap),start=gap+title.length*39+gap;
  const frames=data.units.map(u=>{
    const words=[u.body&&u.speaker,u.body].filter(Boolean).join('　')||(!u.image&&u.heading?'分鏡稿 · '+u.heading:'');
    const lines=words?wrapCanvas(ctx,words,cell-2*pad):[];
    const art=u.image?Math.round((cell-2*pad)*0.84):0;
    return {id:u.image,lines,art,height:Math.max(120,2*pad+art+(art&&lines.length?pad:0)+lines.length*39)};
  });
  let height=start;
  for(let i=0;i<frames.length;i+=cols)height+=Math.max(...frames.slice(i,i+cols).map(f=>f.height))+gap;
  const scale=Math.min(1,8192/height,Math.sqrt(11000000/(width*height)));
  if(scale<0.48)throw Error('這篇漫畫較長。請下載完整排版檔，可逐格閱讀或列印。');
  canvas.width=Math.ceil(width*scale);canvas.height=Math.ceil(height*scale);
  ctx.scale(scale,scale);ctx.fillStyle='#fff';ctx.fillRect(0,0,width,height);
  ctx.textBaseline='top';ctx.font=font;ctx.fillStyle='#252331';
  title.forEach((line,i)=>ctx.fillText(line,gap,gap+i*39));
  let y=start;
  for(let i=0;i<frames.length;i+=cols){
    const row=frames.slice(i,i+cols),rowHeight=Math.max(...row.map(f=>f.height));
    for(let j=0;j<row.length;j++){
      const frame=row[j],x=gap+j*(cell+gap);
      ctx.fillStyle='#fffdf8';ctx.fillRect(x,y,cell,rowHeight);
      ctx.lineWidth=3;ctx.strokeStyle='#303746';ctx.strokeRect(x+1.5,y+1.5,cell-3,rowHeight-3);
      if(frame.id){
        const url=await blobURL(frame.id);
        if(!url)throw Error('找不到這一版採用的格圖，請在原瀏覽器下載。');
        containImage(ctx,await loadPicture(url),x+pad,y+pad,cell-2*pad,frame.art);
      }
      const ty=frame.art?y+2*pad+frame.art:y+(rowHeight-frame.lines.length*39)/2;
      ctx.fillStyle='#252331';frame.lines.forEach((line,k)=>ctx.fillText(line,x+pad,ty+k*39));
    }
    y+=rowHeight+gap;
  }
  return canvasBlob(canvas);
}

async function editionFile(data,kind) {
  if(kind==='txt')return {ext:'txt',blob:new Blob([data.title+'\n\n'+data.body],{type:'text/plain;charset=utf-8'})};
  if(kind==='html')return {ext:'html',blob:await graphicDocument(data)};
  if(kind==='png')return {ext:'png',blob:await comicImage(data)};
  const blob=await mediaBlob(data.media);
  const types={'audio/wav':'wav','audio/x-wav':'wav','audio/webm':'webm','video/webm':'webm','audio/ogg':'ogg',
    'audio/mpeg':'mp3','audio/mp4':'m4a','video/mp4':'mp4','video/quicktime':'mov','audio/flac':'flac','audio/aac':'aac'};
  const ext=types[blob.type.split(';')[0].toLowerCase()]||data.mediaName?.match(/\.([a-z0-9]{1,8})$/i)?.[1]||'bin';
  return {ext,blob};
}

let downloadUrl='';
function releaseDownload() {
  if(!downloadUrl)return;
  const old=downloadUrl;downloadUrl='';
  setTimeout(()=>URL.revokeObjectURL(old),60000);
}

async function downloadEdition(id,n,choice) {
  const w=findW(id),v=version(w,n);
  if(!v||w.shelf)return;
  const data=v.data,kind=choice||({text:'txt',page:'html',comic:'png',film:'media',audio:'media'}[data.type]);
  const alternate=data.type==='comic'?btn(kind==='png'?'下載可列印的完整版（HTML）':'改用漫畫圖檔（PNG）','downloadEdition',[id,n,kind==='png'?'html':'png'],'link'):'';
  const label={txt:'文字檔',html:data.type==='comic'?'完整漫畫':'完整圖文',png:'漫畫圖檔',media:data.type==='audio'?'音檔':'影片檔'}[kind];
  releaseDownload();
  modal('下載定稿 V'+v.n,'<p>'+esc(data.title)+'</p><div id="editionDownload" role="status">正在準備'+esc(label)+'…</div>'+
    (alternate?'<div class="actions">'+alternate+'</div>':''));
  const host=$('editionDownload');
  try{
    const {ext,blob}=await editionFile(data,kind);
    if(!host.isConnected||!$('dialog').open)return;
    if(!blob.size)throw Error('這份檔案沒有內容，請核對後重試。');
    const safe=(data.title||TYPES[data.type].name).replace(/[\\/:*?"<>|\x00-\x1f]/g,'_').slice(0,95);
    const a=document.createElement('a');
    downloadUrl=URL.createObjectURL(blob);
    a.className='download-file';a.href=downloadUrl;a.download=safe+'-V'+v.n+'.'+ext;
    a.textContent='下載'+label+'（'+ext.toUpperCase()+'）';host.replaceChildren(a);
  }catch(error){if(host.isConnected)host.textContent=error.message||'無法準備下載，請重試。';}
}

async function drawComic(id,index) {
  const w=findW(id),u=w?.units[index];
  if(w?.type!=='comic'||!u||w.shelf)return;
  modal('畫第 '+(index+1)+' 格','<p>用手指、觸控筆或滑鼠畫在格內。</p>'+
    '<canvas id="comicInk" width="880" height="660" aria-label="這一格的畫布"></canvas>'+
    '<div class="actions"><button type="button" id="undoInk" disabled>復原一筆</button>'+
    '<button type="button" class="primary" id="saveInk" disabled>採用格圖</button></div><p id="inkStatus" role="status"></p>');
  const canvas=$('comicInk'),ctx=canvas.getContext('2d'),undo=$('undoInk'),accept=$('saveInk'),status=$('inkStatus');
  if(!ctx){status.textContent='此裝置無法開啟畫布，仍可從製作頁加入圖片。';return;}
  const strokes=[];let base=null,pointer=null;
  const paint=()=>{
    ctx.fillStyle='white';ctx.fillRect(0,0,canvas.width,canvas.height);
    if(base)containImage(ctx,base,0,0,canvas.width,canvas.height);
    ctx.lineWidth=6;ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle=ctx.fillStyle='#26334b';
    for(const stroke of strokes){
      ctx.beginPath();
      if(stroke.length===1){ctx.arc(stroke[0][0],stroke[0][1],3,0,Math.PI*2);ctx.fill();continue;}
      ctx.moveTo(...stroke[0]);for(const point of stroke.slice(1))ctx.lineTo(...point);ctx.stroke();
    }
    undo.disabled=accept.disabled=!strokes.length;
  };
  if(u.image){try{base=await loadPicture(await blobURL(u.image));}catch{status.textContent='現有格圖無法讀取，請回到製作頁重新帶入。';return;}}
  if(!canvas.isConnected)return;
  paint();
  const point=e=>{const r=canvas.getBoundingClientRect();return [(e.clientX-r.left)*canvas.width/r.width,(e.clientY-r.top)*canvas.height/r.height];};
  canvas.onpointerdown=e=>{if(pointer!==null||e.button!==0)return;pointer=e.pointerId;canvas.setPointerCapture(pointer);strokes.push([point(e)]);paint();};
  canvas.onpointermove=e=>{if(e.pointerId!==pointer)return;strokes.at(-1).push(point(e));paint();};
  canvas.onpointerup=canvas.onpointercancel=canvas.onlostpointercapture=e=>{if(e.pointerId===pointer)pointer=null;};
  undo.onclick=()=>{strokes.pop();paint();};
  accept.onclick=async()=>{
    if(!strokes.length||accept.disabled)return;
    accept.disabled=true;undo.disabled=true;
    try{
      const image=await putBlob(await canvasBlob(canvas));
      if(!canvas.isConnected||!$('dialog').open||w.shelf||!w.units.includes(u))return;
      const before={image:u.image,ok:u.ok},review=w.review,time=w.updated;
      u.image=image;u.ok=false;w.review=false;keep(w);
      if(!storageOK){Object.assign(u,before);w.review=review;w.updated=time;throw Error('未能保存格圖，請重試。');}
      closeRefresh('格圖已放入第 '+(index+1)+' 格');
    }catch(error){status.textContent=error.message||'未能保存格圖，請重試。';paint();}
  };
}

handlers.downloadEdition=downloadEdition;
handlers.drawComic=drawComic;
$('dialog').addEventListener('close',()=>{if(!$('dialog').open)releaseDownload();});
