'use strict';

const creationAction = {text:'開始寫作',page:'開始編排圖文',comic:'開始畫漫畫',film:'開始製作影片／動畫',audio:'開始製作音檔'};

function chooseShuttleForm(sid) {
  const s=findS(sid);
  if(!s)return;
  modal('從這把杼開始創作','<p>'+esc(s.title)+'</p><div class="formgrid">'+
    Object.keys(TYPES).map(type=>formatBtn(type,s.id)).join('')+'</div>');
}

function setupFor(m,s) {
  const previous=m.setup?.shuttle===s.id?m.setup:{};
  const dir=s.dirs.find(d=>d.id===previous.direction),allowed=new Set(shuttleCardIds(s));
  return {shuttle:s.id,mode:TYPES[m.type].modes.includes(previous.mode)?previous.mode:TYPES[m.type].modes[0],
    direction:dir?.id||'',revision:dir?.vs[previous.revision-1]?previous.revision:0,
    cardIds:(previous.cardIds||[]).filter(id=>allowed.has(id))};
}

function versionSelect(direction, revision) {
  if(!direction?.vs.length)return '';
  const versions=direction.vs.map((text,i)=>[i+1,'V'+(i+1)+' · '+text]).reverse();
  return shuttleSelect('creationVersion','採用哪一版理解？',[[0,'先保留問題'],...versions],revision);
}

function creationPage(m,s) {
  if(!m||m.kind!=='new'||!s||m.fromShuttle&&s.id!==m.fromShuttle)return missing();
  if(m.done)return matchPage(m);
  const selection=setupFor(m,s);
  const dir=s.dirs.find(d=>d.id===selection.direction);
  const ids=shuttleCardIds(s);
  const cards=ids.map(id=>{
    const c=sourceCards.get(id);
    return '<label class="work-card-check"><input type="checkbox" name="creationCard" value="'+esc(id)+'"'+
      (selection.cardIds.includes(id)?' checked':'')+'><span><b>'+esc(c.title)+'</b><small>'+
      esc([c.type,c.source,c.location,c.author].filter(Boolean).join(' · '))+'</small></span></label>';
  }).join('');
  const context=s.core?'<p class="start-core">'+esc(s.core)+'</p>':'';
  const directions=s.dirs.length?shuttleSelect('creationDirection','本件想探討的方向',
    [['','只歸入這把杼'],...s.dirs.map(d=>[d.id,d.name])],selection.direction)+
    '<div id="creationVersions">'+versionSelect(dir,selection.revision)+'</div>':'';
  const inputs=shuttleSelect('creationMode','這次想做的作品',TYPES[m.type].modes.map(mode=>[mode,mode]),selection.mode);
  const sources=ids.length?'<details class="start-cards"><summary>選用這把杼的卡片 <span id="creationCount">（'+selection.cardIds.length+'／'+ids.length+'）</span></summary>'+cards+'</details>':'';
  const from=m.fromShuttle?'shuttle/'+s.id:'match/'+m.id;
  return page('準備'+TYPES[m.type].action,'',panel(s.title,context+inputs+directions+sources+
    '<div class="actions">'+btn(creationAction[m.type],'createFromSetup',[m.id,s.id],'primary')+'</div>'),
    from,m.fromShuttle?s.title:'選擇織光杼');
}

function readSetup(m,s) {
  const direction=val('creationDirection');
  const selected=[...document.querySelectorAll('input[name="creationCard"]:checked')].map(el=>el.value);
  return {shuttle:s.id,mode:val('creationMode'),direction,revision:Number(val('creationVersion'))||0,cardIds:selected};
}

function applyCreationSetup(w,s,setup) {
  setWorkMode(w,setup.mode);
  const allowed=shuttleCardIds(s);
  w.cardIds=allowed.filter(id=>setup.cardIds.includes(id));
}

function workContext(w) {
  const s=findS(w.shuttle),d=s?.dirs.find(item=>item.id===w.direction);
  return {shuttle:s?.title||'',direction:d?.name||'',
    cards:(w.cardIds||[]).map(id=>sourceCards.get(id)).filter(Boolean).map(c=>({
      id:c.id,title:c.title,type:c.type,author:c.author,source:c.source,location:c.location,quote:c.quote,sourceKey:c.sourceKey
    }))};
}

function workReferenceText(w) {
  const context=workContext(w);
  if(!context.shuttle)return '';
  return ['【本件作品的取材】','織光杼｜'+context.shuttle,
    w.coreSnapshot?.text&&'立稿時的核心經線 V'+w.coreSnapshot.n+'｜'+w.coreSnapshot.text,
    context.direction&&'選定方向｜'+context.direction,w.understanding?.text&&'選定理解 V'+w.understanding.n+'｜'+w.understanding.text,
    ...context.cards.map(c=>c.type+'｜'+c.title+'｜'+c.source+' '+c.location+'｜'+c.author+'\n'+c.quote),
    '保留各片段來源與說話者。引用及 GPT 提問均須標示歸屬，只有本人另行採用的文字才可寫進成品。'
  ].filter(Boolean).join('\n');
}

function workSourceReference(w) {
  const context=workContext(w),s=findS(w.shuttle);
  if(!s)return '';
  const info=[context.direction,w.understanding?'V'+w.understanding.n:'',context.cards.length?context.cards.length+' 張卡':''].filter(Boolean).join(' · ');
  const excerpts=context.cards.map(c=>'<article><b>'+esc(c.title)+'</b><small>'+
    esc([c.type,c.source,c.location,c.author].filter(Boolean).join(' · '))+'</small><blockquote>'+esc(c.quote)+'</blockquote>'+
    btn('查看原卡','go',[readingPath('card',c.id)],'link')+'</article>').join('');
  const cardAction=shuttleCardIds(s).length||context.cards.length?btn('調整這件作品的卡片','chooseWorkCards',[w.id],'link'):'';
  return '<details class="creation-reference"><summary>本件取材'+(info?' · '+esc(info):'')+'</summary>'+
    '<p>'+esc(context.shuttle)+'</p>'+(w.coreSnapshot?.text?'<p>經線 V'+w.coreSnapshot.n+' · '+esc(w.coreSnapshot.text)+'</p>':'')+
    (w.understanding?.text?'<p>理解 V'+w.understanding.n+' · '+esc(w.understanding.text)+'</p>':'')+excerpts+cardAction+'</details>';
}

function refreshCreationState() {
  try {
    const raw=localStorage.getItem(statusKey);
    if(raw){
      const doc=JSON.parse(raw);
      if(!Array.isArray(doc.works)||!Array.isArray(doc.shuttles))throw Error();
      state=doc;
    }
    return true;
  }catch{toast('無法讀取已保存的創作，請重試。');return false;}
}

async function startSelectedWork(mid,sid) {
  const before=shuttleMatches()[mid],original=findS(sid);
  if(!original||before?.kind!=='new')return;
  if(before.done){go('edit/'+before.done);return;}
  const setup=readSetup(before,original);
  const commit=()=>{
    if(!refreshCreationState())return;
    const m=shuttleMatches()[mid],s=findS(sid);
    if(!s||m?.kind!=='new'||m.fromShuttle&&m.fromShuttle!==sid){toast('找不到這次選擇的織光杼。');return;}
    if(m.done){go('edit/'+m.done);return;}
    const available=shuttleCardIds(s);
    if(setup.cardIds.some(id=>!available.includes(id))){
      render();toast('這把杼的卡片有更新，請核對後再開始。');return;
    }
    confirmMatch(mid,sid,setup.direction,setup.revision,setup);
  };
  if(navigator.locks){
    try{await navigator.locks.request(statusKey+'.creation',commit);}catch{toast('未能建立工作稿，請重試。');}
  }else commit();
}

Object.assign(handlers,{
  chooseShuttleForm,
  newFromShuttle:(type,sid)=>{if(findS(sid)&&TYPES[type]){fromDayId='';beginShuttleMatch({type,fromShuttle:sid,kind:'new'});}},
  createFromSetup:startSelectedWork
});

document.addEventListener('change',e=>{
  if(route!=='start')return;
  const m=shuttleMatches()[args[0]],s=findS(args[1]);
  if(!m||m.done||!s)return;
  const el=e.target;
  if(!['creationMode','creationDirection','creationVersion'].includes(el.id)&&el.name!=='creationCard')return;
  if(el.id==='creationDirection'){
    const d=s.dirs.find(dir=>dir.id===el.value);
    $('creationVersions').innerHTML=versionSelect(d,0);
  }
  const setup=readSetup(m,s);
  if($('creationCount'))$('creationCount').textContent='（'+setup.cardIds.length+'／'+shuttleCardIds(s).length+'）';
  if(!refreshCreationState())return;
  const fresh=shuttleMatches()[m.id];
  if(fresh&&!fresh.done){fresh.setup=setup;save();}
});
