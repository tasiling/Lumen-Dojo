'use strict';

const trialMaterials = [
  {
    "name": "《紙橋工作簿》｜測試折法",
    "source": "先固定書距，每次只改一種折法。",
    "note": "公開模擬資料，用於比較固定條件與觀察。",
    "url": "source-notes.html#discussion"
  },
  {
    "name": "紙橋工作坊｜示例訪談",
    "source": "每次換一張新紙測試折法。",
    "url": "source-notes.html#interview"
  },
  {
    "name": "紙橋短片｜製作規則",
    "source": "鏡頭依序呈現起始配置、承重測試與觀察結果。",
    "url": "source-notes.html#rules"
  }
];

const readingItems = [
  {title:'討論小結與待查問題',body:readingDiscussion.summary},
  ...readingDiscussion.turns,...readingDiscussion.cards.map(card=>({...card,title:'候選 · '+card.title}))
].map(entry=>({name:'公開示例・紙橋實驗｜'+entry.title,source:entry.body,url:readingDiscussion.url}));

function readingPicker(target){
  const list=(start,end)=>readingItems.slice(start,end).map((m,i)=>more(m.name.split('｜')[1],
    '<p style="white-space:pre-wrap">'+esc(m.source)+'</p>'+btn('帶入這個片段','useMaterial',[target,start+i,true],'light'))).join('');
  return more('公開示例・紙橋實驗｜已完成的心知閱讀討論',list(0,1)+more('逐字問答（13 則）',list(1,14))+
    more('候選成果（5 則觀點、4 張洞察卡）',list(14))+
    '<p><a target="_blank" rel="noopener noreferrer" href="'+esc(readingDiscussion.url)+'">查看完整來源紀錄</a></p>');
}

function workMaterials(w) {
  const rounds=Object.values(shuttleForges()).filter(f=>w.shuttle && f.done===w.shuttle).flatMap(f=>f.rounds);
  const choices=rounds.filter(r=>r.source||r.note).map(r=>({
    name:r.sourceName||r.task,source:r.source||'',note:r.note||''
  }));
  return choices.filter((c,i)=>choices.findIndex(o=>o.name===c.name&&o.note===c.note&&o.source===c.source)===i);
}

function materialPicker(target,items,label) {
  if(!items.length)return '';
  return more(label,(items===trialMaterials?readingPicker(target):'')+items.map((m,i)=>'<div class="entry"><b>'+esc(m.name)+'</b>'+
    (m.source?'<p>來源片段 · '+esc(m.source)+'</p>':'')+
    (m.note?'<p>我的想法 · '+esc(m.note)+'</p>':'')+
    (m.url?'<p><a target="_blank" rel="noopener noreferrer" href="'+esc(m.url)+'">查看原始資料</a></p>':'')+
    btn('帶入這個片段','useMaterial',[target,i],'light')+'</div>').join(''));
}

function appendMaterial(id,value) {
  const el=$(id);
  if(!el||!value||el.value.split('\n\n').includes(value))return;
  el.value=[el.value.trimEnd(),value].filter(Boolean).join('\n\n');
  el.dispatchEvent(new Event('input',{bubbles:true}));
}

handlers.useMaterial=(target,i,reading=false)=>{
  const inForge=target==='forge',fromShuttle=target==='shuttle';
  const item=(reading?readingItems:fromShuttle?workMaterials(current()):target==='workCards'?selectedWorkMaterials(current()):trialMaterials)[i];
  if(!item)return;
  if(inForge){
    if(!$('sfScope')){
      const f=route==='forge'&&activeCardForge(args[0]);
      if(!f)return;
      f.cardMode='topic';render();
    }
    const scope=$('sfScope');
    if(!scope)return;
    scope.value='加上選定的來源';
    for(const type of ['input','change'])scope.dispatchEvent(new Event(type,{bubbles:true}));
    const name=$('sfSourceName');
    const prior=name.value;
    if(prior && prior!==item.name && !prior.split(' ／ ').includes(item.name)){
      const src=$('sfSource');
      if(!prior.includes(' ／ ')&&src.value)src.value='【'+prior+'】\n'+src.value;
      name.value=prior+' ／ '+item.name;
    }else if(!prior)name.value=item.name;
    name.dispatchEvent(new Event('input',{bubbles:true}));
    appendMaterial('sfSource',name.value===item.name?item.source:'【'+item.name+'】\n'+item.source);
    appendMaterial('sfNote',item.note);
  }else{
    const content=[item.name,item.source,item.note?'我的想法 · '+item.note:''].filter(Boolean).join('\n');
    appendMaterial($('mbSource')?'mbSource':'diaScratch',content);
  }
  toast('已帶入，可繼續編輯');
};

function workMaterialPicker(w){
  return materialPicker('workCards',selectedWorkMaterials(w),'這件作品已選用的卡片')+
    materialPicker('shuttle',workMaterials(w),'沿用這一杼討論過的片段')+
    materialPicker('catalog',trialMaterials,'從已有素材挑選');
}
