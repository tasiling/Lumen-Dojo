'use strict';

// The work supplies the adaptation and its sources. The validated A prompt
// still diagnoses only the draft explicitly presented for this round.
const aForms = {
  text:  {draft:'文字草稿', first:'第一句', focus:'哪一句是你最想說的？', read:'引用原句定位問題，說明段落之間如何承接。'},
  page:  {draft:'逐頁圖文稿', first:'第一頁', focus:'你想讓讀者在第一頁注意到什麼？', read:'用頁碼定位，對照讀者看到的標題、內文，以及圖像在頁與頁之間傳達的意思。'},
  comic: {draft:'分格稿', first:'第一格', focus:'第一格裡，你最想讓讀者看見哪個動作？', read:'用格號定位，分開畫面動作和對白。檢查轉折能否從前後格讀出，無字格也可以靠動作表達。'},
  film:  {draft:'分鏡稿', first:'第一個鏡頭', focus:'你想用哪個畫面開場？', read:'用鏡號定位，對照動作、時長和轉場。區分畫面指示、觀眾讀到的字幕與聽到的聲音。'},
  audio: {draft:'口播稿或訪綱', first:'第一段', focus:'你希望聽眾先聽到哪一句？', read:'用段落或口播原句定位，分清主持人的提問、實際回答與錄音提示。'}
};
function aForm(w) {
  if(w.type==='film'&&w.mode==='分章長片')
    return {draft:'章節稿',first:'第一章',focus:'第一章想帶觀眾進入什麼情境？',read:'用章節和章內鏡頭定位，檢查每一章的敘事任務、口播與跨章轉折。'};
  return aForms[w.type];
}
function aWorkDraft(w) {
  if(w.type==='text')return w.body||'';
  const spec=mediaBSpec(w);
  const units=w.units.map((u,i)=>{
    let fields=spec.fields;
    if(w.type==='page')fields={...fields,speaker:'說話者'};
    if(w.type==='film'&&!u.bRound)fields={...fields,body:w.mode==='分章長片'?'章內鏡頭與口播':'動作、口播與字幕'};
    // The recording editor keeps the editable transcript in body after adopting B.
    if(w.type==='audio'&&w.body?.trim())fields={goal:fields.goal,transition:fields.transition,sound:fields.sound};
    const lines=Object.entries(fields).filter(([k])=>u[k]?.trim()).map(([k,label])=>label+'｜'+u[k].trim());
    if(!lines.length)return '';
    return ['第 '+(i+1)+' '+spec.unit+(u.bRound?'（從 B 腳本採用）':''),...lines].join('\n');
  });
  return [w.body,...units].filter(s=>s?.trim()).join('\n\n');
}
function aDraftState(w) {
  const current=aWorkDraft(w),note=w.aDraft??w.diamondNarrative??'';
  const useNote=!!w.aUseNote||!current.trim();
  return {current,note,useNote,text:useNote?note:current};
}
function aWorkLabel(w) {
  return [w.mode,w.title.trim()||'作品尚未命名'].join(' · ');
}
function latestConfirmedA(w) {
  return (w.diamondRuns||[]).slice().reverse().find(r=>r.mode==='A'&&!r.phase&&r.locked&&
    r.shuttleId===w.shuttle&&r.answer&&r.answer===w.intent);
}
function aOwnCardLabel(card) {
  if(card.author==='本人發言整理成的候選卡')return '用這句原話起稿';
  if(card.author==='本人已確認的訪談摘要')return '用這段訪談摘要起稿';
  return '';
}
function aContext(w) {
  const c=workContext(w),cardCount=c.cards.length;
  const title='<div class="a-shuttle"><small>所屬織光杼</small><strong>'+esc(c.shuttle||'尚未匹配')+'</strong></div>';
  const direction=c.direction?'<p class="a-direction">方向 · '+esc(c.direction)+(w.understanding?' · 理解 V'+w.understanding.n:'')+'</p>':'';
  const summary=cardCount===1?'選用的卡片 · '+c.cards[0].title:cardCount?'本件選用的 '+cardCount+' 張卡片':'查看本件取材';
  const fromShuttle=shuttleCardIds(findS(w.shuttle)).length;
  const cardAction=fromShuttle||cardCount?btn(cardCount?'調整本件選用的卡片':'從這把杼選卡片','chooseWorkCards',[w.id,'A'],'link'):'';
  const details=[
    w.coreSnapshot?.text&&'<p>立稿時的經線 V'+w.coreSnapshot.n+' · '+esc(w.coreSnapshot.text)+'</p>',
    w.understanding?.text&&'<p>選定的理解 V'+w.understanding.n+' · '+esc(w.understanding.text)+'</p>',
    ...c.cards.map(card=>'<article><b>'+esc(card.title)+'</b><small>'+esc([card.type,card.source,card.location,card.author].filter(Boolean).join(' · '))+'</small><blockquote>'+esc(card.quote)+'</blockquote>'+
      (aOwnCardLabel(card)?btn(aOwnCardLabel(card),'diaUseOwnWords',[w.id,'card',card.id],'link'):'')+'</article>')
  ].filter(Boolean).join('');
  const thoughts=workMaterials(w).map((m,i)=>m.note?.trim()?'<article><b>'+esc(m.name)+'</b><blockquote>'+esc(m.note)+'</blockquote>'+
    btn('用這段想法起稿','diaUseOwnWords',[w.id,'forge',i],'link')+'</article>':'').join('');
  return '<p class="sub">'+esc(aWorkLabel(w))+'</p>'+title+direction+
    (details?'<details class="creation-reference"><summary>'+esc(summary)+'</summary>'+details+(cardCount?cardAction:'')+'</details>':'')+
    (cardCount?'':cardAction)+(thoughts?'<details class="creation-reference"><summary>我在立杼討論裡的想法</summary>'+thoughts+'</details>':'');
}
function aReferenceText(w) {
  const parts=['作品｜'+aWorkLabel(w),workReferenceText(w)];
  if(w.source?.title)parts.push('來源作品｜'+w.source.title+(w.source.n?' V'+w.source.n:''));
  return parts.filter(Boolean).join('\n');
}
function aAssetNote(w) {
  if(w.type==='text')return '';
  const numbers=w.units.flatMap((u,i)=>u.image?[i+1]:[]);
  const unitName=mediaBSpec(w).unit;
  const items=[numbers.length&&'第 '+numbers.join('、')+' '+unitName+'已有圖片',w.media&&(w.type==='audio'?'已加入音檔':'已加入影片')].filter(Boolean);
  return items.length?items.join('，')+'。這輪傳給 GPT 的是文字，可以補上你想討論的畫面或聲音。':'';
}
function openDiamondA(w) {
  const form=aForm(w),draft=aDraftState(w);
  const generate=btn('產生 A 診斷指令','diaGenerate',[w.id,'A',0],'primary');
  const swaps=draft.current?'<div class="a-draft-choice" id="aDraftChoice">'+
    btn('使用目前作品的'+form.draft,'diaDraftFrom',[w.id,'work'],'link')+
    btn('接續上次另寫的稿','diaDraftFrom',[w.id,'note'],'link')+'</div>':'';
  const editor='<p class="sub" id="aDraftOrigin"></p>'+field('這輪要診斷的'+form.draft,'diaScratch',draft.text,true,'placeholder="'+esc(form.focus)+'"')+swaps+generate;
  const available=!!(draft.text.trim()||draft.current.trim());
  const starting=btn('和 GPT 討論'+form.first,'diaStartWriting',[w.id],'primary');
  const assetNote=aAssetNote(w);
  modal('A｜'+diamondNames.A,aContext(w)+(assetNote?'<p class="sub">'+esc(assetNote)+'</p>':'')+
    (available?editor:'<section class="a-start"><h3>從哪裡起稿？</h3><p>'+esc(form.focus)+'</p>'+starting+'</section>'+
      more('我想直接寫'+form.draft,editor))+
    diamondLive+diamondHistory(w,'A'));
  const area=$('diaScratch');
  function updateOrigin(useNote) {
    $('aDraftOrigin').textContent=useNote?'這份診斷稿可以另寫，工作區會保留原稿。':'已帶入作品工作區的'+form.draft+'。';
    const swaps=$('aDraftChoice');
    if(swaps){
      swaps.children[0].hidden=!useNote;
      swaps.children[1].hidden=useNote||!draft.note.trim()||draft.note===draft.current;
    }
  }
  updateOrigin(draft.useNote);
  area.oninput=()=>{w.aDraft=area.value;w.aUseNote=true;keep(w);updateOrigin(true);};
}
function aStartWriting(id) {
  const w=findW(id);if(!w||w.shelf)return;
  const form=aForm(w),source=aReferenceText(w);
  const prompt=[source,'我想在「'+w.mode+'」裡從'+form.first+'開始，目前還沒有可診斷的作品稿。',
    '先陪我起稿。從我選用的材料或這把杼的問題出發，一次問一個我能具體回答的小問題，例如「'+form.focus+'」。請承接我已說出的內容。',
    '卡片的原話、引用與 GPT 當時的提問都保留各自的身分。等我說出願意放進作品的一句話或畫面，用我的原話小結，問我要留下哪一段。由我決定後再整理，只交回我選定的原話。草稿留給之後的 A 診斷。'
  ].join('\n\n');
  const run={id:uid(),mode:'A',phase:'start',first:form.first,workId:id,shuttleId:w.shuttle,title:aWorkLabel(w),source,prompt,stage:'等待起稿',raw:'',n:0};
  w.diamondRuns ||= [];w.diamondRuns.push(run);keep(w);diamondRun(id,run.id);
}
function aStartRound(w,r,invite) {
  const back=btn('回到 A 診斷','diamondOpen',[w.id,'A'],'light');
  const complete=r.locked?'<h3>這輪留下的原話</h3><p class="fixed-preview">'+esc(r.answer)+'</p>'+back:
    field('討論後，我想留下的起稿原話','diaSeed',r.pendingSeed||'',true)+
    btn('採用為這輪的診斷草稿','diaAdoptSeed',[w.id,r.id],'primary');
  modal('起稿討論｜'+(r.first||aForm(w).first),'<p class="sub">'+esc(r.title)+'</p>'+
    (r.locked?'':'<p>複製指令到 GPT。談好後，把你決定採用的那段話帶回來。</p>'+invite)+complete+
    (r.locked?more('查看當時的討論指令',field('指令內容','diaPrompt',r.prompt,true,'readonly')):'')+diamondLive);
  if(!r.locked)$('diaSeed').oninput=e=>{r.pendingSeed=e.target.value;save();};
}
Object.assign(handlers,{
  diaStartWriting:aStartWriting,
  diaUseOwnWords:(id,kind,ref)=>{
    const w=findW(id);if(!w||w.shelf)return;
    let excerpt='';
    if(kind==='card'){
      const c=workContext(w).cards.find(card=>card.id===ref);
      if(c&&aOwnCardLabel(c))excerpt=c.author+'｜'+c.source+' '+c.location+'\n'+c.quote;
    }else if(kind==='forge'){
      const m=workMaterials(w)[ref];
      if(m?.note)excerpt='我在立杼討論裡的想法｜'+m.name+'\n'+m.note;
    }
    if(!excerpt)return;
    const current=val('diaScratch');
    if(!current.includes(excerpt))w.aDraft=[current,excerpt].filter(Boolean).join('\n\n');
    else w.aDraft=current;
    w.aUseNote=true;keep(w);openDiamondA(w);diamondMessage('已帶入這輪診斷稿。');
  },
  diaDraftFrom:(id,from)=>{const w=findW(id);if(!w)return;w.aUseNote=from==='note';keep(w);openDiamondA(w);},
  diaAdoptSeed:(id,rid)=>{
    const [w,r]=diamondFind(id,rid);if(r?.phase!=='start'||r.locked)return;
    const text=val('diaSeed');if(!text){diamondMessage('先放入你想帶回的那句話或那段畫面描述。');return;}
    const base=aDraftState(w).text.trimEnd();
    w.aDraft=base.includes(text)?base:[base,text].filter(Boolean).join('\n\n');
    w.aUseNote=true;r.answer=text;delete r.pendingSeed;r.locked=true;r.stage='已留下起稿原話';
    keep(w);openDiamondA(w);diamondMessage('已帶入本輪診斷稿。');
  }
});
