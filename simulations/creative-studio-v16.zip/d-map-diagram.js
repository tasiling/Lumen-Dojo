'use strict';

// Shared drawing approach from the reading mind map. This edition uses the studio palette.
const drawDMap = (() => {
  const svgNS = 'http://www.w3.org/2000/svg';
  const colors = {ink:'#253c5c',green:'#813d64',thread:'#b199ad',rule:'#e2d8e1',white:'#fff',paper:'#fcf9fc'};
  function vector(tag, attributes = {}, text) {
    const node = document.createElementNS(svgNS, tag);
    for (const [key, value] of Object.entries(attributes)) node.setAttribute(key, String(value));
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function wrapText(value, width, size) {
    const limit = Math.max(3, (width - 6) / size);
    const rows = [];
    let row = '', units = 0;
    for (const ch of Array.from(String(value))) {
      if (ch === '\n') { rows.push(row); row = ''; units = 0; continue; }
      const add = /[\u0020-\u007e]/.test(ch) ? (/[il.,:;!|']/.test(ch) ? .38 : .66) : 1;
      if (units + add > limit && row) { rows.push(row); row = ''; units = 0; }
      row += ch; units += add;
    }
    if (row || !rows.length) rows.push(row);
    return rows;
  }
  function line(parent, d, color = colors.thread) {
    parent.append(vector('path',{d,fill:'none',stroke:color,'stroke-width':1.4,'stroke-linecap':'round','stroke-linejoin':'round'}));
  }
  function textRows(parent, x, y, rows, size, cfg = {}) {
    const node = vector('text',{x,y,fill:cfg.fill || colors.ink,'font-family': cfg.serif ? "Georgia, 'Noto Serif CJK TC', 'Songti TC', serif" : "'PingFang TC', 'Noto Sans CJK TC', 'Microsoft JhengHei', sans-serif",'font-size':size,'font-weight':cfg.weight || 400,'text-anchor':cfg.anchor || 'start','pointer-events':'none'});
    rows.forEach((row,i) => node.append(vector('tspan',{x,dy:i ? size + 5 : 0},row)));
    parent.append(node);
  }
  function handleNode(group, label, invoke, expanded) {
    group.setAttribute('role','button'); group.setAttribute('tabindex','0');
    group.setAttribute('class','lm-node'); group.setAttribute('aria-label',label);
    if (expanded !== undefined) group.setAttribute('aria-expanded',String(expanded));
    group.addEventListener('click',invoke);
    group.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); invoke(); }
    });
  }
  function makeDiagram({width,title,groups,collapsed,activeId,activate,toggle,exporting}) {
    const svg = vector('svg',{class:'lm-diagram', role:exporting ? 'img' : 'group','aria-label':title + ' 心智圖'});
    svg.append(vector('title',{},title + ' 心智圖'));
    const tracks = vector('g',{'aria-hidden':'true'}), nodes = vector('g');
    const wide = width >= 600 && groups.length > 1;
    const edge = width < 450 ? 14 : 24;
    const cols = wide ? 2 : 1;
    const colGap = wide ? 30 : 0;
    const colWidth = (width - 2 * edge - colGap) / cols;
    const rootX = width/2, rootWidth = Math.min(width - edge*2, Math.max(158, Math.min(344, Array.from(title).length * 19 + 50)));
    const rootLines = wrapText(title,rootWidth-26,18);
    const rootH = 32 + 23 * rootLines.length, rootTop = 20, rootBottom = rootTop + rootH;
    const rootBox = vector('g');
    rootBox.append(vector('rect',{x:rootX-rootWidth/2,y:rootTop,width:rootWidth,height:rootH,rx:9,fill:colors.green}));
    textRows(rootBox,rootX,rootTop+27,rootLines,18,{fill:'#fff',anchor:'middle',weight:500,serif:false});
    nodes.append(rootBox);
    const colItems = wide ? [groups.filter((_,i)=>i%2===0),groups.filter((_,i)=>i%2===1)] : [groups];
    let maxBottom = rootBottom;
    colItems.forEach((list,col) => {
      if (!list.length) return;
      const start = edge + col * (colWidth+colGap);
      const stem = start+3, groupX = start+15, leafStem = groupX+11, leafX = leafStem+15;
      const yStart = rootBottom + (wide ? 38 : 32);
      line(tracks, 'M '+rootX+' '+rootBottom+' V '+(rootBottom+10)+' Q '+rootX+' '+(rootBottom+17)+' '+(rootX + (stem < rootX ? -7 : 7))+' '+(rootBottom+17)+' H '+(stem+7)+' Q '+stem+' '+(rootBottom+17)+' '+stem+' '+(rootBottom+24)+' V '+yStart);
      let top = yStart;
      let prevMid = yStart;
      list.forEach(([name,entries]) => {
        const mid = top+22;
        line(tracks,'M '+stem+' '+prevMid+' V '+(mid-5)+' Q '+stem+' '+mid+' '+(stem+5)+' '+mid+' H '+groupX);
        prevMid = mid;
        const group = vector('g');
        const groupW = Math.min(colWidth-17,Math.max(84,Array.from(name).length*15+40));
        group.append(vector('rect',{x:groupX,y:top,width:groupW,height:44,rx:7,fill:'#f6e9f1',stroke:'#e1d0de',class:'lm-hit'}));
        const xIcon=groupX+groupW-14;
        if (!exporting) {
          line(group,'M '+(xIcon-3.5)+' '+mid+' H '+(xIcon+3.5),colors.green);
          if (collapsed.has(name)) line(group,'M '+xIcon+' '+(mid-3.5)+' V '+(mid+3.5),colors.green);
          handleNode(group,name+'，'+entries.length+' 則',()=>toggle(name),!collapsed.has(name));
        }
        textRows(group,groupX+10,mid+5,[name],14,{weight:500});
        nodes.append(group); top += 44;
        if (exporting || !collapsed.has(name)) {
          let prevLeaf=top;
          entries.forEach(item => {
            const size=15, innerWidth= start+colWidth-leafX;
            const rows=wrapText(item.label,innerWidth-24,size);
            const h=Math.max(44,18+rows.length*(size+5)), y=top+5, anchor=y+h/2;
            line(tracks,'M '+leafStem+' '+prevLeaf+' V '+(anchor-4)+' Q '+leafStem+' '+anchor+' '+(leafStem+4)+' '+anchor+' H '+leafX);
            prevLeaf=anchor;
            const g=vector('g');
            g.append(vector('title',{},item.label));
            if(exporting) g.append(vector('desc',{},[item.body,item.source].filter(Boolean).join('\n')));
            g.append(vector('rect',{x:leafX,y,width:innerWidth,height:h,rx:6,fill:(!exporting && activeId===item.id)?'#f6e9f1':colors.white,stroke:(!exporting && activeId===item.id)?'#995677':colors.rule,class:'lm-hit'}));
            textRows(g,leafX+10,y+(h-(rows.length-1)*(size+5))/2+5,rows,size);
            if(!exporting) handleNode(g,'查看'+item.group+'：'+item.label,()=>activate(item.id));
            nodes.append(g); top=y+h;
          });
        }
        top+=14;
      });
      maxBottom=Math.max(maxBottom,top);
    });
    const height=maxBottom+10;
    svg.setAttribute('viewBox','0 0 '+width+' '+height);
    if(exporting){svg.setAttribute('width',width);svg.setAttribute('height',height);}
    svg.append(vector('rect',{x:0,y:0,width,height,fill:colors.paper,rx:10}),tracks,nodes);
    return svg;
  }
  return makeDiagram;
})();
