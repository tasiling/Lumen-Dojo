'use strict';
const id = location.hash.slice(1);
const origin = location.origin;
const parentWindow = window.opener;
const field = document.getElementById('text');
const send = document.getElementById('send');
const status = document.getElementById('status');
let recordReady = false;
window.addEventListener('message', event => {
  if (!parentWindow || event.origin !== origin || event.source !== parentWindow || event.data?.id !== id) return;
  if (event.data.type === 'record' && !recordReady) {
    recordReady = true;
    document.getElementById('title').textContent = event.data.title;
    document.getElementById('url').value = event.data.url || '';
    field.value = '這是一段示範逐字稿，可以編輯，再存回原素材。';
    send.disabled = false;
    status.textContent = '已收到來源資料。';
  } else if (event.data.type === 'saved') {
    status.textContent = '已存回野採素材。';
    send.disabled = true;
  }
});
send.addEventListener('click', () => {
  if (!recordReady || !field.value.trim() || !parentWindow || parentWindow.closed) return;
  parentWindow.postMessage({ type: 'transcript', id, text: field.value.trim() }, origin);
});
if (parentWindow && id && origin !== 'null') parentWindow.postMessage({ type: 'ready', id }, origin);
