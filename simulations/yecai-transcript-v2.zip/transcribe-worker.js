import {env,pipeline} from './engine/transformers.min.js';
env.allowRemoteModels=false;
env.localModelPath=new URL('./model/',self.location).href;
env.backends.onnx.wasm.wasmPaths=new URL('./engine/',self.location).href;
env.backends.onnx.wasm.numThreads=1;
env.backends.onnx.wasm.proxy=false;
const nativeFetch=globalThis.fetch.bind(globalThis);
const modelBase=new URL('./model/tiny/onnx/',self.location);
globalThis.fetch=async function(input,init){
 const path=typeof input==='string'?input:input.url||String(input);
 if(new URL(path,self.location).href!==modelBase+'decoder_model_merged_quantized.onnx')return nativeFetch(input,init);
 const parts=await Promise.all(['decoder.part0','decoder.part1'].map(async name=>{
  const response=await nativeFetch(new URL(name,modelBase));if(!response.ok)throw Error('模型下載失敗，請確認網路後重試。');return response.blob();
 }));
 const data=new Blob(parts);return new Response(data,{headers:{'content-length':String(data.size),'content-type':'application/octet-stream'}});
};
let recognizer;
self.onmessage=async ({data})=>{
 try{
  self.postMessage({phase:'正在載入 Whisper 語音模型…'});
  recognizer??=await pipeline('automatic-speech-recognition','tiny',{quantized:true});
  self.postMessage({phase:'正在辨識影片聲音，請保持此頁開啟…'});
  const result=await recognizer(data.audio,{task:'transcribe',language:data.language||null,return_timestamps:true,chunk_length_s:25,stride_length_s:4});
  const text=(result.chunks||[]).map(c=>c.text.trim()).filter(Boolean).join('\n')||result.text.trim();
  if(!text)throw Error('影片中沒有辨識出可保存的語音。');
  self.postMessage({text});
 }catch(e){self.postMessage({error:String(e.message||e)})}
};
