'use strict';
const samplePath='fixtures/mandarin-check.mp4';
const picked=new Map();
const jobs=new Map();
const bridges=new Map();
const macOrigin=new URL(mac).origin;
function mediaMarkup(r){
 const m=picked.get(r.id),job=jobs.get(r.id);
 return `<div class="block"><h3>讀取影片檔</h3><label class="filepick" for="movie">選取影片檔</label><input id="movie" type="file" accept="video/*,.mp4,.mov,.m4v,.webm"><p class="hint">從「照片」或「檔案」選取有聲影片。這個頁面可直接播放並在裝置上辨識語音。</p>
 ${m?`<video id="player" controls playsinline preload="metadata" src="${esc(m.url)}"></video><p id="filemeta" class="sub">${esc(m.name)} · ${esc(m.info||'讀取影片資訊中…')}</p>`:''}
 ${r.sample&&!m?'<button data-media="sample">載入中文測試影片</button>':''}
 ${m?`<button class="primary" data-media="recognize" ${job?'disabled':''}>在此裝置產生逐字稿</button>`:''}
 <p id="media-status" role="status">${esc(job?.phase||r.mediaMessage||'')}</p></div>
 ${r.sample?'':`<details class="block"><summary>交給 Mac 的 BiliNote</summary><p class="hint">測試視窗會以本機示例模擬回傳，沒有連線到 Mac。</p><button data-media="mac">開啟回傳測試視窗 ↗</button></details>`}`;
}
function showMediaMessage(r,msg){r.mediaMessage=msg;if(active===r&&$('media-status'))$('media-status').textContent=msg }
let videoDatabase;
function videoStore(){
 if(!videoDatabase)videoDatabase=new Promise((resolve,reject)=>{
  const req=indexedDB.open('dojo-handoff-transcript-videos-v2',1);
  req.onupgradeneeded=()=>req.result.createObjectStore('files');
  req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)
 });
 return videoDatabase
}
async function writeVideo(id,blob,name){
 const db=await videoStore();
 await new Promise((resolve,reject)=>{
  const tx=db.transaction('files','readwrite');tx.oncomplete=resolve;tx.onabort=()=>reject(tx.error);tx.onerror=()=>reject(tx.error);
  tx.objectStore('files').put({blob,name},id)
 })
}
async function restoreVideo(r){
 if(picked.has(r.id)||!r.hasFile)return;
 try{const db=await videoStore();const file=await new Promise((resolve,reject)=>{const req=db.transaction('files').objectStore('files').get(r.id);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)});
 if(file&&!picked.has(r.id)){picked.set(r.id,{blob:file.blob,name:file.name,url:URL.createObjectURL(file.blob)});if(active===r&&$('sheet').open)details(r)}
 }catch{showMediaMessage(r,'此瀏覽器暫時讀不到上次選取的影片，請重新選檔。')}
}
function attachVideo(r,blob,name){
 if(jobs.has(r.id)){showMediaMessage(r,'這筆素材正在辨識中。');return}
 if(!blob.size){showMediaMessage(r,'這個檔案是空的。');return}
 const old=picked.get(r.id);if(old)URL.revokeObjectURL(old.url);
 picked.set(r.id,{blob,url:URL.createObjectURL(blob),name});r.mediaMessage='';details(r);
 if(!r.sample)writeVideo(r.id,blob,name).then(()=>{r.hasFile=true;save()}).catch(()=>showMediaMessage(r,'影片可在本次使用，瀏覽器空間不足或禁止保存。下次請重新選檔。'))
}
function setupPlayer(r){
 const p=$('player'),m=picked.get(r.id);if(!p||!m)return;
 const ready=()=>{m.info=[isFinite(p.duration)?Math.floor(p.duration/60)+' 分 '+Math.round(p.duration%60)+' 秒':'片長未知',p.videoWidth?p.videoWidth+' × '+p.videoHeight:'',Math.max(1,Math.round(m.blob.size/1024))+' KB'].filter(Boolean).join(' · ');if($('filemeta'))$('filemeta').textContent=m.name+' · '+m.info};
 p.onloadedmetadata=ready;if(p.readyState>=1)ready();p.onerror=()=>showMediaMessage(r,'此瀏覽器無法預覽這個編碼。可以嘗試辨識音軌，或用 Mac 轉錄。');
}
function storeTranscript(r,text,method){
 if(!text?.trim())throw Error('沒有收到逐字稿。');
 r.transcript=text.trim();r.stage='done';r.method=method;r.demo=false;r.draft='';r.mediaMessage='';save();draw();if(active===r&&$('sheet').open)details(r)
}
async function recognize(r){
 const m=picked.get(r.id);if(!m||jobs.has(r.id))return;
 if(jobs.size)return showMediaMessage(r,'請等目前的影片辨識結束，再開始下一支。');
 if(r.transcript&&!r.demo&&!confirm('用本次辨識結果更新這筆逐字稿？'))return;
 const job={phase:'讀取影片音軌中…'};jobs.set(r.id,job);details(r);
 let worker,ctx;
 try{
  const engineReady=await fetch('engine/transformers.min.js',{method:'HEAD'});
  if(!engineReady.ok)throw Error('請先依 README.md 執行 prepare-model.py 準備本機語音模型。');
  if(m.blob.size>200*1024*1024)throw Error('此裝置單檔上限為 200 MB，請選較短的影片。');
  const player=$('player');if(player&&player.duration>900)throw Error('此裝置每次可辨識 15 分鐘，較長影片請交給 Mac。');
  ctx=new (window.AudioContext||window.webkitAudioContext)({sampleRate:16000});
  const audio=await ctx.decodeAudioData(await m.blob.arrayBuffer());
  if(audio.duration>900)throw Error('影片超過 15 分鐘，請交給 Mac 處理。');
  const offline=new OfflineAudioContext(1,Math.ceil(audio.duration*16000),16000);
  const src=offline.createBufferSource();src.buffer=audio;src.connect(offline.destination);src.start();
  const mono=(await offline.startRendering()).getChannelData(0);
  if(!mono.some(s=>Math.abs(s)>0.0003))throw Error('音軌沒有可辨識的聲音。');
  const text=await new Promise((resolve,reject)=>{
   worker=new Worker('transcribe-worker.js',{type:'module'});worker.onerror=e=>reject(Error(e.message||'辨識程序無法啟動。'));
   worker.onmessage=({data})=>{if(data.phase){job.phase=data.phase;showMediaMessage(r,data.phase)}else if(data.error)reject(Error(data.error));else resolve(data.text)};
   worker.postMessage({audio:mono,language:'chinese'},[mono.buffer]);
  });
  storeTranscript(r,text,'本裝置 Whisper · 中文語音');
 }catch(e){showMediaMessage(r,'未產生逐字稿：'+(e.message||'無法解碼影片音軌。'))}
 finally{worker?.terminate();if(ctx)await ctx.close().catch(()=>{});jobs.delete(r.id);if(active===r&&$('sheet').open)details(r)}
}
function openMac(r){
 if(jobs.has(r.id))return;
 if(r.transcript&&!r.demo&&!confirm('用下一次 Mac 轉錄結果更新這筆逐字稿？'))return;
 const id=crypto.randomUUID(),win=window.open(mac.href+'#'+id,'_blank');
 if(!win)return showMediaMessage(r,'請允許這次開啟 Mac 轉錄視窗。');
 bridges.set(id,{win,r});showMediaMessage(r,'請在測試視窗確認文字並存回素材。');
}
window.addEventListener('message',e=>{
 const msg=e.data;if(e.origin!==macOrigin||!msg||typeof msg.id!=='string')return;
 const pending=bridges.get(msg.id);if(!pending||pending.win!==e.source)return;
 if(msg.type==='ready')e.source.postMessage({type:'record',id:msg.id,url:pending.r.url,title:pending.r.title},macOrigin);
 if(msg.type==='transcript'&&typeof msg.text==='string'&&msg.text.trim()){storeTranscript(pending.r,msg.text,'Mac 回傳流程示範');e.source.postMessage({type:'saved',id:msg.id},macOrigin);bridges.delete(msg.id)}
});
document.addEventListener('change',e=>{if(e.target.id==='movie'&&e.target.files[0]&&active)attachVideo(active,e.target.files[0],e.target.files[0].name)});
document.addEventListener('click',async e=>{
 const b=e.target.closest('[data-media]');if(!b||!active)return;const r=active;
 if(b.dataset.media==='sample'){try{const f=await fetch(samplePath);if(!f.ok)throw Error();attachVideo(r,await f.blob(),'中文語音測試.mp4')}catch{showMediaMessage(r,'無法載入測試影片。')}}
 if(b.dataset.media==='recognize')recognize(r);
 if(b.dataset.media==='mac')openMac(r);
 if(b.dataset.media==='copy'){try{await navigator.clipboard.writeText(r.url);$('msg').textContent='已複製影片網址。'}catch{$('msg').textContent='請長按影片網址複製。'}}
 if(b.dataset.media==='import'){const text=$('returned').value.trim();if(!text)return $('msg').textContent='請先貼入逐字稿。';if(jobs.has(r.id))return $('msg').textContent='這支影片正在辨識中。';if(!r.transcript||confirm('取代目前儲存的逐字稿？'))storeTranscript(r,text,'從 BiliNote 手動帶回')}
});
$('newMovie').onchange=e=>{
 const file=e.target.files[0];if(!file)return;
 const r={id:crypto.randomUUID(),platform:'影片檔',title:file.name,author:'本機影片',url:'',share:'',stage:'ready'};
 items.unshift(r);filter='all';save();attachVideo(r,file,file.name);e.target.value='';
};
