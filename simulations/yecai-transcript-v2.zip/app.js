'use strict';
const mac=new URL('mac-preview/index.html', location.href);
const storageKey='dojo-handoff-transcript-v2';
const samples=[
 {id:'dy',platform:'抖音',title:'雨後的葉子',author:'示範素材',share:'練習觀察雨滴落在兩種葉片上的差異。',url:'https://www.douyin.com/video/example-leaf',stage:'ready'},
 {id:'bv',platform:'B站',title:'紙張吸水觀察',author:'示範素材',share:'把兩張紙放進同樣深的水，記錄變化。',url:'https://www.bilibili.com/video/BVExample/',stage:'ready'},
 {id:'check-video',platform:'影片檔',title:'中文語音測試影片',author:'有聲 MP4 · 中文',url:'',stage:'ready',sample:true,share:'使用 eSpeak NG 合成的普通話測試短片。'}];
const statuses={ready:'待補逐字稿',queued:'等待 Mac（模擬）',running:'轉錄中（模擬）',failed:'轉錄中斷（模擬）',done:'已有逐字稿'};
const $=id=>document.getElementById(id);
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let items=samples,active=null,filter='all',durable=true;
try{const saved=JSON.parse(localStorage.getItem(storageKey));if(Array.isArray(saved)&&saved.length)items=saved}catch{durable=false}
if(!items.some(r=>r.sample))items.push(samples.find(r=>r.sample));
function dyShare(text){
 const m=text.match(/【(.+?)的作品】\s*([^\n]*?)(?=\s*(?:[声聲]明[：:]|https?:\/\/)|$)/);
 return m?{author:m[1].trim(),title:m[2].trim()}:null;
}
for(const item of items){
 if(item.platform==='抖音'&&item.title?.includes('打开抖音')){const meta=dyShare(item.share);if(meta){item.title=meta.title;item.author=meta.author}}
 if(item.demo||['running','queued','failed'].includes(item.stage)){if(item.demo)item.transcript='';item.stage='ready';item.demo=false}
}
function save(){try{localStorage.setItem(storageKey,JSON.stringify(items))}catch{durable=false}if(!durable)$('announcement').textContent='此瀏覽器限制儲存，請在關閉頁面前複製逐字稿。'}
function draw(){
 document.querySelectorAll('[data-filter]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.filter===filter));
 const rows=items.filter(r=>filter==='all'||(filter==='done')===(r.stage==='done'));
 $('cards').innerHTML=rows.map(r=>`<button class="card" data-id="${esc(r.id)}"><div><div class="meta"><span class="source">${esc(r.platform)}</span><span class="pill ${r.stage==='done'?'done':''}">${statuses[r.stage]}</span></div><strong>${esc(r.title)}</strong><small>${esc(r.author||'自行收錄')}</small></div><span class="arrow">›</span></button>`).join('')||'<p class="block">這裡還沒有符合條件的影片。</p>';
}
function openSheet(label){$('dialogLabel').textContent=label;if(!$('sheet').open)$('sheet').showModal()}
function details(r,manual=false){
 active=r; openSheet('素材詳情'); $('panel').innerHTML=`<div class="meta"><span class="source">${esc(r.platform)}</span><span class="pill">${statuses[r.stage]}</span></div><h2>${esc(r.title)}</h2><details open><summary>原始分享文案</summary><p class="bodytext">${esc(r.share||'只收錄了影片網址。')}</p></details>
 ${mediaMarkup(r)}
 ${r.stage==='done'?`<div class="block soft"><h3>影片逐字稿</h3><small>${esc(r.method||'從 BiliNote 手動帶回')}</small><details open><summary>逐字稿全文</summary><div class="bodytext">${esc(r.transcript)}</div></details></div>`:''}
 <details><summary>從既有 BiliNote 手動帶回</summary>${r.url?`<p class="mono">${esc(r.url)}</p><button data-media="copy">複製影片網址</button>`:''}<label for="returned">貼上已取得的逐字稿</label><textarea id="returned" rows="4">${esc(r.draft||'')}</textarea><button data-media="import">存回這筆素材</button></details>
 <details><summary>我的感觸</summary><label for="note">我為什麼想留下它</label><textarea id="note" rows="2" placeholder="選填">${esc(r.note||'')}</textarea></details><p class="inline-msg" id="msg" role="status"></p>`;draw();setupPlayer(r);restoreVideo(r);
}
function parseShare(text){const match=text.match(/https?:\/\/[^\s<>"【】]+/i);if(!match)return null;try{const url=new URL(match[0].replace(/[。），,）]+$/,''));const hosts=['douyin.com','bilibili.com','b23.tv'];const h=hosts.find(h=>url.hostname===h||url.hostname.endsWith('.'+h));if(!h||url.username||url.password||url.port)return null;const id=url.pathname.match(/\/video\/(BV\w+)/i);if(h==='bilibili.com'&&id)return {platform:'B站',url:'https://www.bilibili.com/video/'+id[1]+'/'};return {platform:h==='douyin.com'?'抖音':'B站',url:url.href}}catch{return null}}
function addForm(){
 active=null;openSheet('收影片');$('panel').innerHTML='<h2>收一支影片</h2><label for="share">抖音或 B 站分享訊息</label><textarea id="share" rows="4" placeholder="貼網址，或貼上含網址的整段分享文案"></textarea><label for="title">素材標題（選填）</label><input id="title"><p class="hint">分享文案與你的感觸會分開保存。</p><button class="primary" data-action="add">存入測試採集匣</button><p id="msg" class="inline-msg" role="status"></p>';
}
document.addEventListener('click',async event=>{
 const b=event.target.closest('button');if(!b)return;
 if(b.id==='add')return addForm();if(b.id==='close')return $('sheet').close();
 if(b.dataset.filter){filter=b.dataset.filter;return draw()}if(b.dataset.id)return details(items.find(r=>r.id===b.dataset.id));
 const action=b.dataset.action;if(!action)return;const r=active;
 if(action==='add'){
  const share=$('share').value.trim(),info=parseShare(share);if(!info)return $('msg').textContent='請貼上含抖音或 B 站網址的分享訊息。';
  const old=items.find(x=>x.url===info.url);if(old){if(share!==info.url){old.share=share;const meta=dyShare(share);if(meta&&old.id==='dy'){old.title=meta.title;old.author=meta.author}save()}details(old);$('msg').textContent='這支影片已經收錄，已開啟原本的素材。';return}
  const row={...info,id:Date.now().toString(36),author:dyShare(share)?.author||'',title:$('title').value.trim()||dyShare(share)?.title||share.replace(/https?:\/\/\S+/gi,'').trim().slice(0,54)||info.platform+'影片',share,stage:'ready'};
  items.unshift(row);save();filter='all';return details(row)
 }

});
$('panel').addEventListener('input',e=>{if(!active)return;if(e.target.id==='returned')active.draft=e.target.value;else if(e.target.id==='note')active.note=e.target.value;else return;save()});
draw();
