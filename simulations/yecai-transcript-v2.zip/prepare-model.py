"""Install the exact browser ASR assets used by the v2 prototype."""
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
from urllib.request import urlopen
import os
import sys

ROOT = Path(__file__).resolve().parent
ENGINE = 'https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2/dist/'
MODEL = 'https://huggingface.co/Xenova/whisper-tiny/resolve/5332fcc35e32a33b86612b9a57a89be7906102b1/'
ASSETS = [
    ('engine/ort-wasm.wasm', ENGINE + 'ort-wasm.wasm', 'bbdcb6b3c7d294577d806077630460be4e13ca35a345acb5e81188e9649fa74a'),
    ('engine/ort-wasm-simd.wasm', ENGINE + 'ort-wasm-simd.wasm', '9bd07bababc65f53d061f457233eeae501be7ceb8a2adb9eef52d87fe776d865'),
    ('engine/transformers.min.js', ENGINE + 'transformers.min.js', 'bcf7cf304e51f470ed59409622b9d6ffbad80dfcf5baf6a40c919e4b9c4ff812'),
    ('model/tiny/config.json', MODEL + 'config.json', '2b2e4e519084e0ea028b19b153f95202735a971870d6844aa26e559edd292e94'),
    ('model/tiny/generation_config.json', MODEL + 'generation_config.json', '68ac791fcb4999461a313472125042934656240ba1cba7d1c2627fcbb19ac24c'),
    ('model/tiny/preprocessor_config.json', MODEL + 'preprocessor_config.json', 'a6a76d28c93edb273669eb9e0b0636a2bddbb1272c3261e47b7ca6dfdbac1b8d'),
    ('model/tiny/tokenizer.json', MODEL + 'tokenizer.json', '27fc476bfe7f17299480be2273fc0608e4d5a99aba2ab5dec5374b4482d1a566'),
    ('model/tiny/tokenizer_config.json', MODEL + 'tokenizer_config.json', '2a4c4281cf9f51ac6ccc406fdc711a087afe6530f671fa7b80953edc498275ce'),
    ('model/tiny/onnx/encoder_model_quantized.onnx', MODEL + 'onnx/encoder_model_quantized.onnx', 'fd9d995b9dcb0520f0dbf6cf68651af639fc385f594d9d876e69ca2802dc438e'),
    ('model/tiny/onnx/decoder_model_merged_quantized.onnx', MODEL + 'onnx/decoder_model_merged_quantized.onnx', '6c0c125986b007d2e3734bec84c18bda0152071b90b87fadac6d7764499927a0'),
]


def install(relative, url, digest, temporary):
    target = ROOT / relative
    split = relative.endswith('decoder_model_merged_quantized.onnx')
    parts = [target.with_name('decoder.part0'), target.with_name('decoder.part1')] if split else [target]
    if all(path.is_file() for path in parts):
        if sha256(b''.join(path.read_bytes() for path in parts)).hexdigest() == digest:
            print('Ready', relative)
            return
    with urlopen(url, timeout=90) as response:
        content = response.read()
    if sha256(content).hexdigest() != digest:
        raise ValueError('SHA-256 mismatch: ' + relative)
    target.parent.mkdir(parents=True, exist_ok=True)
    segments = [content[:16777216], content[16777216:]] if split else [content]
    for path, data in zip(parts, segments):
        draft = Path(temporary) / 'download'
        draft.write_bytes(data)
        os.replace(draft, path)
    print('Installed', relative)


if __name__ == '__main__':
    try:
        with TemporaryDirectory(dir=ROOT) as temp:
            for relative, url, digest in ASSETS:
                install(relative, url, digest, temp)
    except (OSError, ValueError) as error:
        sys.exit(str(error))
