// This private reader handles one user-provided public post at a time. It does
// not follow arbitrary outbound URLs, send cookies, or cache third-party posts.
import {threadAddress,sourceMeta,threadCanonical,extractThreadBody,fullCaption,samePost,publicAddress,threadAttr,hasThreadClass} from "../dist/threads-page-parser.js";

async function threadReadStream(stream,limit) {
  if(!stream)throw Error("沒有可讀取的內容。");
  const reader=stream.getReader(),decoder=new TextDecoder();let size=0,out="";
  try{
    for(;;){const {done,value}=await reader.read();if(done)break;
      size+=value.byteLength;if(size>limit){await reader.cancel();throw Error("內容超過單篇讀取範圍。");}
      out+=decoder.decode(value,{stream:true});}
    return out+decoder.decode();
  }finally{reader.releaseLock();}
}

async function threadFetch(url) {
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),9000);
  try{
    const response=await fetch(url, {headers:{Accept:"text/html"},redirect:"manual",signal:controller.signal});
    if([301,302,303,307,308].includes(response.status)){
      const location=response.headers.get("Location");
      if(response.body)await response.body.cancel();
      return {redirect:location?threadAddress(new URL(location,url).href):null,html:""};
    }
    if(!response.ok||!(response.headers.get("Content-Type")||"").toLowerCase().includes("text/html")){
      if(response.body)await response.body.cancel();
      throw Error("來源目前沒有提供公開原文。");
    }
    return {html:await threadReadStream(response.body,2400000)};
  }finally{clearTimeout(timer);}
}

async function resolveThread(address) {
  let point=address;const seen=new Set();
  for(let i=0;i<4;i++){
    if(point.code)return point;
    if(seen.has(point.url))break;seen.add(point.url);
    const fetched=await threadFetch(point.url+"/");
    point=fetched.redirect || threadAddress(sourceMeta(fetched.html,"og:url"));
    if(!point)break;
  }
  throw Error("未能從分享網址確認原帖。");
}

function threadSegments(s){return s.split(/\r\n|[\r\n\u2028\u2029]/u).map(t=>t.trim()).filter(Boolean);}
async function threadHash(text){const buf=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(text));return [...new Uint8Array(buf)].map(n=>n.toString(16).padStart(2,"0")).join("");}

function threadJson(data,status=200){
  return Response.json(data,{status,headers:{"Cache-Control":"private, no-store","X-Content-Type-Options":"nosniff"}});
}

export async function handleThreads(request) {
  if(request.method!=="POST")return threadJson({error:"請由閱讀頁指定原帖。"},405);
  if(request.headers.get("Sec-Fetch-Site")==="cross-site" || !(request.headers.get("Content-Type")||"").startsWith("application/json"))return threadJson({error:"此操作僅供閱讀頁使用。"},403);
  let input;
  try{input=JSON.parse(await threadReadStream(request.body,6500));}catch{return threadJson({error:"無法讀取網址或段號。"},400);}
  const address=threadAddress(input?.url);
  if(!address || !["capture","passage"].includes(input?.mode))return threadJson({error:"請提供有效的 Threads 貼文或分享網址。"},400);
  const p=input.p;
  if(input.mode==="passage"&&(!Number.isSafeInteger(p)||p<1||p>10000))return threadJson({error:"原文段號無效。"},400);
  let point=address;
  try{
    point=await resolveThread(address);
    let rendered=null,canonicalPage="",canonicalDoc=null,description="",caption="",allowCanonical=false;
    const embedUrl="https://www.threads.com/t/"+point.code+"/embed/?utm_source=th_embed&utm_campaign=threads_api";
    const native=await threadFetch(embedUrl);
    rendered=extractThreadBody(native.html,point);
    let source=rendered.address||point,text=rendered.text;
    async function loadCanonical(){
      if(allowCanonical)return;
      allowCanonical=true;
      if(!source?.author)return;
      const fetched=await threadFetch(source.url);
      canonicalPage=fetched.html;
      const found=threadCanonical(canonicalPage);
      if(!found?.author || !samePost(found,source))return;
      canonicalDoc=found;description=sourceMeta(canonicalPage,"og:description");
      caption=fullCaption(canonicalPage,found);
    }
    if(!text || !rendered.address){
      await loadCanonical();
      if(!canonicalDoc)throw Error("官方嵌文沒有可辨認的主文，來源頁也未提供符合的原帖網址。");
      source=canonicalDoc;
      const comparable=t=>threadSegments(t).join("\n").replace(/\s+/g," ");
      if(caption)text=caption;
      else if(text&&description&&comparable(text)===comparable(description)){/* full native target independently matched */}
      else if(input.mode==="passage" && /^[0-9a-f]{64}$/i.test(input.checks?.text||"") && description){text=description;}
      else throw Error(description?"來源頁提供了預覽；官方嵌文與完整主文欄位皆未能核對。":"已確認原帖網址，來源目前沒有提供可讀的主文。");
    }
    const doc={...source,text},lines=threadSegments(text);
    if(!lines.length)throw Error("原帖沒有可供比對的主文段落。");
    if(input.mode==="capture"){
      const title=Array.from(lines[0]).slice(0,40).join("");
      return threadJson({status:"ready",sourceUrl:address.url,url:doc.url,author:doc.author,title:title+(title.length<lines[0].length?"…":""),text:doc.text});
    }
    if(p>lines.length)return threadJson({status:"linked",reason:"目前的原帖版本沒有這個段落。",url:doc.url});
    const checks=input.checks||{},fieldNames=["before","text","after"],result={};
    let metadata=null;
    for(let i=0;i<3;i++){
      const key=fieldNames[i],idx=p-2+i,expected=checks[key];
      if(idx<0||idx>=lines.length){result[key]="";continue;}
      if(!expected || await threadHash(lines[idx])===expected){result[key]=lines[idx];continue;}
      // Meta may substitute a public metadata character for an inline sticker.
      // Use it only when it matches the previously verified paragraph exactly.
      if(metadata===null){
        try{await loadCanonical();metadata=canonicalDoc?threadSegments(description):[];}catch{metadata=[];}
      }
      result[key]=metadata[idx] && await threadHash(metadata[idx])===expected ? metadata[idx] : "";
    }
    if(!result.text)return threadJson({status:"linked",reason:"原帖文字與先前索引版本不同，請回來源核對。",url:doc.url});
    return threadJson({status:"ready",...result,url:doc.url,n:lines.length,p});
  }catch(err){
    const reason=err?.name==="AbortError"?"來源回應逾時。":err instanceof Error&&/[\u3400-\u9fff]/.test(err.message)?err.message:"來源目前未回傳可核對的公開主文。";
    return threadJson({status:"linked",reason,url:point?.url||address.url,author:point?.author||""});
  }
}
