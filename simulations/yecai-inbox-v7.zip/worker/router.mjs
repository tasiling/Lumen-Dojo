// The same routing rules are used by the local managed preview and the published Worker.
export const assetTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".jpg": "image/jpeg",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".webp": "image/webp",
  ".ico": "image/x-icon"
};

export function assetName(pathname) {
  if (pathname === "/") return "index.html";
  if (!/^\/[a-zA-Z0-9_-]+(?:\.[a-zA-Z0-9]+)?$/.test(pathname)) return null;
  const name = pathname.slice(1);
  return name.includes(".") ? name : name + ".html";
}

export async function routeSite(request, loadAsset, readThreads) {
  const url = new URL(request.url);
  if (url.pathname === "/api/threads-read") return readThreads(request);
  if (!["GET", "HEAD"].includes(request.method)) {
    return new Response(null, { status: 405, headers: { Allow: "GET, HEAD" } });
  }
  if (/^\/[a-zA-Z0-9_-]+\/$/.test(url.pathname)) {
    url.pathname = url.pathname.slice(0, -1);
    return Response.redirect(url, 308);
  }
  const name = assetName(url.pathname);
  const result = name && await loadAsset(name, request.method === "HEAD");
  if (!result) return new Response("找不到這個頁面", { status: 404 });
  return new Response(request.method === "HEAD" ? null : result.body, {
    headers: {
      "Content-Type": result.type,
      "Cache-Control": "private, no-cache",
      "X-Content-Type-Options": "nosniff"
    }
  });
}
