import assert from "node:assert/strict";
import {createHash} from "node:crypto";
import {createReadingBackup,restoreReadingBackup,parseReadingBackup} from "../dist/reading-backup.js";
class MemoryDB{
  constructor(){this.data=Object.fromEntries(["docs","links","notes","outside"].map(s=>[s,new Map()]));this.objectStoreNames=Object.keys(this.data);}
  transaction(names,mode){
    const sandbox=structuredClone(this.data),queue=[];let aborted=false;
    const issue=read=>{const req={};queue.push(()=>{req.result=read();req.onsuccess?.()});return req;};
    const tx={objectStore:name=>({get:id=>issue(()=>structuredClone(sandbox[name].get(id))),getAll:()=>issue(()=>structuredClone([...sandbox[name].values()])),put:row=>issue(()=>sandbox[name].set(row.id,structuredClone(row))),delete:id=>issue(()=>sandbox[name].delete(id)),add:row=>issue(()=>{assert(!sandbox[name].has(row.id));sandbox[name].set(row.id,structuredClone(row));})}),abort:()=>{aborted=true}};
    queueMicrotask(()=>{while(queue.length&&!aborted)queue.shift()();if(aborted)tx.onabort();else{if(mode==="readwrite")this.data=sandbox;tx.oncomplete();}});
    return tx;
  }
}
const doc={id:"local-"+"a".repeat(64),revision:"b".repeat(64),title:"我自己的原文",text:"第一段。\n第二段。",url:"",author:"作者"};
const note={id:"old",createdAt:1,method:"buddy",body:"v4",refs:[{id:doc.id,ps:[1]}]};
const whole={id:"v5",createdAt:2,method:"angles",body:"全文感想",refs:[{id:doc.id,ps:[0],quotes:[]}]};
const pending={id:"https://www.threads.com/share/example",url:"https://www.threads.com/share/example",status:"linked"};
const from=new MemoryDB(),to=new MemoryDB();
from.data.docs.set(doc.id,doc);from.data.notes.set(note.id,note);from.data.notes.set(whole.id,whole);from.data.links.set(pending.id,pending);
from.data.outside.set("secret",{id:"secret",surrogate:"exclude"});
const copy=await createReadingBackup(from);assert.deepEqual(Object.keys(copy.stores).sort(),["docs","links","notes"]);
const imported=parseReadingBackup(JSON.stringify(copy));assert.deepEqual(await restoreReadingBackup(imported,to),{added:4,same:0,conflicts:0});
assert.deepEqual(await restoreReadingBackup(imported,to),{added:0,same:4,conflicts:0});
to.data.notes.set("old",{...note,body:"裝置已有新版"});
assert.deepEqual(await restoreReadingBackup(imported,to),{added:0,same:3,conflicts:1});
assert.equal(to.data.notes.get("old").body,"裝置已有新版");
const bad=structuredClone(imported);bad.stores={notes:[{...whole,id:"extra"}],docs:[{...doc,text:"不同的文本"}]};
await assert.rejects(restoreReadingBackup(bad,to),/不同版本/);assert(!to.data.notes.has("extra"));
const unknown=structuredClone(imported);unknown.stores.outside=[];assert.throws(()=>parseReadingBackup(JSON.stringify(unknown)),/不同版本/);
const unsafe=structuredClone(imported);unsafe.stores.docs[0].url="javascript:alert(1)";assert.throws(()=>parseReadingBackup(JSON.stringify(unsafe)),/內容無效/);
const canonical="https://www.threads.com/@tester/post/FixtureV5";
const sourceUrl="https://www.threads.com/share/ExampleV5";
const fullText="這是自行編寫的第一段。\n第二段也要核對。",revision="test-revision";
const hashes=fullText.split("\n").map(line=>createHash("sha256").update(line).digest("hex"));
globalThis.document={baseURI:"https://site.example/reading"};
globalThis.fetch=async url=>{
  assert.equal(url.href,"https://site.example/corpus-index.json");
  return Response.json([{id:"FixtureV5",revision,paragraphHashes:hashes}]);
};
const verified={id:canonical,url:canonical,sourceUrl,title:"完整測試",author:"tester",status:"ready",
  docId:"FixtureV5",verifiedMain:{revision,text:fullText},createdAt:5};
const pendingAlias={id:sourceUrl,url:sourceUrl,sourceUrl,status:"linked",collectionReason:"本機收藏理由",createdAt:2};
const testdb=new MemoryDB();testdb.data.links.set(sourceUrl,pendingAlias);
const withPage={...copy,stores:{docs:[],notes:[],links:[verified]}};
const stats=await restoreReadingBackup(parseReadingBackup(JSON.stringify(withPage)),testdb);
assert.equal(stats.added,1);assert.equal(testdb.data.links.size,1);
const upgraded=testdb.data.links.get(canonical);
assert.deepEqual(upgraded.verifiedMain,verified.verifiedMain);assert.equal(upgraded.collectionReason,pendingAlias.collectionReason);
const reacquired=await createReadingBackup(testdb);
assert.deepEqual(reacquired.stores.links[0].verifiedMain,verified.verifiedMain);
assert.equal((await restoreReadingBackup(withPage,testdb)).added,0);
await restoreReadingBackup({...copy,stores:{docs:[],notes:[],links:[pendingAlias]}},testdb);
assert.deepEqual(testdb.data.links.get(canonical),upgraded);assert.equal(testdb.data.links.size,1);
for(const field of [{text:fullText+"假的"},{revision:"old"},{text:"只有一段"}]){
  const altered=structuredClone(withPage);
  Object.assign(altered.stores.links[0].verifiedMain,field);
  altered.stores.notes.push({...whole,id:"should-not-write"});
  await assert.rejects(restoreReadingBackup(altered,testdb),/不符/);assert(!testdb.data.notes.has("should-not-write"));
}
const crossSource=structuredClone(withPage);crossSource.stores.links[0].sourceUrl="https://www.threads.com/@tester/post/OtherId";
assert.throws(()=>parseReadingBackup(JSON.stringify(crossSource)),/無效/);
console.log("Verified reading backups, source revisions, paragraph hashes, pending-to-full merges, independent notes, and repeat restores.");
