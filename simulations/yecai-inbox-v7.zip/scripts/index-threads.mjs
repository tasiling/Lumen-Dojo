// Usage: node scripts/index-threads.mjs <verified author main-post JSON>
// Input records contain { canonical, meta }. No full third-party post is copied into the site.
import {readFile,writeFile} from "node:fs/promises";
import {createHash} from "node:crypto";
import {guides} from "../dist/corpus-guides.js";
import {indexWords,paragraphs} from "../dist/corpus-words.js";
const source=JSON.parse(await readFile(process.argv[2],"utf8"));
const records=source.map(({canonical,meta})=>{
  const id=new URL(canonical).pathname.split("/").pop();
  const lines=paragraphs(meta);
  const marks={};
  for(const [name,phrase] of Object.entries(guides[id].marks)){
    const hits=lines.map((text,i)=>text.includes(phrase)?i+1:0).filter(Boolean);
    if(hits.length!==1)throw new Error(id+" / "+name+": expected one original paragraph, got "+hits.length);
    marks[name]=hits[0];
  }
  return {id,revision:createHash("sha256").update(lines.join("\n")).digest("hex").slice(0,16),marks,
    paragraphHashes:lines.map(line=>createHash("sha256").update(line).digest("hex")),
    words:lines.map(line=>indexWords(line).sort())};
});
if(new Set(records.map(x=>x.id)).size!==Object.keys(guides).length)throw Error("Incomplete seed collection");
await writeFile(new URL("../dist/corpus-index.json",import.meta.url),JSON.stringify(records));
console.log("Indexed "+records.length+" posts, "+records.reduce((n,r)=>n+r.words.length,0)+" author paragraphs.");
