import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { Corpus, methods } from '../dist/corpus-engine.js';
import { parseFile } from '../dist/corpus-store.js';
import { inspectSavedThread } from '../dist/reading-page-file.js';
import { unpackReadingPage } from '../dist/reading-webarchive.js';

const file = name => readFile(new URL('../' + name, import.meta.url));
const corpus = new Corpus();
const seeds = JSON.parse(await file('dist/corpus-index.json'));
const sourceScript = await file('dist/threads-source.js');
const meta = vm.runInNewContext(sourceScript + ';threadsBatch.map(p => ({ ...p, url: threadsPermalink(p) }))', {
  HTMLElement: class {}, customElements: { define() {} }
});
assert.equal(seeds.length, 10);
for (const [i, seed] of seeds.entries()) {
  assert.equal(meta[i].code, seed.id);
  assert(corpus.addSeed(meta[i], seed));
}
const options = { method: 'buddy', focus: 'basis', query: '', selection: [], onlySelected: false, group: '', page: 1 };
for (const [method, guide] of Object.entries(methods)) {
  for (const focus of Object.keys(guide.choices)) {
    const result = corpus.list({ ...options, method, focus });
    assert.equal(result.shown, 10);
    assert.equal(result.allParagraphs, 56);
    for (const row of result.rows) {
      for (const block of row.blocks) {
        assert(corpus.source(row.id).anchors.some(anchor => anchor.p === block.p && anchor.quote === block.quote));
      }
    }
  }
}
const stress = parseFile((await file('fixtures/yecai-corpus-qa-5000.jsonl')).toString());
assert.equal(stress.length, 5000);
stress.forEach((doc, i) => assert(corpus.addLocal({ ...doc, id: 't' + i, revision: 'v1' })));
assert(!corpus.addLocal({ ...stress[0], id: 't0' }));
for (const [method, guide] of Object.entries(methods)) {
  const result = corpus.list({ ...options, method, focus: Object.keys(guide.choices)[0] });
  assert.equal(result.total, 5010);
  assert.equal(result.allParagraphs, 10056);
  assert.equal(result.rows.length, 12);
  assert.equal(result.pages, 418);
}
assert.equal(corpus.list({ ...options, page: 500 }).rows.at(-1).title, '壓測素材 5000');
assert.deepEqual(corpus.list({ ...options, query: 'quartzneedle' }).rows.map(row => row.found), [[2]]);
const demo = parseFile((await file('fixtures/ten-demo-posts.json')).toString());
assert.equal(new Set(demo.map(d => d.title)).size, 10);
assert(demo.every(d => d.text.split('\n').length === 2));
let original;
for (const extension of ['html', 'webarchive']) {
  const content = await file('fixtures/saved-thread.' + extension);
  const record = inspectSavedThread(unpackReadingPage(content));
  assert.equal(record.id, 'DemoQA900');
  assert.equal(record.texts.length, 1);
  assert.match(record.texts[0], /今天交班時/);
  if (original) assert.deepEqual(record, original);
  original = record;
}
console.log('PASS: 10 original indexes, 4 reading methods, 5,000 imports, 10,056 paragraphs, 418 pages, search, ten offline examples, HTML and Safari archive.');
