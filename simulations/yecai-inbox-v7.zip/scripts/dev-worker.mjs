import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { extname } from "node:path";
import { Readable } from "node:stream";
import { routeSite, assetTypes } from "../worker/router.mjs";

const dist = new URL("../dist/", import.meta.url);
const args = process.argv.slice(2);
function flag(name) {
  const i = args.indexOf(name);
  if (i >= 0 && args[i + 1] && !args[i + 1].startsWith("-")) return args[i + 1];
  return args.find(s => s.startsWith(name + "="))?.slice(name.length + 1);
}
const port = Number(flag("--port") || process.env.PORT || 5173);
const host = flag("--host") || process.env.HOST || "127.0.0.1";

async function loadAsset(name, head) {
  const type = assetTypes[extname(name)];
  if (!type) return null;
  try {
    const contents = await readFile(new URL(name, dist));
    return { type, body: head ? null : contents };
  } catch (e) {
    if (e.code === "ENOENT") return null;
    throw e;
  }
}
const endpoint = new URL("../worker/threads-endpoint.mjs", import.meta.url);
async function readThreads(req) {
  const { handleThreads } = await import(endpoint);
  return handleThreads(req);
}
const server = createServer(async (incoming, outgoing) => {
  try {
    const init = { method: incoming.method, headers: incoming.headers };
    if (init.method !== "GET" && init.method !== "HEAD") {
      init.body = Readable.toWeb(incoming);
      init.duplex = "half";
    }
    const request = new Request(new URL(incoming.url, "http://" + incoming.headers.host), init);
    const result = await routeSite(request, loadAsset, readThreads);
    outgoing.writeHead(result.status, Object.fromEntries(result.headers));
    if (result.body) Readable.fromWeb(result.body).pipe(outgoing);
    else outgoing.end();
  } catch (error) {
    console.error(error.message);
    if (!outgoing.headersSent) outgoing.writeHead(500);
    outgoing.end("讀取失敗");
  }
});
server.listen(port, host, () => console.log("Worker preview listening on port " + port));
for (const signal of ["SIGINT", "SIGTERM"]) process.on(signal, () => server.close(() => process.exit(0)));
