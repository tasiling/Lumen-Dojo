import { readFile, writeFile, readdir, mkdir, rename } from "node:fs/promises";
import { extname } from "node:path";
import { assetTypes } from "../worker/router.mjs";

const dist = new URL("../dist/", import.meta.url);
const [endpointFile, parserFile, router, entries] = await Promise.all([
  readFile(new URL("../worker/threads-endpoint.mjs", import.meta.url), "utf8"),
  readFile(new URL("../dist/threads-page-parser.js", import.meta.url), "utf8"),
  readFile(new URL("../worker/router.mjs", import.meta.url), "utf8"),
  readdir(dist, { withFileTypes: true })
]);
const endpoint=parserFile.replace(/^export \{[^\n]*\};$/m,"")+"\n"+endpointFile.replace(/^import \{[^\n]*\} from "\.\.\/dist\/threads-page-parser\.js";$/m,"");
if (/^\s*import\s/m.test(endpoint) || /export\s+default\s+/.test(endpoint)) {
  throw Error("The Threads endpoint must be self-contained and use named exports.");
}
// Keep the existing source assets in place. Hosting receives a single self-contained
// Worker which returns the original UTF-8 text or the original binary image bytes.
const assets = {};
for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name, "en"))) {
  if (!entry.isFile() || entry.name.startsWith(".")) continue;
  const type = assetTypes[extname(entry.name)];
  if (!type) throw Error("Add the asset's HTTP content type: " + entry.name);
  const bytes = await readFile(new URL(entry.name, dist));
  const binary = !type.includes("charset") && type !== "image/svg+xml";
  assets[entry.name] = { type, binary, data: bytes.toString(binary ? "base64" : "utf8") };
}
const runtime = [
  'function loadBundledAsset(name, head) {',
  '  if (!Object.hasOwn(bundledAssets, name)) return null;',
  '  const {type, binary, data} = bundledAssets[name];',
  '  let body = head ? null : data;',
  '  if (binary && !head) {',
  '    const asset = bundledAssets[name];',
  '    if (!asset.decoded) asset.decoded = typeof Uint8Array.fromBase64 === "function"',
  '      ? Uint8Array.fromBase64(data) : Uint8Array.from(atob(data), ch => ch.charCodeAt(0));',
  '    body = asset.decoded;',
  '  }',
  '  return {type, body};',
  '}',
  'export default { fetch(request) { return routeSite(request, loadBundledAsset, handleThreads); } };'
].join("\n");
const bundle = [endpoint, router, "const bundledAssets = " + JSON.stringify(assets) + ";", runtime].join("\n\n");
await mkdir(new URL("server/", dist), { recursive: true });
await writeFile(new URL("server/index.js.next", dist), bundle);
await rename(new URL("server/index.js.next", dist), new URL("server/index.js", dist));
console.log("Built Worker with " + Object.keys(assets).length + " site assets.");
