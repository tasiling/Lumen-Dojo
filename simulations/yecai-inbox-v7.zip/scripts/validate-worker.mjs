import assert from "node:assert/strict";
import { readFile, readdir } from "node:fs/promises";
import { extname } from "node:path";
import deployed from "../dist/server/index.js";
import { assetTypes, routeSite } from "../worker/router.mjs";

const dist = new URL("../dist/", import.meta.url);
const base = "https://site.example";
const request = (path, options) => new Request(base + path, options);
const files = (await readdir(dist, { withFileTypes: true })).filter(f => f.isFile() && !f.name.startsWith("."));
for (const file of files) {
  const res = await deployed.fetch(request("/" + file.name));
  assert.equal(res.status, 200, file.name);
  assert.equal(res.headers.get("content-type"), assetTypes[extname(file.name)]);
  const expected = await readFile(new URL(file.name, dist));
  assert.deepEqual(Buffer.from(await res.arrayBuffer()), expected, file.name);
}
for (const path of ["/", "/reading?from=review", "/threads", "/reading-pair"]) {
  const res = await deployed.fetch(request(path, { method: "HEAD" }));
  assert.equal(res.status, 200, path);
  assert.match(res.headers.get("content-type"), /^text\/html/);
  assert.equal(await res.text(), "");
}
const trailing = await deployed.fetch(request("/reading/?from=review"));
assert.equal(trailing.status, 308);
assert.equal(trailing.headers.get("location"), base + "/reading?from=review");
assert.equal((await deployed.fetch(request("/page-that-does-not-exist"))).status, 404);
assert.equal((await deployed.fetch(request("/server/index.js"))).status, 404);
assert.equal((await deployed.fetch(request("/reading", { method: "POST" }))).status, 405);
// Test endpoint dispatch independently of the constantly changing public source.
const api = request("/api/threads-read", { method: "POST", body: "{}" });
const dispatched = await routeSite(api, () => assert.fail("API reached static routing"), req => {
  assert.equal(req, api);
  return Response.json({ received: true });
});
assert.deepEqual(await dispatched.json(), { received: true });
assert.equal(typeof deployed.fetch, "function");
console.log("Verified " + files.length + " assets, page aliases, and routing.");
