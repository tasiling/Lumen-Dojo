# 素材採集匣 v0.2

BiliNote 純轉錄橋接工程修正版。詳見 [建置狀態](selfhost/README.md)。

Linux 真正模型和 HTTP 已驗證；Docker／使用者 Mac／平台影片下載尚未完成端到端驗證。使用者尚未測試及核准，不列正式工具。

`npm test`：收藏核心測試。`python scripts/package.py`：建立自架工程包及狀態說明。後端測試需實際 BiliNote 原始碼及 Faster-Whisper 依賴，不使用假的辨識結果。
