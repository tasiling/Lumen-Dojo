const {test}=require('node:test'),assert=require('node:assert/strict');
const U=require('../dist/ux.js'),C=require('../dist/core.js');
test('URL-only capture works, duplicate tracking links canonicalize and malicious URLs cannot enter',()=>{
 const a=U.capture('https://www.bilibili.com/video/BV123?vd_source=aaa',C),b=U.capture('https://www.bilibili.com/video/BV123',C);
 assert.equal(a.url,b.url);assert.ok(C.record(a).title);assert.throws(()=>U.capture('javascript:alert(1)',C));
});
test('reading opens actual contents; search directs to matching source rather than unrelated AI summary',()=>{
 const r={transcript:'spoken words',aiSummary:'short digest'};assert.equal(U.readTab(r),'aiSummary');assert.equal(U.readTab(r,'spoken'),'transcript');assert.equal(U.readTab({}),'overview');
});
test('uncertain submissions never suggest duplicate work; failed work offers deliberate recovery',()=>{
 const r={platform:'bilibili',job:{status:'UNKNOWN'}};assert.equal(U.action(r).kind,'wait');r.job.status='FAILED';assert.equal(U.action(r).kind,'transcribe');assert.match(U.action(r).label,/重試/);
});
test('Threads offers social extraction, not video transcription; saved content allows explicit AI action',()=>{
 assert.equal(U.action({platform:'threads'}).kind,'social');assert.equal(U.action({platform:'threads',original:'real post'}).kind,'ai');assert.equal(U.action({transcript:'hello'},{status:'RUNNING'}).kind,'wait');
});
test('failure detail survives serialization and backup roundtrip',()=>{
 const r=C.record({title:'failure',job:{taskId:'abc',status:'FAILED',message:'HTTP Error 567'}});
 const [restored]=C.parseBackup(JSON.parse(JSON.stringify({schema:'material-inbox/v1',records:[r]})));assert.equal(restored.job.message,'HTTP Error 567');
});
const fs=require('node:fs'),vm=require('node:vm');
function tracker(overrides={}){
 const source=fs.readFileSync('dist/app.js','utf8'),start=source.indexOf('let tracking=false'),end=source.indexOf('async function trackingLoop');
 const state={shared:true,engineReady:true,document:{hidden:false,activeElement:null},writeQueue:Promise.resolve(),records:[],U,C,JSON,Date,selectedRecord:()=>null,$:()=>null,render:()=>{},renderDetail:()=>{},aiJobs:[],aiOnline:false,lastSync:'',syncError:'',...overrides};
 const ctx=vm.createContext(state);vm.runInContext(source.slice(start,end),ctx);return ctx;
}
test('automatic tracking reads original task, saves failure details, never submits a replacement',async()=>{
 const r=C.record({title:'test',job:{taskId:'task-1',status:'UNKNOWN'}}),calls=[];let patch;
 const ctx=tracker({records:[r],api:async p=>{calls.push(p);if(p.includes('task_status/'))return {status:'FAILED',message:'HTTP Error 567'};if(p.endsWith('jobs'))return {jobs:[],workerOnline:false};return {records:[r]};},update:async(id,value)=>{patch=value;}});
 await ctx.track();assert.equal(patch.job.message,'HTTP Error 567');assert.ok(calls.every(p=>!p.includes('transcribe')));
});
test('background collection read cannot overwrite an overlapping user save',async()=>{
 let resolveRead,requested;const started=new Promise(r=>requested=r),fresh=C.record({title:'fresh user save'});
 const ctx=tracker({api:async p=>{if(p.endsWith('jobs'))return {jobs:[],workerOnline:false};requested();return new Promise(r=>resolveRead=r);}});
 const pending=ctx.track();await started;ctx.records=[fresh];resolveRead({records:[]});await pending;assert.equal(ctx.records[0].title,'fresh user save');
});
test('hidden page pauses tracking; network failure retains records and communicates recovery',async()=>{
 let calls=0;const r=C.record({title:'keep me'}),ctx=tracker({records:[r],document:{hidden:true},api:async()=>{calls++;throw Error('offline');}});
 await ctx.track();assert.equal(calls,0);ctx.document.hidden=false;await ctx.track();assert.equal(ctx.records[0].title,'keep me');assert.match(ctx.syncError,/offline/);
});
