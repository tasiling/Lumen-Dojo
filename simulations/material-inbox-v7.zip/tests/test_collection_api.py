import pathlib,sys,tempfile,unittest,uuid,os
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'selfhost/runtime'))
from fastapi import FastAPI
from fastapi.testclient import TestClient
from collector_runtime import CollectorRuntime,install
class ApiTest(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.root=pathlib.Path(self.tmp.name);app=FastAPI();install(app,CollectorRuntime(self.root));self.c=TestClient(app,base_url='http://127.0.0.1:8480');self.store=app.state.collection
  self.token=(self.root/'collector_worker.token').read_text();self.headers={'Authorization':'Bearer '+self.token}
 def save(self,id='one',text='來源'):
  return self.c.put('/api/collector/collection/'+id,json={'expectedVersion':0,'record':{'id':id,'title':'Test','transcript':text}})
 def test_real_http_crud_conflict_and_shared_read(self):
  self.assertEqual(self.save().status_code,200)
  self.assertEqual(self.save(text='覆寫').status_code,409)
  self.assertEqual(self.c.get('/api/collector/collection').json()['data']['records'][0]['transcript'],'來源')
  self.assertEqual(self.c.delete('/api/collector/collection/one?version=0').status_code,409)
  self.assertEqual(self.c.delete('/api/collector/collection/one?version=1').status_code,200)
 def test_worker_auth_cloud_consent_and_result(self):
  self.save();self.assertEqual(self.c.post('/api/collector/worker/claim',json={}).status_code,403)
  self.c.post('/api/collector/worker/heartbeat',headers=self.headers,json={})
  body={'recordId':'one','mode':'summary','requestId':str(uuid.uuid4())}
  self.assertEqual(self.c.post('/api/collector/ai/jobs',json=body).status_code,400)
  body['consent']=True;self.assertEqual(self.c.post('/api/collector/ai/jobs',json=body).status_code,200)
  job=self.c.post('/api/collector/worker/claim',headers=self.headers,json={}).json()['data']
  self.assertEqual(job['source']['transcript'],'來源')
  done=self.c.post('/api/collector/worker/finish',headers=self.headers,json={'id':job['id'],'lease':job['lease'],'result':'整理完成'})
  self.assertEqual(done.status_code,200);self.assertEqual(self.store.get('one')['aiSummary'],'整理完成')
  self.assertNotIn('lease',self.c.get('/api/collector/ai/jobs').text)
 def test_foreign_hosts_origins_and_worker_origin_rejected(self):
  for headers in ({'Host':'attacker.test'},{'Origin':'null'},{'Origin':'https://attacker.test'},{'Sec-Fetch-Site':'cross-site'}):
   self.assertEqual(self.c.get('/api/collector/collection',headers=headers).status_code,403)
  self.assertEqual(self.c.post('/api/collector/worker/claim',headers={**self.headers,'Origin':'http://127.0.0.1:8481'},json={}).status_code,403)
 def test_exact_tailnet_origin(self):
  host = uuid.uuid4().hex + '.ts.net'
  other_host = uuid.uuid4().hex + '.ts.net'
  origin = 'https://' + host
  old=os.environ.get('COLLECTOR_ALLOWED_ORIGIN');os.environ['COLLECTOR_ALLOWED_ORIGIN']=origin
  try:
   self.assertEqual(self.c.get('/api/collector/collection',headers={'Host':host,'Origin':origin}).status_code,200)
   self.assertEqual(self.c.get('/api/collector/collection',headers={'Host':other_host}).status_code,403)
  finally:
   if old is None:os.environ.pop('COLLECTOR_ALLOWED_ORIGIN',None)
   else:os.environ['COLLECTOR_ALLOWED_ORIGIN']=old
if __name__=='__main__':unittest.main()
