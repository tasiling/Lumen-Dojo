const {test}=require('node:test');
const assert=require('node:assert/strict');
const C=require('../dist/core.js');
const make=(d={})=>C.record({title:'測試素材',...d});
test('分享文字解析抖音網址',()=>assert.equal(C.cleanUrl('6.3 分享影片 https://v.douyin.com/abc/ 複製此連結'),'https://v.douyin.com/abc/'));
test('B站去追蹤，保留分P',()=>assert.equal(C.cleanUrl('https://www.bilibili.com/list/watchlater/?bvid=BV123abc&p=36&vd_source=xx'),'https://www.bilibili.com/video/BV123abc?p=36'));
test('不同分P不誤合併',()=>{const out=C.merge([make({url:'https://www.bilibili.com/video/BV123abc?p=1'})],[make({url:'https://www.bilibili.com/video/BV123abc?p=2'})]);assert.equal(out.added,1);});
test('相同來源或id不覆蓋原稿',()=>{const r=make({url:'https://threads.com/@test/post/A',original:'原文'});const out=C.merge([r],[make({...r,original:'新文'}),make({url:r.url,notes:'新筆記'})]);assert.equal(out.skipped,2);assert.equal(out.records[0].original,'原文');});
test('平台偽冒網域不當作抖音',()=>assert.equal(C.detect('https://douyin.com.evil.example/video/123'),'web'));
test('拒絕帶帳密的來源', () => {
  const url = new URL('https://example.com/');
  url.username = 'fixture';
  url.password = require('node:crypto').randomUUID();
  assert.throws(() => make({url: url.toString()}));
});
test('拒絕javascript與空標題',()=>{assert.throws(()=>make({url:'javascript:alert(1)'}));assert.throws(()=>make({title:'  '}));});
test('備份格式錯誤不產生可合併資料',()=>{assert.throws(()=>C.parseBackup({records:[]}));assert.throws(()=>C.parseBackup({schema:'material-inbox/v1',records:[null]}));});
test('來源原文、逐字稿、AI稿與筆記獨立',()=>{const r=make({original:'原文',transcript:'原話',aiSummary:'整理',notes:'我的想法'});const s=C.markdown(r);for(const t of ['原文','原話','整理','我的想法'])assert.ok(s.includes(t));assert.equal(r.original,'原文');});
test('搜尋包含原文、逐字稿、AI稿、筆記及標籤',()=>{const r=make({original:'ORIGINAL',transcript:'逐字稿',aiSummary:'整理稿',notes:'自己的疑問',tags:['按摩']});for(const q of ['original','逐字稿','整理稿','疑問','按摩'])assert.ok(C.match(r,q));});
test('CSV防公式注入並保留多行引號',()=>{const s=C.csv([make({title:'=SUM(1,2)',original:'第一行\n"第二行"'})]);assert.ok(s.includes("'=SUM"));assert.ok(s.includes('""第二行""'));});
test('原版BiliNote直存結果和API結果皆能讀入',()=>{const d={markdown:'AI稿',transcript:{full_text:'全文',segments:[{start:1,end:3,text:'全文'}]}};for(const input of [d,{result:d},{code:0,data:{status:'SUCCESS',result:d}}]){const r=C.biliResult(input);assert.equal(r.transcript,'全文');assert.equal(r.aiSummary,'AI稿');assert.equal(r.segments[0].start,1);}});
test('只有摘要不能偽裝逐字稿',()=>{assert.throws(()=>C.biliResult({markdown:'只有摘要'}));assert.throws(()=>C.biliResult({transcript:{segments:[]}}));});
test('備份保留時間、修訂、任務與轉錄段落',()=>{const r=make({createdAt:'2026-11-15T00:00:00Z',segments:[{start:2,end:4,text:'片段'}],revisions:[{at:'2026-11-15T00:00:00Z',original:'舊原文',transcript:'舊稿'}],job:{taskId:'abc-123',status:'PENDING'}});assert.deepEqual(C.parseBackup(JSON.parse(JSON.stringify({schema:'material-inbox/v1',records:[r]})))[0],r);});
test('無效識別、時間與過大備份拒絕',()=>{assert.throws(()=>make({id:{bad:true}}));assert.throws(()=>make({createdAt:'not a date'}));assert.throws(()=>C.parseBackup({schema:'material-inbox/v1',records:new Array(2001).fill({title:'a'})}));});

test("損壞修訂拒絕，避免讀取頁崩潰",()=>assert.throws(()=>make({revisions:[null]})));
test('新版共用版本與畫面及AI依據可備份往返',()=>{
 const r=C.record({title:'畫面',version:8,visualText:'可見文字',visualSegments:[{start:1,text:'可見文字',image:'frame-0001.jpg'}],visualJob:{id:'11111111-1111-1111-1111-111111111111',status:'SUCCESS'},aiRuns:[{text:'摘要',source:{transcript:'口述'},stale:true}]});
 const restored=C.parseBackup(JSON.parse(JSON.stringify({schema:'material-inbox/v1',records:[r]})))[0];
 assert.equal(restored.version,8);assert.equal(restored.visualText,'可見文字');assert.equal(restored.aiRuns[0].source.transcript,'口述');assert.equal(restored.visualSegments[0].image,'frame-0001.jpg');
 assert.ok(C.markdown(restored).includes('可見文字'));assert.ok(C.match(restored,'可見文字'));
});

test('social extraction keeps selected author replies separate across JSON backups',()=>{
 const r=C.record({title:'post',url:'https://www.instagram.com/p/a/',original:'main',socialExtraction:{quality:'partial',authorReplies:[{text:'reply',url:'https://www.threads.com/@a/post/b'}],warnings:['partial']}});
 const restored=C.parseBackup(JSON.parse(JSON.stringify({schema:'material-inbox/v1',records:[r]})))[0];assert.equal(restored.platform,'instagram');assert.equal(restored.original,'main');assert.equal(restored.socialExtraction.authorReplies[0].text,'reply');assert.match(C.markdown(restored),/reply/);assert.equal(C.detect('https://www.facebook.com/reel/1'),'facebook');assert.equal(C.detect('https://facebook.com.bad.test/reel/1'),'web');
});
