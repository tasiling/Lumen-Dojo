import pathlib,sys,unittest,tempfile,uuid
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'selfhost/runtime'))
from social_reader import parse_reader,validate_url,extract
from collection_api import install_collection
from fastapi import FastAPI
from fastapi.testclient import TestClient
from types import SimpleNamespace

URL='https://www.threads.com/@writer/post/abc'
RAW='''Title: writer on Threads

URL Source: https://www.threads.com/@writer/post/abc

Markdown Content:
[2d](https://www.threads.com/@writer/post/abc)

第一段原文。

第二段原文。

Translate

12

[![Image 1: reader's profile picture](https://example.com/p.jpg)](https://www.threads.com/@reader)

[2d](https://www.threads.com/@reader/post/def)

讀者留言不能混入。

Translate

[2d](https://www.threads.com/@writer/post/ghi)

·Author

這是作者的回覆。

Translate

Related threads

[2d](https://www.threads.com/@writer/post/jkl)

·Author

不相關貼文不能混入。
'''
class ReaderTest(unittest.TestCase):
 def test_main_replies_related_separation(self):
  r=parse_reader(RAW,URL)
  self.assertEqual(r['text'],'第一段原文。\n\n第二段原文。')
  self.assertEqual([x['text'] for x in r['authorReplies']],['這是作者的回覆。'])
 def test_unknown_layout_login_and_fake_hosts_fail(self):
  user_info_url = 'https://' + 'fixture:' + uuid.uuid4().hex + '@threads.com/share/abc'
  for u in ['http://127.0.0.1/a','https://threads.com.attacker.test/share/abc',user_info_url,'https://threads.com:444/share/a','https://threads.com/@writer','https://instagram.com/username/']:
   with self.assertRaises(ValueError):validate_url(u)
  for raw in ['Title: Threads\nMarkdown Content:\nLog in', RAW.replace('/post/abc','/post/other')]:
   with self.assertRaises(ValueError):parse_reader(raw,URL)
 def test_ig_caption_not_comments(self):
  raw='Title: Writer on Instagram: "A caption"\n\nURL Source: https://instagram.com/p/a\n\nMarkdown Content:\nA caption\nSpam comment'
  r=parse_reader(raw,'https://instagram.com/p/a');self.assertEqual(r['text'],'A caption');self.assertEqual(r['quality'],'review')
  self.assertEqual(parse_reader(raw.replace('A caption\nSpam','Truncated\nSpam'),'https://instagram.com/p/a')['quality'],'partial')
 def test_fb_metadata_always_partial(self):
  r=parse_reader('Title: 12 views · 3 reactions | A recipe | Writer\n\nURL Source: https://facebook.com/reel/123\n\nMarkdown Content:\nLog In','https://facebook.com/reel/123')
  self.assertEqual(r['text'],'A recipe');self.assertEqual(r['quality'],'partial')
 def test_preview_no_write_and_conflict_and_consent(self):
  with tempfile.TemporaryDirectory() as root:
   app=FastAPI();store=install_collection(app,SimpleNamespace(root=pathlib.Path(root)));c=TestClient(app)
   store.save({'id':'one','title':'Old','url':URL,'original':'keep'},0)
   data={'recordId':'one','expectedVersion':1,'consent':True}
   with patch('collection_api.extract',return_value=parse_reader(RAW,URL)) as mocked:
    self.assertEqual(c.post('/api/collector/social/preview',json={**data,'consent':False}).status_code,400)
    self.assertEqual(c.post('/api/collector/social/preview',json={**data,'expectedVersion':0}).status_code,409)
    self.assertEqual(c.post('/api/collector/social/preview',json=data).status_code,200)
    self.assertEqual(mocked.call_count,1)
   self.assertEqual(store.get('one')['original'],'keep');self.assertEqual(store.get('one')['version'],1)
   row=store.get('one');row['original']='new';row['socialExtraction']=parse_reader(RAW,URL)
   store.save(row,1);self.assertEqual(store.get('one')['revisions'][-1]['original'],'keep')
   self.assertEqual(store.get('one')['socialExtraction']['authorReplies'][0]['text'],'這是作者的回覆。')
if __name__=='__main__':unittest.main()
