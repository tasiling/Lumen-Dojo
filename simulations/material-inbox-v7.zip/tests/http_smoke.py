"""Real subprocess + TCP HTTP + model + upload smoke (requires local runtime config)."""
import json, os, pathlib, subprocess, time, uuid
import httpx
ROOT=pathlib.Path(__file__).resolve().parents[1]
c=json.loads((ROOT/'.openai/local-runtime.json').read_text())
env={**os.environ,**c['env'],'BACKEND_PORT':'8485','PYTHONPATH':str(ROOT/'selfhost/runtime')+':'+c['source']+'/backend'}
log=pathlib.Path(c['state'])/'http-smoke.log'
with log.open('w') as output:
 p=subprocess.Popen([c['python'],str(ROOT/'selfhost/runtime/verified_main.py')],cwd=c['state'],env=env,stdout=output,stderr=subprocess.STDOUT)
 try:
  with httpx.Client(base_url='http://127.0.0.1:8485',trust_env=False,timeout=30) as client:
   for _ in range(180):
    if p.poll() is not None: raise RuntimeError('Backend exited; see local smoke log')
    try:
     health=client.get('/api/collector/health').json()['data']
     if health['phase']=='failed': raise RuntimeError(health['message'])
     if health['ready']: break
    except httpx.ConnectError: pass
    time.sleep(1)
   else: raise RuntimeError('Model did not become ready')
   task=str(uuid.uuid4());fixture=ROOT/'selfhost/runtime/fixtures/zh.mp3'
   response=client.post('/api/collector/transcribe-file',data={'task_id':task},files={'file':('zh.mp3',fixture.read_bytes(),'audio/mpeg')})
   response.raise_for_status()
   for _ in range(90):
    job=client.get('/api/collector/tasks/'+task).json()['data']
    if job['status'] in ('SUCCESS','FAILED'):break
    time.sleep(1)
   assert job['status']=='SUCCESS',job.get('message')
   transcript=job['result']['transcript'];assert transcript['language']=='zh' and transcript['segments'] and len(transcript['full_text'])>=8
   assert 'file' not in job and 'fingerprint' not in job
   report={'http_smoke':'passed','model':health['model'],'model_revision':health['model_revision'],'speech_probe':health['speech_probe'],'upload':{'status':job['status'],'language':transcript['language'],'characters':len(transcript['full_text']),'segments':len(transcript['segments'])},'requires_api_key':False,'container_tested':False,'mac_tested':False}
   (pathlib.Path(c['state'])/'http-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
   print(json.dumps(report,ensure_ascii=False))
 finally:
  p.terminate()
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:p.kill();p.wait()
