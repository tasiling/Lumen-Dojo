import importlib.util,pathlib,sys,unittest,uuid
host=pathlib.Path(__file__).resolve().parents[1]/'selfhost/host';sys.path.insert(0,str(host))
spec=importlib.util.spec_from_file_location('collector_setup',host/'setup.py');setup=importlib.util.module_from_spec(spec);spec.loader.exec_module(setup)
TEST_HTTPS_TARGET = uuid.uuid4().hex + '.ts.net:443'

class SetupTest(unittest.TestCase):
 def test_preserves_existing_service_and_rejects_public_funnel(self):
  for config in [{'AllowFunnel':{TEST_HTTPS_TARGET:True}},{'Foreground':{'session':{'AllowFunnel':{TEST_HTTPS_TARGET:True}}}},{'Web':{TEST_HTTPS_TARGET:{'Handlers':{'/':{'Proxy':'http://localhost:9000'}}}}}]:
   with self.assertRaises(RuntimeError):setup.verify_private_serve(config)
 def test_empty_or_existing_private_collector_is_safe(self):
  setup.verify_private_serve({});setup.verify_private_serve({'AllowFunnel':{TEST_HTTPS_TARGET:False},'Web':{TEST_HTTPS_TARGET:{'Handlers':{'/':{'Proxy':'http://127.0.0.1:8481'}}}}})
if __name__=='__main__':unittest.main()
