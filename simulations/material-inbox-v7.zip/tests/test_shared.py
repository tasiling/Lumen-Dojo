import importlib, pathlib, sys, tempfile, unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'selfhost/runtime'))

class SharedTest(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.assertTrue((pathlib.Path(__file__).resolve().parents[1]/'selfhost/runtime/collection_store.py').exists(),'shared persistent collection is missing')
  self.m=importlib.import_module('collection_store');self.s=self.m.Store(pathlib.Path(self.tmp.name)/'inbox.db')
 def row(self):return {'id':'material-1','title':'範例','url':'','transcript':'原始逐字稿','original':'來源原文'}
 def test_shared_persistence_and_conflict(self):
  r=self.s.save(self.row(),0);other=self.m.Store(self.s.path)
  self.assertEqual(other.list()[0]['transcript'],'原始逐字稿')
  updated=self.s.save({**r,'notes':'Mac修改'},r['version'])
  with self.assertRaises(self.m.Conflict):other.save({**r,'notes':'手機舊版'},r['version'])
  self.assertEqual(other.list()[0]['notes'],'Mac修改')
 def test_import_keeps_existing_and_dedupes_url(self):
  r={**self.row(),'url':'https://example.org/source'};self.s.save(r,0)
  result=self.s.merge([{**r,'transcript':'不應覆寫'},{**r,'id':'another'}])
  self.assertEqual(result,{'added':0,'skipped':2})
  self.assertEqual(self.s.list()[0]['transcript'],'原始逐字稿')
 def test_job_idempotency_snapshot_and_stale_result(self):
  r=self.s.save(self.row(),0)
  j=self.s.enqueue(r['id'],'summary','request-1')
  self.assertEqual(j['id'],self.s.enqueue(r['id'],'summary','request-1')['id'])
  lease=self.s.claim();self.assertIsNone(self.s.claim())
  self.s.save({**r,'transcript':'新的原稿'},1)
  self.s.finish(j['id'],lease['lease'],'整理完成','')
  saved=self.s.list()[0]
  self.assertEqual(saved['transcript'],'新的原稿')
  self.assertEqual(saved.get('aiSummary',''),'')
  self.assertTrue(saved['aiRuns'][0]['stale'])
  self.assertEqual(saved['aiRuns'][0]['source']['transcript'],'原始逐字稿')
 def test_failed_worker_and_wrong_lease_do_not_overwrite(self):
  r=self.s.save(self.row(),0);j=self.s.enqueue(r['id'],'reading','request-2');lease=self.s.claim()
  with self.assertRaises(self.m.Conflict):self.s.finish(j['id'],'wrong','bad','')
  self.s.finish(j['id'],lease['lease'],'','訂閱額度不足')
  self.assertEqual(self.s.jobs()[0]['status'],'FAILED')
  self.assertEqual(self.s.list()[0]['transcript'],'原始逐字稿')
class LargeHistoryTest(unittest.TestCase):
 def test_edit_after_many_ai_runs_keeps_history(self):
  with tempfile.TemporaryDirectory() as d:
   from collection_store import Store
   st=Store(pathlib.Path(d)/'test.db');st.save({'id':'large','title':'Long','transcript':'中'*160000},0)
   for i in range(9):
    st.enqueue('large','summary',str(i));j=st.claim();st.finish(j['id'],j['lease'],'摘要','')
   record=st.get('large');record['notes']='保留編輯能力';saved=st.save(record,record['version'])
   self.assertEqual(saved['notes'],'保留編輯能力');self.assertEqual(len(saved['aiRuns']),9)

if __name__=='__main__':unittest.main()
