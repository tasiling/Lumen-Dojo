"""Real BiliNote / Whisper integration; no mocked transcription or model server."""
import importlib.util
import json
import os
import pathlib
import sys
import uuid

from fastapi import FastAPI
from fastapi.testclient import TestClient
import pytest

ROOT = pathlib.Path(__file__).resolve().parents[1]
BACKEND = pathlib.Path(os.environ['BILINOTE_SOURCE']) / 'backend'
sys.path.insert(0,str(BACKEND))


def runtime_module():
    path=ROOT/'selfhost/runtime/collector_runtime.py'
    assert path.exists(), '缺少能自動安裝並驗證模型的真正轉錄服務'
    spec=importlib.util.spec_from_file_location('collector_runtime',path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_not_ready_until_real_model_and_speech_probe_finish(tmp_path):
    m=runtime_module()
    r=m.CollectorRuntime(tmp_path)
    assert r.health()['ready'] is False
    assert r.health()['phase']=='not_started'


@pytest.fixture(scope='module')
def service(tmp_path_factory):
    m=runtime_module()
    r=m.CollectorRuntime(tmp_path_factory.mktemp('runtime'))
    r.prepare()
    from main import create_app, lifespan
    app=create_app(lifespan)
    m.install(app,r)
    with TestClient(app,base_url='http://127.0.0.1') as client:
        yield client,r,m


def test_real_chinese_model_is_ready_without_cloud_provider(service):
    c,r,m=service
    d=c.get('/api/collector/health').json()['data']
    assert d['ready'] is True
    assert d['speech_probe']['language']=='zh'
    assert d['speech_probe']['characters']>=8
    models=c.get('/api/collector/models').json()['data']
    assert models[0]['provider_id']=='local-whisper'


def test_real_file_transcription_has_chinese_text_timestamps_and_persistent_task(service):
    c,r,m=service
    task=str(uuid.uuid4())
    fixture=ROOT/'selfhost/runtime/fixtures/zh.mp3'
    response=c.post('/api/collector/transcribe-file',data={'task_id':task},files={'file':('zh.mp3',fixture.read_bytes(),'audio/mpeg')})
    assert response.status_code==200,response.text
    d=c.get('/api/collector/tasks/'+task).json()['data']
    assert d['status']=='SUCCESS',d
    t=d['result']['transcript']
    assert t['language']=='zh'
    assert len(t['full_text'])>8
    assert len(t['segments'])>=1
    assert all(s['end']>=s['start']>=0 for s in t['segments'])
    assert d['result']['markdown']==''
    assert (r.tasks_dir/(task+'.json')).is_file()
    repeat=c.post('/api/collector/transcribe-file',data={'task_id':task},files={'file':('zh.mp3',fixture.read_bytes(),'audio/mpeg')})
    assert repeat.json()['data']['task_id']==task
    assert c.get('/api/collector/tasks/'+task).json()['data']==d


def test_unknown_task_is_missing_not_fake_pending(service):
    c,_,_=service
    assert c.get('/api/collector/tasks/'+str(uuid.uuid4())).status_code==404


def test_rejects_spoofed_source_host_and_private_network(service):
    c,_,_=service
    for u in ['http://127.0.0.1/','https://douyin.com.evil.invalid/video/123','https://example.com/?douyin=1']:
        resp=c.post('/api/collector/transcribe',json={'task_id':str(uuid.uuid4()),'video_url':u})
        assert resp.status_code==400


def test_rejects_foreign_web_origin_and_host(service):
    c,_,_=service
    assert c.get('/api/collector/health',headers={'Host':'evil.invalid'}).status_code==403
    assert c.get('/api/collector/health',headers={'Origin':'https://evil.invalid'}).status_code==403


def test_rejects_unsupported_upload_without_losing_original_jobs(service):
    c,_,_=service
    resp=c.post('/api/collector/transcribe-file',data={'task_id':str(uuid.uuid4())},files={'file':('bad.html',b'<script>bad</script>','text/html')})
    assert resp.status_code==400
