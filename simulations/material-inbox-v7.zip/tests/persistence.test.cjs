const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const vm=require('node:vm');
test('overlapping creates never imply deletion of a separately saved record',async()=>{
 const source=fs.readFileSync('dist/app.js','utf8');
 const implementation=source.slice(source.indexOf('let writeQueue='),source.indexOf('function selectedRecord()'));
 const rows=new Map(),calls=[];
 const context=vm.createContext({shared:true,blocked:false,records:[],C:{record:x=>x},JSON,Promise,Error,
  api:async(path,options)=>{calls.push(options.method);await new Promise(r=>setTimeout(r,5));if(options.method==='DELETE')throw Error('unrequested delete');const data=JSON.parse(options.body);const row={...data.record,version:1};rows.set(row.id,row);return row;}});
 vm.runInContext(implementation,context);
 await vm.runInContext("Promise.all([persist([{id:'a',title:'A',version:0}]),persist([{id:'b',title:'B',version:0}])])",context);
 assert.equal(rows.size,2);assert.equal(context.records.length,2);assert.deepEqual(calls,['PUT','PUT']);
});
