"""Regression for Bilibili CDN 567 and resumable downloads, using real yt-dlp."""
import pathlib
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'selfhost/runtime'))
from bilibili_media import apply_bilibili_media_range_patch
from yt_dlp import YoutubeDL
from yt_dlp.downloader.http import HttpFD
from yt_dlp.extractor.bilibili import BilibiliBaseIE

PAYLOAD = bytes(range(256)) * 256


class MediaServer(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        value = self.headers.get('Range')
        self.server.ranges.append(value)
        if not value:
            self.send_response(567)
            self.send_header('Content-Length', '0')
            self.end_headers()
            return
        start = int(value.split('=')[1].split('-')[0])
        self.send_response(206)
        self.send_header('Content-Type', 'audio/mp4')
        self.send_header('Content-Length', str(len(PAYLOAD) - start))
        self.send_header('Content-Range', f'bytes {start}-{len(PAYLOAD)-1}/{len(PAYLOAD)}')
        self.end_headers()
        self.wfile.write(PAYLOAD[start:])


class QuietLogger:
    def debug(self, text): pass
    def warning(self, text): pass
    def error(self, text): pass


class BilibiliMediaTest(unittest.TestCase):
    def formats(self, ydl, url):
        return BilibiliBaseIE(ydl).extract_formats({
            'support_formats': [],
            'dash': {'audio': [{'id': 30280, 'baseUrl': url,
                               'mimeType': 'audio/mp4', 'codecs': 'mp4a.40.2',
                               'bandwidth': 128000}], 'video': []},
        })

    def download(self, prefix=b''):
        apply_bilibili_media_range_patch()
        server = ThreadingHTTPServer(('127.0.0.1', 0), MediaServer)
        server.ranges = []
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with tempfile.TemporaryDirectory() as temp, YoutubeDL({
                'proxy': '', 'quiet': True, 'noprogress': True,
                'logger': QuietLogger(), 'retries': 0, 'ignoreerrors': True,
            }) as ydl:
                info = self.formats(ydl, 'https://upos-sz-mirrorcosov.bilivideo.com/audio.m4s')[0]
                # Only the transport endpoint is local; real extractor headers and
                # real yt-dlp HTTP downloader handle the request and resumption.
                info['url'] = f'http://127.0.0.1:{server.server_port}/audio.m4s'
                filename = pathlib.Path(temp) / 'audio.m4a'
                if prefix:
                    pathlib.Path(str(filename) + '.part').write_bytes(prefix)
                success, _ = HttpFD(ydl, ydl.params).download(str(filename), info)
                self.assertTrue(success, 'CDN rejected a download without its required Range header')
                self.assertEqual(filename.read_bytes(), PAYLOAD)
                self.assertEqual(server.ranges, [f'bytes={len(prefix)}-'])
        finally:
            server.shutdown()
            server.server_close()
            thread.join()

    def test_download_reaches_server_with_range_and_preserves_all_bytes(self):
        self.download()

    def test_partial_download_resumes_without_duplicate_bytes(self):
        self.download(PAYLOAD[:12345])

    def test_patch_is_idempotent_and_does_not_change_other_hosts_or_api_headers(self):
        apply_bilibili_media_range_patch()
        first = BilibiliBaseIE.extract_formats
        apply_bilibili_media_range_patch()
        self.assertIs(first, BilibiliBaseIE.extract_formats)
        with YoutubeDL({'quiet': True, 'proxy': '', 'http_headers': {'Referer': 'https://www.bilibili.com/'}}) as ydl:
            for host in ['api.bilibili.com', 'www.bilibili.com', 'cdn.example.org',
                         'bilivideo.com.evil.invalid', 'evilbilivideo.com']:
                fmt = self.formats(ydl, f'https://{host}/audio.m4s')[0]
                self.assertNotIn('Range', fmt.get('http_headers', {}))
            fmt = self.formats(ydl, 'https://upos-sz-mirrorcosov.bilivideo.com/audio.m4s')[0]
            self.assertEqual(fmt.get('http_headers', {}).get('Range'), 'bytes=0-')
            self.assertNotIn('Range', ydl.params['http_headers'])


if __name__ == '__main__':
    unittest.main()
