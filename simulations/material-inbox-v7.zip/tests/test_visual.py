import importlib,pathlib,sys,tempfile,unittest,subprocess
from PIL import Image,ImageDraw,ImageFont
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'selfhost/runtime'))
class VisualTest(unittest.TestCase):
 def setUp(self):
  self.assertTrue((pathlib.Path(__file__).resolve().parents[1]/'selfhost/runtime/visual_reader.py').exists(),'visual OCR missing')
  self.m=importlib.import_module('visual_reader');self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=pathlib.Path(self.tmp.name)
 def movie(self):
  for n,label in enumerate(['SOURCE 123','FINAL 456']):
   im=Image.new('RGB',(960,540),'white');ImageDraw.Draw(im).text((70,200),label,font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',72),fill='black');im.save(self.root/f'{n}.png')
  subprocess.run(['ffmpeg','-v','error','-framerate','1','-i',str(self.root/'%d.png'),'-c:v','libx264','-pix_fmt','yuv420p',str(self.root/'test.mp4')],check=True)
  return self.root/'test.mp4'
 def test_short_video_reads_first_and_tail_real_ocr(self):
  r=self.m.extract_visual(self.movie(),self.root/'frames',languages='eng',interval=2)
  text=' '.join(s['text'] for s in r['segments'])
  self.assertIn('SOURCE',text);self.assertIn('FINAL',text)
  self.assertTrue(r['sampled']);self.assertTrue(all((self.root/'frames'/s['image']).is_file() for s in r['segments']))
 def test_audio_only_is_rejected_clearly(self):
  wav=self.root/'audio.wav';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','sine=frequency=500:duration=1',str(wav)],check=True)
  with self.assertRaisesRegex(ValueError,'影像'):self.m.extract_visual(wav,self.root/'frames',languages='eng')
if __name__=='__main__':unittest.main()
