"""Public social text candidates. Never treats a login wall as a saved post."""
import re
import time
from urllib.parse import urlsplit, urlunsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

HOSTS = {'threads.com':'threads','www.threads.com':'threads','threads.net':'threads','www.threads.net':'threads','instagram.com':'instagram','www.instagram.com':'instagram','facebook.com':'facebook','www.facebook.com':'facebook','m.facebook.com':'facebook','www.facebook.com':'facebook','fb.watch':'facebook'}

def validate_url(url):
    try:
        p=urlsplit(url)
        if p.scheme not in ('https','http') or p.hostname not in HOSTS or p.username or p.password or p.port not in (None,80,443):raise ValueError()
        if len(url)>4096 or any(ord(c)<33 for c in url):raise ValueError()
        platform=HOSTS[p.hostname]
        if platform=='threads' and not re.match(r'^/(share/[^/]+|@[^/]+/post/[^/]+)/?$',p.path):raise ValueError()
        if platform=='instagram' and not re.match(r'^/(p|reel|reels|tv)/[^/]+/?$',p.path):raise ValueError()
        if platform=='facebook' and p.path in ('','/','/login','/login/'):raise ValueError()
        return urlunsplit(('https',p.hostname,p.path,p.query,'')),platform
    except (ValueError,TypeError,AttributeError):raise ValueError('請使用 Threads、IG 或 Facebook 的公開貼文／分享網址，不能使用個人首頁或登入網址')

def plain(s):
    s=re.sub(r'!?\[!?\[Image[^\n]*','',s)
    s=re.sub(r'!\[[^\]]*\]\([^\n]*','',s)
    s=re.sub(r'\[([^\]]*)\]\(https?://[^\s)]+\)',r'\1',s)
    return re.sub(r'\n{3,}','\n\n',s).strip()

def parse_reader(raw,url):
    url,platform=validate_url(url)
    if 'Markdown Content:' not in raw:raise ValueError('讀取服務未回傳可辨識內容；請稍後重試或手動貼入原文')
    head,body=raw.split('Markdown Content:',1)
    title=re.search(r'^Title: (.*?)(?=\n\n(?:URL Source|Final URL|Published Time|Warning):|\Z)',head,re.S)
    title=title.group(1).strip() if title else ''
    final=re.search(r'^Final URL: (\S+)',head,re.M)
    canonical=url
    if final:
        try:
            candidate,p=validate_url(final.group(1))
            if p==platform:canonical=candidate
        except ValueError:pass
    result={'provider':'Jina Reader','platform':platform,'sourceUrl':url,'canonicalUrl':canonical,'fetchedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'author':'','text':'','authorReplies':[],'quality':'partial','warnings':[]}
    if platform=='threads':
        # Related posts can contain duplicates of the entire main post.
        body=re.split(r'(?im)^\s*(?:#{1,4}\s*)?(?:Related threads|相關串文|相關貼文)\s*$',body)[0]
        links=list(re.finditer(r'(?m)^\[([^\]\n]+)\]\((https://(?:www\.)?threads\.(?:com|net)/@([^/\s]+)/post/[^\s)]+)\)\s*$',body))
        canonical_id=re.search(r'/post/([^/?]+)',canonical)
        if not canonical_id:
            thread=re.search(r'# \[Thread\]\((https://[^)]+)\)',body)
            if thread:
                try:canonical,_=validate_url(thread.group(1));result['canonicalUrl']=canonical
                except ValueError:pass
            canonical_id=re.search(r'/post/([^/?]+)',canonical)
        main_index=next((i for i,m in enumerate(links) if canonical_id and '/post/'+canonical_id.group(1)==urlsplit(m.group(2)).path[urlsplit(m.group(2)).path.index('/post/'):]),None)
        if main_index is not None:
            author=links[main_index].group(3);result['author']='@'+author
            seen=set()
            for i,m in enumerate(links[main_index:],main_index):
                chunk=body[m.end():links[i+1].start() if i+1<len(links) else len(body)]
                # A profile picture starts the next reply even before its date link.
                chunk=re.split(r'(?m)^\[?!\[Image[^\n]*profile picture',chunk)[0]
                marked='·Author' in chunk
                chunk=chunk.replace('·Author','').strip()
                boundary=re.search(r'(?im)^\s*(Translate|翻譯|See translation|View activity|Log in to see more replies)\s*$',chunk)
                if boundary:chunk=chunk[:boundary.start()]
                else:
                    # Trailing interaction counts only; never remove numbers inside prose.
                    chunk=re.sub(r'(?:\n\s*\d[\d.,]*[KMB]?\s*)+$','',chunk)
                text=plain(chunk)
                if not text:continue
                if i==main_index:
                    result['text']=text;result['quality']='review'
                elif m.group(3)==author and marked and text not in seen and text!=result['text']:
                    result['authorReplies'].append({'text':text,'url':m.group(2).split('?')[0]})
                seen.add(text)
            result['canonicalUrl']=links[main_index].group(2).split('?')[0]
        result['warnings'].append('只包含公開可見文字；作者回覆不一定是續文，留言可能不完整。圖片與影片內容尚未辨識。')
    elif platform=='instagram':
        # Metadata alone is partial. Promote only when caption also occurs in page body.
        m=re.match(r'(.+?) on Instagram:\s*["“](.*)["”]$',title,re.S)
        if m:
            result['author']=m.group(1);result['text']=m.group(2).strip()
            if re.sub(r'\s','',result['text']) in re.sub(r'\s','',plain(body)):result['quality']='review'
        result['warnings'].append('IG 擷取仍需核對原貼文；不含圖片文字、影片口述與留言。')
    else:
        # Facebook often exposes only title metadata behind a See more/login wall.
        if '|' in title:
            caption,author=title.rsplit('|',1)
            caption=re.sub(r'^.*?\breactions\s*\|\s*','',caption,flags=re.S)
            result['text']=caption.strip();result['author']=author.strip()
        result['warnings'].append('Facebook 目前只提供頁面摘要候選，可能截斷；不能視為完整原文。')
    if not result['text'] or re.fullmatch(r'(Log ?[Ii]n|Instagram|Facebook|Threads|登入)(\s*[|·].*)?',result['text']):
        raise ValueError('未找到可辨識的貼文文字。可能需要登入、貼文已移除或格式改變；請手動貼入原文。')
    if len(result['text'])>100000:raise ValueError('貼文內容超過擷取上限，請手動分段保存')
    result['authorReplies']=result['authorReplies'][:100]
    if re.search(r'(See more|閱讀更多|顯示更多|\.\.\.|…)$',result['text']):result['quality']='partial'
    if 'Warning:' in head:result['quality']='partial';result['warnings'].append('讀取服務提示頁面可能尚未載入完整。')
    result['title']=result['text'].splitlines()[0][:80]
    return result

def extract(url):
    url,_=validate_url(url)
    request=Request('https://r.jina.ai/'+url,headers={'Accept':'text/plain','User-Agent':'MaterialInbox/0.5'})
    try:
        with urlopen(request,timeout=40) as response:
            raw=response.read(1024*1024+1)
            if len(raw)>1024*1024:raise ValueError('頁面過大，請手動貼入原文')
        return parse_reader(raw.decode('utf-8'),url)
    except HTTPError as e:
        raise ValueError('Jina 暫時限制請求，請稍後重試' if e.code==429 else '讀取服務無法取得貼文，請稍後重試或手動貼入') from e
    except (URLError,TimeoutError,UnicodeError) as e:raise ValueError('網頁讀取逾時或連線失敗，尚未變更素材；可重試或手動貼入') from e
