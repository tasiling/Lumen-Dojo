"""Start BiliNote and automatically prepare the local transcription model."""
import os
import threading
import uvicorn
from bilibili_media import apply_bilibili_media_range_patch

apply_bilibili_media_range_patch()

from main import app
from collector_runtime import install

runtime = install(app)

def prepare():
    try:
        runtime.prepare()
    except Exception:
        # Health reports the actual phase/error; it never turns ready on failure.
        import logging
        logging.getLogger('collector').exception('語音模型初始化未完成')

if __name__ == '__main__':
    threading.Thread(target=prepare, daemon=True).start()
    uvicorn.run(app, host='0.0.0.0', port=int(os.getenv('BACKEND_PORT', '8483')))
