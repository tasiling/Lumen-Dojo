"""Shared collection and leased AI jobs. SQLite transactions protect concurrent devices."""
import contextlib
import json
import sqlite3
import time
import uuid
from pathlib import Path
from urllib.parse import urlsplit

class Conflict(Exception): pass
class Missing(Exception): pass


def clean_record(row):
    if not isinstance(row, dict): raise ValueError('素材格式不正確')
    out = dict(row)
    if not isinstance(out.get('id'), str) or not 1 <= len(out['id']) <= 200: raise ValueError('素材識別不正確')
    if not isinstance(out.get('title'), str) or not out['title'].strip(): raise ValueError('請填寫標題')
    out['title'] = out['title'].strip()[:300]
    url = out.get('url', '')
    if url:
        try:
            parsed = urlsplit(url)
            if parsed.scheme not in ('http','https') or not parsed.hostname or parsed.username or parsed.password: raise ValueError()
        except (ValueError, TypeError): raise ValueError('來源網址不正確')
    if len(json.dumps({k:v for k,v in out.items() if k not in ('aiRuns','revisions')},ensure_ascii=False).encode()) > 4*1024*1024: raise ValueError('單筆素材超過 4 MB')
    for field in ('original','transcript','aiSummary','notes','visualText'):
        if not isinstance(out.get(field,''),str): raise ValueError('素材文字格式不正確')
        out.setdefault(field,'')
    return out


class Store:
    def __init__(self,path):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        with self.connect() as c:
            c.execute('PRAGMA journal_mode=WAL')
            c.executescript('''CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY, url TEXT NOT NULL, version INTEGER NOT NULL, body TEXT NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS unique_source ON records(url) WHERE url != '';
CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, request_id TEXT UNIQUE NOT NULL, record_id TEXT NOT NULL, mode TEXT NOT NULL, source_version INTEGER NOT NULL, source TEXT NOT NULL, status TEXT NOT NULL, lease TEXT, deadline REAL, result TEXT, error TEXT, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);''')
    @contextlib.contextmanager
    def connect(self):
        c=sqlite3.connect(self.path,timeout=20);c.row_factory=sqlite3.Row
        try:
            yield c;c.commit()
        except Exception:c.rollback();raise
        finally:c.close()
    def list(self):
        with self.connect() as c:return [json.loads(r['body']) for r in c.execute('SELECT body FROM records ORDER BY rowid DESC')]
    def get(self,id):
        with self.connect() as c:
            r=c.execute('SELECT body FROM records WHERE id=?',(id,)).fetchone()
            if not r:raise Missing('找不到素材')
            return json.loads(r['body'])
    def save(self,row,expected_version):
        row=clean_record(row)
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');old=c.execute('SELECT version,body FROM records WHERE id=?',(row['id'],)).fetchone()
            version=old['version'] if old else 0
            if version!=expected_version:raise Conflict('其他裝置已修改這筆素材；請先重新讀取再保存')
            if old:
                previous=json.loads(old['body'])
                # AI histories are server-owned; browser edits cannot erase them.
                row['aiRuns']=previous.get('aiRuns',[])
                row['revisions']=previous.get('revisions',[])
                if any(row.get(k,'')!=previous.get(k,'') for k in ('original','transcript','visualText','aiSummary')):
                    revisions=previous.get('revisions',[])
                    row['revisions']=(revisions+[{'at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),**{k:previous.get(k,'') for k in ('original','transcript','visualText','aiSummary')}}])[-20:]
            row['version']=version+1
            try:c.execute('INSERT INTO records VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET url=excluded.url,version=excluded.version,body=excluded.body',(row['id'],row.get('url',''),row['version'],json.dumps(row,ensure_ascii=False)))
            except sqlite3.IntegrityError:raise Conflict('這個來源已在共用收藏中')
        return row
    def delete(self,id,expected_version):
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');row=c.execute('SELECT version FROM records WHERE id=?',(id,)).fetchone()
            if not row:raise Missing('找不到素材')
            if row['version']!=expected_version:raise Conflict('素材已有新版本，請重新讀取')
            c.execute('DELETE FROM records WHERE id=?',(id,))
    def merge(self,rows):
        if not isinstance(rows,list) or len(rows)>2000:raise ValueError('一次最多匯入 2,000 筆')
        rows=[clean_record(r) for r in rows];added=skipped=0
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            for row in rows:
                if c.execute('SELECT id FROM records WHERE id=? OR (url=? AND url!=\'\')',(row['id'],row.get('url',''))).fetchone():skipped+=1;continue
                row['version']=1
                c.execute('INSERT INTO records VALUES(?,?,1,?)',(row['id'],row.get('url',''),json.dumps(row,ensure_ascii=False)));added+=1
        return {'added':added,'skipped':skipped}
    def enqueue(self,record_id,mode,request_id):
        if mode not in ('reading','summary','notes'):raise ValueError('未知整理方式')
        if not isinstance(request_id,str) or not 1<=len(request_id)<=100:raise ValueError('請求識別不正確')
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            old=c.execute('SELECT * FROM jobs WHERE request_id=?',(request_id,)).fetchone()
            if old:
                if old['record_id']!=record_id or old['mode']!=mode:raise Conflict('同一請求不可使用不同素材')
                return dict(old)
            r=c.execute('SELECT * FROM records WHERE id=?',(record_id,)).fetchone()
            if not r:raise Missing('找不到素材')
            source=json.loads(r['body'])
            if not any(source.get(k,'').strip() for k in ('original','transcript','visualText')):raise ValueError('尚無可整理的文字')
            if c.execute("SELECT id FROM jobs WHERE record_id=? AND status IN ('PENDING','RUNNING')",(record_id,)).fetchone():raise Conflict('這筆素材已有待處理的 AI 任務')
            id=str(uuid.uuid4())
            c.execute('INSERT INTO jobs(id,request_id,record_id,mode,source_version,source,status,created) VALUES(?,?,?,?,?,?,?,?)',(id,request_id,record_id,mode,r['version'],json.dumps(source,ensure_ascii=False),'PENDING',time.time()))
            return dict(c.execute('SELECT * FROM jobs WHERE id=?',(id,)).fetchone())
    def jobs(self):
        with self.connect() as c:
            c.execute("UPDATE jobs SET status='FAILED',error='工作程序中斷或逾時；請確認後重新提出' WHERE status='RUNNING' AND deadline<?",(time.time(),))
            return [{k:r[k] for k in ('id','request_id','record_id','mode','status','result','error','created','source_version')} for r in c.execute('SELECT * FROM jobs ORDER BY created DESC LIMIT 200')]
    def claim(self):
        self.jobs()
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute("SELECT id FROM jobs WHERE status='RUNNING'").fetchone():return None
            row=c.execute("SELECT * FROM jobs WHERE status='PENDING' ORDER BY created LIMIT 1").fetchone()
            if not row:return None
            lease=str(uuid.uuid4());c.execute("UPDATE jobs SET status='RUNNING',lease=?,deadline=? WHERE id=?",(lease,time.time()+960,row['id']))
            return {**dict(row),'lease':lease,'source':json.loads(row['source'])}
    def finish(self,id,lease,result,error):
        if not isinstance(result,str) or len(result)>500000:raise ValueError('整理結果過長或格式不正確')
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE');job=c.execute('SELECT * FROM jobs WHERE id=?',(id,)).fetchone()
            if not job or job['lease']!=lease or job['status']!='RUNNING':raise Conflict('任務租約失效，未覆寫結果')
            if not result.strip() and not error:error='AI 沒有回傳可用結果'
            c.execute('UPDATE jobs SET status=?,result=?,error=? WHERE id=?',('FAILED' if error else 'SUCCESS',result,error,id))
            row=c.execute('SELECT * FROM records WHERE id=?',(job['record_id'],)).fetchone()
            if row and not error:
                record=json.loads(row['body']);source=json.loads(job['source'])
                stale=any(record.get(k)!=source.get(k) for k in ('title','url','original','transcript','visualText'))
                run={'jobId':id,'mode':job['mode'],'text':result,'source':{k:source.get(k,'') for k in ('title','url','original','transcript','visualText')},'sourceVersion':job['source_version'],'stale':stale,'at':time.time()}
                record['aiRuns']=(record.get('aiRuns',[])+[run])[-20:]
                if not stale:record['aiSummary']=result
                record['version']=row['version']+1
                c.execute('UPDATE records SET version=?,body=? WHERE id=?',(record['version'],json.dumps(record,ensure_ascii=False),record['id']))
    def heartbeat(self):
        with self.connect() as c:c.execute("INSERT OR REPLACE INTO settings VALUES('worker_seen',?)",(str(time.time()),))
    def worker_online(self):
        with self.connect() as c:r=c.execute("SELECT value FROM settings WHERE key='worker_seen'").fetchone()
        return bool(r and time.time()-float(r['value'])<60)
