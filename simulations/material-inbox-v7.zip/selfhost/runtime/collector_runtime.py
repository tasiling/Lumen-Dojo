"""A local-only transcription bridge over BiliNote's real downloaders and Whisper.

No external LLM or API key is needed. Model readiness means a real speech probe
completed, not merely that a model.bin exists or a web server returned 200.
"""
import hashlib
import json
import os
import re
import subprocess
import threading
import time
import uuid
from dataclasses import asdict
from pathlib import Path
from urllib.parse import urlparse

from fastapi import BackgroundTasks, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse
from pydantic import BaseModel

MODEL_REPO = 'Systran/faster-whisper-base'
MODEL_REVISION = 'ebe41f70d5b6dfa9166e2c581c45c9c0cfc57b66'
LOCAL_HOSTS = {'127.0.0.1', 'localhost', '::1', 'bilinote', 'bilinote_engine'}
MAX_UPLOAD = 200 * 1024 * 1024


def success(data):
    return {'code': 0, 'msg': 'success', 'data': data}


def valid_task(value):
    try:
        return str(uuid.UUID(str(value)))
    except (ValueError, TypeError, AttributeError):
        raise HTTPException(400, '任務識別格式不正確')


def source_platform(url):
    try:
        u = urlparse(url)
        port = u.port
    except ValueError:
        raise HTTPException(400, '影片網址格式不正確')
    if u.scheme != 'https' or u.username or u.password or port not in (None, 443):
        raise HTTPException(400, '請使用支援平台的公開 HTTPS 影片連結')
    h = (u.hostname or '').lower()
    for domain, platform in [('bilibili.com', 'bilibili'), ('b23.tv', 'bilibili'),
                             ('douyin.com', 'douyin'), ('youtube.com', 'youtube'),
                             ('youtu.be', 'youtube')]:
        if h == domain or h.endswith('.' + domain):
            return platform
    raise HTTPException(400, '這個來源尚未支援自動轉錄；可先使用本機音影片檔')


class CollectorRuntime:
    def __init__(self, root):
        self.root = Path(root)
        self.tasks_dir = self.root / 'collector_tasks'
        self.media_dir = self.root / 'collector_media'
        self.tasks_dir.mkdir(parents=True, exist_ok=True)
        self.media_dir.mkdir(parents=True, exist_ok=True)
        self.model = None
        self.phase = 'not_started'
        self.error = ''
        self.probe = None
        self.lock = threading.RLock()
        self.model_lock = threading.Lock()
        self.prepare_lock = threading.Lock()
        # A stopped process cannot leave a task deceptively pending forever.
        for path in self.tasks_dir.glob('*.json'):
            try:
                data = json.loads(path.read_text())
                if data.get('status') in ('PENDING', 'DOWNLOADING', 'TRANSCRIBING'):
                    data.update(status='FAILED', message='服務曾中斷，請重新提出任務')
                    self._write(data)
            except (OSError, ValueError):
                continue

    def health(self):
        return {'ready': self.phase == 'ready', 'phase': self.phase, 'message': self.error,
                'model': 'base', 'model_revision': MODEL_REVISION,
                'speech_probe': self.probe, 'requires_api_key': False}

    def prepare(self):
        with self.prepare_lock:
            if self.phase == 'ready':
                return self.health()
            try:
                self.phase = 'downloading'
                os.environ.setdefault('HF_HUB_DISABLE_TELEMETRY', '1')
                from huggingface_hub import snapshot_download
                from app.utils.path_helper import get_model_dir
                from app.transcriber.whisper import WhisperTranscriber
                model_path = snapshot_download(MODEL_REPO, revision=MODEL_REVISION,
                    cache_dir=get_model_dir('whisper'), allow_patterns=[
                        'config.json', 'preprocessor_config.json', 'model.bin',
                        'tokenizer.json', 'vocabulary.*'])
                self.phase = 'loading'
                self.model = WhisperTranscriber(model_size=model_path, device='cpu', compute_type='int8')
                self.phase = 'speech_probe'
                fixture = Path(__file__).parent / 'fixtures' / 'zh.mp3'
                result = self.model.transcript(str(fixture))
                text = result.full_text if result else ''
                characters = len(re.findall(r'[\u3400-\u9fff]', text))
                if not result or result.language != 'zh' or characters < 8 or not result.segments:
                    raise RuntimeError('中文語音自檢未通過，尚不能標記模型就緒')
                self.probe = {'language': result.language, 'characters': characters,
                              'segments': len(result.segments), 'checked_at': time.time()}
                self.phase, self.error = 'ready', ''
                (self.root / 'collector_readiness.json').write_text(
                    json.dumps(self.health(), ensure_ascii=False, indent=2))
                return self.health()
            except Exception as exc:
                self.phase, self.error = 'failed', str(exc)
                raise

    def _write(self, task):
        task['updated_at'] = time.time()
        path = self.tasks_dir / (task['task_id'] + '.json')
        temp = path.with_suffix('.json.tmp')
        temp.write_text(json.dumps(task, ensure_ascii=False, indent=2))
        temp.replace(path)

    def read(self, task_id):
        task_id = valid_task(task_id)
        with self.lock:
            path = self.tasks_dir / (task_id + '.json')
            if not path.exists():
                raise HTTPException(404, '找不到這個任務，尚未確認接收')
            return json.loads(path.read_text())

    def create(self, task_id, fingerprint, **source):
        task_id = valid_task(task_id)
        with self.lock:
            path = self.tasks_dir / (task_id + '.json')
            if path.exists():
                task = json.loads(path.read_text())
                if task['fingerprint'] != fingerprint:
                    raise HTTPException(409, '同一個任務識別不能套用不同素材')
                return task, False
            task = dict(task_id=task_id, fingerprint=fingerprint, status='PENDING',
                        message='', result=None, **source)
            self._write(task)
            return task, True

    def run(self, task):
        # One model / one task at a time, including the download stage.
        with self.model_lock:
            try:
                transcript = None
                file = task.get('file')
                if not file:
                    platform = source_platform(task['video_url'])
                    from app.downloaders.bilibili_downloader import BilibiliDownloader
                    from app.downloaders.douyin_downloader import DouyinDownloader
                    from app.downloaders.youtube_downloader import YoutubeDownloader
                    downloader = {'bilibili': BilibiliDownloader,
                                  'douyin': DouyinDownloader,
                                  'youtube': YoutubeDownloader}[platform]()
                    task['status'] = 'DOWNLOADING'
                    with self.lock: self._write(task)
                    transcript = downloader.download_subtitles(task['video_url'])
                    if not transcript or not transcript.segments:
                        audio = downloader.download(task['video_url'],
                            output_dir=str(self.media_dir), quality='fast')
                        if not audio or not audio.file_path:
                            raise RuntimeError('來源未提供可下載音訊，可改用本機音影片檔')
                        file = audio.file_path
                if not transcript or not transcript.segments:
                    task['status'] = 'TRANSCRIBING'
                    with self.lock: self._write(task)
                    transcript = self.model.transcript(str(file))
                if not transcript or not transcript.full_text.strip():
                    raise RuntimeError('沒有取得可用逐字稿，原始素材仍保留')
                data = {'language': transcript.language, 'full_text': transcript.full_text,
                        'segments': [asdict(s) for s in transcript.segments]}
                task.update(status='SUCCESS', result={'transcript': data, 'markdown': ''}, message='')
            except Exception as exc:
                task.update(status='FAILED', message=str(exc))
            with self.lock: self._write(task)


class VideoRequest(BaseModel):
    video_url: str
    task_id: str


def install(app, runtime=None):
    runtime = runtime or CollectorRuntime(os.getenv('COLLECTOR_DATA_DIR',
        os.getenv('DATA_DIR', 'data')))
    app.state.collector_runtime = runtime

    @app.middleware('http')
    async def local_access_only(request: Request, call_next):
        host = request.url.hostname
        origin = request.headers.get('origin')
        public = os.getenv('COLLECTOR_ALLOWED_ORIGIN', '').rstrip('/')
        public_host = urlparse(public).hostname if public.startswith('https://') and public.endswith('.ts.net') else None
        allowed_hosts = LOCAL_HOSTS | ({public_host} if public_host else set())
        local_origins = {'http://localhost:8481', 'http://127.0.0.1:8481', 'http://localhost:8480', 'http://127.0.0.1:8480'}
        foreign_origin = bool(origin and origin not in local_origins and origin != public)
        if host not in allowed_hosts or foreign_origin or request.headers.get('sec-fetch-site') == 'cross-site':
            return JSONResponse({'detail': '此服務只接受本機頁面存取'}, status_code=403)
        return await call_next(request)

    @app.get('/api/collector/health')
    def health():
        return success(runtime.health())

    @app.get('/api/collector/models')
    def models():
        return success([{'provider_id': 'local-whisper', 'model_name': 'Whisper base（本機語音辨識）'}]
                       if runtime.health()['ready'] else [])

    @app.get('/api/collector/tasks/{task_id}')
    def get_task(task_id: str):
        task = runtime.read(task_id)
        return success({k: task.get(k) for k in ('task_id', 'status', 'message', 'result', 'updated_at')})

    def require_ready():
        if not runtime.health()['ready']:
            raise HTTPException(503, '轉錄模型尚未就緒：' + runtime.phase)

    @app.post('/api/collector/transcribe')
    def transcribe(data: VideoRequest, background_tasks: BackgroundTasks):
        source_platform(data.video_url)
        require_ready()
        fingerprint = hashlib.sha256(data.video_url.encode()).hexdigest()
        task, created = runtime.create(data.task_id, fingerprint, video_url=data.video_url)
        if created: background_tasks.add_task(runtime.run, task)
        return success({'task_id': task['task_id'], 'status': task['status']})

    @app.post('/api/collector/transcribe-file')
    async def transcribe_file(background_tasks: BackgroundTasks,
            task_id: str = Form(...), file: UploadFile = File(...)):
        require_ready()
        task_id = valid_task(task_id)
        suffix = Path(file.filename or '').suffix.lower()
        if suffix not in {'.mp3', '.mp4', '.m4a', '.wav', '.flac', '.ogg', '.webm', '.mov'}:
            raise HTTPException(400, '請選擇支援的音訊或影片檔')
        temp = runtime.media_dir / (str(uuid.uuid4()) + suffix)
        digest, size = hashlib.sha256(), 0
        try:
            with temp.open('wb') as target:
                while chunk := await file.read(1024 * 1024):
                    size += len(chunk)
                    if size > MAX_UPLOAD: raise HTTPException(413, '檔案上限為 200 MB')
                    digest.update(chunk)
                    target.write(chunk)
            if not size: raise HTTPException(400, '檔案是空的')
            task, created = runtime.create(task_id, digest.hexdigest(), file=str(temp))
            if created:
                background_tasks.add_task(runtime.run, task)
            else:
                temp.unlink()
            return success({'task_id': task['task_id'], 'status': task['status']})
        except Exception:
            temp.unlink(missing_ok=True)
            raise
    from collection_api import install_collection
    install_collection(app, runtime)
    return runtime
