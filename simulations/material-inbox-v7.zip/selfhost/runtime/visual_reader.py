"""Bounded frame sampling + real local OCR, with timestamped evidence."""
import csv
import io
import json
import math
import re
import subprocess
from pathlib import Path

def extract_visual(video,output,languages='chi_tra+chi_sim+eng',interval=2):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    info=subprocess.run(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(video)],capture_output=True,text=True,check=True,timeout=30)
    meta=json.loads(info.stdout)
    if not any(s.get('codec_type')=='video' for s in meta.get('streams',[])):raise ValueError('檔案沒有影像軌，只有音訊可轉錄')
    duration=float(meta['format']['duration'])
    if not math.isfinite(duration) or duration<=0 or duration>1800:raise ValueError('畫面辨識目前支援 30 分鐘以內影片')
    stream=next(s for s in meta['streams'] if s.get('codec_type')=='video')
    rate=stream.get('avg_frame_rate','25/1').split('/')
    fps=float(rate[0])/max(float(rate[1]),1)
    tail=max(0, duration-max(0.12,1/max(fps,0.1)))
    interval=max(float(interval),duration/300,0.5)
    timestamps=sorted(set([round(i*interval,3) for i in range(math.ceil(duration/interval))]+[round(tail,3)]))
    segments=[];last=''
    for i,ts in enumerate(timestamps):
        image=output/f'frame-{i:04d}.jpg'
        subprocess.run(['ffmpeg','-v','error','-ss',str(ts),'-i',str(video),'-frames:v','1','-vf','scale=\'min(1920,iw)\':-2','-q:v','2','-y',str(image)],capture_output=True,check=True,timeout=30)
        if not image.exists():continue
        ocr=subprocess.run(['tesseract',str(image),'stdout','-l',languages,'--psm','11','-c','tessedit_create_tsv=1'],capture_output=True,text=True,check=True,timeout=45)
        if not ocr.stdout.startswith('level\t'):raise ValueError('OCR 未回傳可解析的辨識資料')
        lines={};confidence=[]
        for row in csv.DictReader(io.StringIO(ocr.stdout),delimiter='\t'):
            text=(row.get('text') or '').strip()
            try:conf=float(row.get('conf',-1))
            except (ValueError,TypeError):continue
            if not text or conf<0:continue
            key=(row['page_num'],row['block_num'],row['par_num'],row['line_num'])
            lines.setdefault(key,[]).append(text);confidence.append(conf)
        text='\n'.join(' '.join(words) for words in lines.values())
        normalized=re.sub(r'\s+','',text)
        if not normalized:
            last='';image.unlink();continue
        if normalized==last and segments:
            segments[-1]['lastSeen']=ts;image.unlink();continue
        mean=sum(confidence)/len(confidence)
        segments.append({'start':ts,'lastSeen':ts,'text':text,'image':image.name,'confidence':round(mean,1),'needsReview':mean<80})
        last=normalized
    return {'segments':segments,'full_text':'\n\n'.join(f"[{s['start']:.2f}s] {s['text']}" for s in segments),
            'sampled':True,'interval':interval,'duration':duration,'framesChecked':len(timestamps),
            'coverage':'定時取樣，包含首尾；快速閃字可能遺漏，非逐幀完整字幕。'}
