# 中文語音自檢素材

來源：FunAudioLLM / SenseVoiceSmall 官方公開範例。
下載網址：https://huggingface.co/FunAudioLLM/SenseVoiceSmall/resolve/main/example/zh.mp3
用途：啟動時確認模型能實際解碼中文語音及產生時間段。
不代表其他影片的辨識準確度已通過人工驗收。
素材沒有使用本人的私有音訊。
