"""Bilibili CDN compatibility; API/page requests keep their original headers.

Reproduced against BV1CPxB65Eyo on 2026-11-17: without Range the media
server returns 567, with bytes=0- it returns the complete audio via 206.
Upstream report: https://github.com/yt-dlp/yt-dlp/issues/17847
"""
from functools import wraps
from urllib.parse import urlsplit


def apply_bilibili_media_range_patch():
    from yt_dlp.extractor.bilibili import BilibiliBaseIE

    original = BilibiliBaseIE.extract_formats
    if getattr(original, '_collector_media_range', False):
        return

    @wraps(original)
    def extract_formats(self, *args, **kwargs):
        formats = original(self, *args, **kwargs)
        for fmt in formats:
            url = urlsplit(fmt.get('url') or '')
            host = (url.hostname or '').lower()
            if url.scheme not in ('https', 'http') or not (
                host == 'bilivideo.com' or host.endswith('.bilivideo.com')
            ):
                continue
            headers = dict(fmt.get('http_headers') or {})
            if not any(key.lower() == 'range' for key in headers):
                headers['Range'] = 'bytes=0-'
            fmt['http_headers'] = headers
        return formats

    extract_formats._collector_media_range = True
    BilibiliBaseIE.extract_formats = extract_formats
