"""Private shared collection API. Worker credentials never reach the web UI."""
import json, os, re, secrets, threading, time, uuid
from pathlib import Path
from fastapi import Request, HTTPException, BackgroundTasks, UploadFile, File, Form
from fastapi.responses import FileResponse
from collection_store import Store, Conflict, Missing
from visual_reader import extract_visual
from social_reader import extract
from starlette.concurrency import run_in_threadpool

PREFIX='/api/collector'
def ok(data):return {'code':0,'data':data}
def install_collection(app,runtime):
    store=Store(runtime.root/'collector.sqlite3');app.state.collection=store
    token_path=runtime.root/'collector_worker.token'
    try:
        fd=os.open(token_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as f:f.write(secrets.token_urlsafe(48))
    except FileExistsError:pass
    token=token_path.read_text().strip()
    visual_root=runtime.root/'collector_visuals';visual_root.mkdir(exist_ok=True)
    visual_lock=threading.Lock()
    for p in visual_root.glob('*/job.json'):
        try:
            job=json.loads(p.read_text())
            if job['status'] in ('PENDING','RUNNING'):
                job.update(status='FAILED',error='服務曾中斷，請重新提交畫面辨識');p.write_text(json.dumps(job,ensure_ascii=False))
        except (ValueError,KeyError):pass
    @app.exception_handler(Conflict)
    async def conflict(request,exc):
        from fastapi.responses import JSONResponse
        return JSONResponse({'detail':str(exc)},status_code=409)
    @app.exception_handler(Missing)
    async def missing(request,exc):
        from fastapi.responses import JSONResponse
        return JSONResponse({'detail':str(exc)},status_code=404)
    def guarded(fn,*args):
        try:return fn(*args)
        except ValueError as e:raise HTTPException(400,str(e))
    async def body(request):
        raw=await request.body()
        if len(raw)>(64 if request.url.path.endswith('/merge') else 8)*1024*1024:raise HTTPException(413,'請求超過大小上限')
        try:
            value=json.loads(raw)
            if not isinstance(value,dict):raise ValueError()
            return value
        except (ValueError,TypeError):raise HTTPException(400,'請求格式不正確')
    @app.get(PREFIX+'/collection')
    def collection():return ok({'records':store.list(),'workerOnline':store.worker_online()})
    @app.post(PREFIX+'/social/preview')
    async def social_preview(request:Request):
        data=await body(request)
        if data.get('consent') is not True:raise HTTPException(400,'請確認將公開貼文網址交給 Jina Reader 讀取')
        record=store.get(data.get('recordId'))
        if record['version']!=data.get('expectedVersion'):raise Conflict('素材已更新，請重新開啟擷取')
        try:result=await run_in_threadpool(extract,record.get('url',''))
        except ValueError as e:raise HTTPException(422,str(e))
        return ok(result)
    @app.put(PREFIX+'/collection/{id}')
    async def save(id:str,request:Request):
        data=await body(request);record=data.get('record')
        if not isinstance(record,dict) or record.get('id')!=id:raise HTTPException(400,'素材識別不一致')
        return ok(guarded(store.save,record,data.get('expectedVersion')))
    @app.delete(PREFIX+'/collection/{id}')
    def delete(id:str,version:int):store.delete(id,version);return ok(True)
    @app.post(PREFIX+'/merge')
    async def merge(request:Request):return ok(guarded(store.merge,(await body(request)).get('records')))
    @app.get(PREFIX+'/ai/jobs')
    def jobs():return ok({'jobs':store.jobs(),'workerOnline':store.worker_online()})
    @app.post(PREFIX+'/ai/jobs')
    async def enqueue(request:Request):
        d=await body(request)
        if d.get('consent') is not True:raise HTTPException(400,'請確認將文字交給 ChatGPT 訂閱整理')
        if not store.worker_online():raise HTTPException(503,'Mac 的 AI 工作程序尚未連線；請執行 Enable-AI.command')
        j=guarded(store.enqueue,d.get('recordId'),d.get('mode'),d.get('requestId'))
        return ok({k:j[k] for k in ('id','status','record_id')})
    def worker_auth(request):
        if request.headers.get('origin') or request.url.hostname not in ('127.0.0.1','localhost') or not secrets.compare_digest(request.headers.get('authorization',''),'Bearer '+token):
            raise HTTPException(403,'工作程序未配對')
    @app.post(PREFIX+'/worker/claim')
    def claim(request:Request):worker_auth(request);store.heartbeat();return ok(store.claim())
    @app.post(PREFIX+'/worker/heartbeat')
    def heartbeat(request:Request):worker_auth(request);store.heartbeat();return ok(True)
    @app.post(PREFIX+'/worker/finish')
    async def finish(request:Request):
        worker_auth(request);d=await body(request)
        error=d.get('error','')
        if not isinstance(error,str):raise HTTPException(400,'錯誤訊息格式不正確')
        guarded(store.finish,d.get('id'),d.get('lease'),d.get('result',''),error[:500]);return ok(True)
    def job_dir(id):
        try:
            if str(uuid.UUID(id))!=id:raise ValueError()
        except (ValueError,TypeError):raise HTTPException(400,'畫面任務識別不正確')
        return visual_root/id
    def write_job(folder,job):
        temp=folder/'job.tmp';temp.write_text(json.dumps(job,ensure_ascii=False));temp.replace(folder/'job.json')
    def run_visual(folder,job,video):
        with visual_lock:
            try:
                job['status']='RUNNING';write_job(folder,job)
                job['result']=extract_visual(video,folder/'frames');job['status']='SUCCESS'
            except Exception as exc:
                job.update(status='FAILED',error=str(exc)[:500] if isinstance(exc,ValueError) else '畫面辨識失敗，請確認影片格式與 OCR 語言模型')
            write_job(folder,job)
    @app.post(PREFIX+'/visual/upload')
    async def upload(background_tasks:BackgroundTasks,task_id:str=Form(...),record_id:str=Form(...),file:UploadFile=File(...)):
        store.get(record_id);folder=job_dir(task_id)
        if folder.exists():raise HTTPException(409,'這個畫面任務已提交，請更新任務狀態')
        suffix=Path(file.filename or '').suffix.lower()
        if suffix not in ('.mp4','.mov','.webm','.mkv','.m4v'):raise HTTPException(400,'請選擇影片檔')
        folder.mkdir();video=folder/('source'+suffix);size=0
        try:
            with video.open('wb') as target:
                while chunk:=await file.read(1024*1024):
                    size+=len(chunk)
                    if size>200*1024*1024:raise HTTPException(413,'影片上限 200 MB')
                    target.write(chunk)
            if not size:raise HTTPException(400,'影片是空的')
            job={'id':task_id,'recordId':record_id,'status':'PENDING','result':None,'error':''}
            write_job(folder,job);background_tasks.add_task(run_visual,folder,job,video)
            return ok(job)
        except Exception:
            import shutil
            shutil.rmtree(folder);raise
    @app.get(PREFIX+'/visual/{id}')
    def visual(id:str):
        p=job_dir(id)/'job.json'
        if not p.exists():raise HTTPException(404,'找不到畫面任務')
        return ok(json.loads(p.read_text()))
    @app.get(PREFIX+'/visual/{id}/assets/{name}')
    def asset(id:str,name:str):
        if not re.fullmatch(r'frame-\d{4}\.jpg',name):raise HTTPException(404,'找不到截圖')
        p=job_dir(id)/'frames'/name
        if not p.is_file():raise HTTPException(404,'找不到截圖')
        return FileResponse(p,media_type='image/jpeg')
    return store
