"""Apply narrowly scoped fixes to the pinned upstream image's source."""
from pathlib import Path
import sys

root = Path(sys.argv[1])
provider = root / 'app/services/provider.py'
text = provider.read_text()
old = 'return [ProviderService.serialize_provider(row) for row in rows] if (rows) else []'
new = 'return [ProviderService.serialize_provider_safe(row) for row in rows] if (rows) else []'
if old not in text and new not in text:
    raise SystemExit('Pinned source mismatch: provider masking patch cannot be applied')
text = text.replace(old, new)
text = text.replace("            print('更新模型供应商',filtered_data)", '            # Credential values are not written to logs.')
provider.write_text(text)
downloader = root / 'app/downloaders/douyin_downloader.py'
text = downloader.read_text()
text = text.replace('        print(self.headers_config)', '        # Cookie headers are not written to logs.')
downloader.write_text(text)
