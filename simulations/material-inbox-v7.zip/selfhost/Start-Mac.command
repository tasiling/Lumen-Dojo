#!/bin/bash
# Local Mac launcher. No sudo, credential collection, licence auto-acceptance,
# system-wide PATH changes, security changes, or destructive Docker commands.
set -euo pipefail

kit_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
docker_docs='https://docs.docker.com/desktop/setup/install/mac-install/'
check_only=0
if [ "${1:-}" = '--check-only' ]; then check_only=1; fi

fail() {
  printf '\n尚未完成：%s\n' "$1" >&2
  printf '已存在的收藏和 Docker 資料卷不會被刪除。\n' >&2
  exit 1
}

printf '\n素材採集匣與 BiliNote：Mac 本機啟動\n\n'
if [ "$(uname -s)" != Darwin ]; then
  fail '這個啟動程式需要在你的 Mac 上執行。'
fi

mac_arch="$(uname -m)"
if [ "$(/usr/sbin/sysctl -n sysctl.proc_translated 2>/dev/null || true)" = 1 ]; then
  mac_arch=arm64
fi
case "$mac_arch" in
  arm64) chip_name='Apple silicon（M 系列）' ;;
  x86_64) chip_name='Intel' ;;
  *) fail "尚未支援這個處理器架構：$mac_arch" ;;
esac

mac_version="$(/usr/bin/sw_vers -productVersion)"
mac_memory_bytes="$(/usr/sbin/sysctl -n hw.memsize)"
mac_memory_gb=$((mac_memory_bytes / 1073741824))
printf '處理器：%s\nmacOS：%s\n記憶體：%s GB\n' "$chip_name" "$mac_version" "$mac_memory_gb"
printf '這些檢查只在本機顯示，不會上傳你的硬體資訊。\n\n'
if [ "$mac_memory_gb" -lt 4 ]; then
  fail 'Docker Desktop 官方最低需要 4 GB 記憶體。'
fi
if [ "$mac_memory_gb" -lt 8 ]; then
  printf '提醒：本機記憶體較少，BiliNote 應先以短影片驗證實際用量。\n\n'
fi

docker_app=''
for candidate in '/Applications/Docker.app' "$HOME/Applications/Docker.app"; do
  if [ -d "$candidate" ]; then docker_app="$candidate"; break; fi
done
docker_bin="$(command -v docker || true)"
if [ -z "$docker_bin" ] && [ -n "$docker_app" ]; then
  candidate="$docker_app/Contents/Resources/bin/docker"
  if [ -x "$candidate" ]; then docker_bin="$candidate"; fi
fi

if [ -z "$docker_bin" ]; then
  printf '尚未找到 Docker Desktop。\n'
  printf '請在官方下載頁選擇「Mac with %s」對應版本。\n' "$chip_name"
  printf '安裝後將 Docker 放入「應用程式」，開啟並完成首次設定，再執行此啟動程式。\n'
  printf '請在 Docker 的視窗自行閱讀並處理首次使用條款；此程式不會代你接受。\n'
  printf '下載頁：%s\n' "$docker_docs"
  if [ "$check_only" -eq 0 ]; then /usr/bin/open "$docker_docs"; fi
  exit 2
fi

# Never deploy into an accidentally selected remote Docker host.
if [ -n "${DOCKER_HOST:-}" ] || [ -n "${DOCKER_CONTEXT:-}" ]; then
  fail '目前有 Docker 主機覆寫設定。請在沒有 DOCKER_HOST／DOCKER_CONTEXT 的本機終端執行，避免安裝到遠端電腦。'
fi
context_name="$("$docker_bin" context show 2>/dev/null || true)"
context_endpoint="$("$docker_bin" context inspect "$context_name" --format '{{.Endpoints.docker.Host}}' 2>/dev/null || true)"
case "$context_endpoint" in
  unix://*) ;;
  *) fail '目前 Docker context 不是本機 Unix socket，已停止安裝。' ;;
esac

if [ "$check_only" -eq 1 ]; then
  printf 'Docker 執行檔：已找到。\n'
  if "$docker_bin" info --format '{{.ServerVersion}}' >/dev/null 2>&1; then
    printf 'Docker 引擎：運作中。\n'
  else
    printf 'Docker 引擎：尚未就緒。\n'
  fi
  if "$docker_bin" compose version >/dev/null 2>&1; then
    printf 'Docker Compose：已找到。\n'
  else
    printf 'Docker Compose：尚未就緒。\n'
  fi
  printf '\n只檢查環境；沒有啟動、下載或修改任何服務。\n'
  exit 0
fi

if ! "$docker_bin" info --format '{{.ServerVersion}}' >/dev/null 2>&1; then
  if [ -z "$docker_app" ]; then
    fail 'Docker 引擎未啟動，且未找到 Docker.app。請先開啟你的 Docker 服務後重試。'
  fi
  printf '正在開啟 Docker Desktop。若出現首次設定或條款視窗，請在該視窗完成。\n'
  /usr/bin/open "$docker_app"
  docker_ready=0
  for attempt in {1..60}; do
    if "$docker_bin" info --format '{{.ServerVersion}}' >/dev/null 2>&1; then
      docker_ready=1
      break
    fi
    if [ $((attempt % 10)) -eq 0 ]; then
      printf '仍在等待 Docker 引擎，請檢查 Docker Desktop 的視窗。\n'
    fi
    sleep 2
  done
  if [ "$docker_ready" -ne 1 ]; then fail 'Docker 尚未就緒。完成 Docker 視窗的設定後，再執行此程式。'; fi
fi

if ! "$docker_bin" compose version >/dev/null 2>&1; then
  fail 'Docker Compose 尚未就緒，請先確認 Docker Desktop 已完成首次啟動。'
fi
if [ ! -f "$kit_dir/compose.yaml" ] || [ ! -f "$kit_dir/collector/index.html" ]; then
  fail '資料夾不完整。請先解壓整個測試包，不要只移動這個 .command 檔。'
fi

cd "$kit_dir"
printf '正在檢查容器設定。\n'
"$docker_bin" compose config --quiet || fail '容器設定檢查失敗。'
printf '\n正在下載固定版網頁映像，並建置含轉錄修正的 BiliNote。首次可能需要較長時間。\n'
"$docker_bin" compose pull collector || fail '網頁映像下載失敗，尚未完成安裝。'
"$docker_bin" compose build --pull bilinote || fail 'BiliNote 建置失敗，尚未完成安裝。'
printf '\n正在啟動服務；模型會自動下載、載入並進行中文語音自檢。\n'
"$docker_bin" compose up -d --no-build || fail '容器尚未啟動完成。'

engine_ready=0
collector_opened=0
for attempt in {1..360}; do
  # Parse health inside the installed image: no host Python dependency.
  phase="$("$docker_bin" compose exec -T bilinote python -c 'import json,urllib.request; d=json.load(urllib.request.urlopen("http://127.0.0.1:8483/api/collector/health",timeout=5))["data"]; print(d["phase"]); print(d.get("message", ""))' 2>/dev/null || true)"
  # Social text capture only needs the collection API, not the speech model.
  if [ "$collector_opened" -eq 0 ] && /usr/bin/curl --max-time 5 -fsS http://127.0.0.1:8481/engine/api/collector/collection >/dev/null 2>&1; then
    printf '收藏服務已就緒，可先擷取社群文字；語音模型繼續在背景準備。\n'
    /usr/bin/open http://127.0.0.1:8481
    collector_opened=1
  fi
  case "$phase" in
    ready*) engine_ready=1; break ;;
    failed*) fail "語音模型自檢失敗：$phase" ;;
  esac
  if [ $((attempt % 6)) -eq 1 ]; then
    printf '初始化進度：%s\n' "${phase:-等待 BiliNote 啟動}"
  fi
  sleep 5
done
if [ "$engine_ready" -ne 1 ]; then
  fail '模型下載或語音自檢在 30 分鐘內尚未完成；未標記安裝成功。重新執行會沿用已下載的模型。'
fi

# Verify the same nginx route that the collector UI uses, not only backend health.
bridge="$(/usr/bin/curl --max-time 10 -fsS http://127.0.0.1:8481/engine/api/collector/health 2>/dev/null || true)"
if ! printf '%s' "$bridge" | "$docker_bin" compose exec -T bilinote python -c 'import json,sys; d=json.load(sys.stdin); sys.exit(0 if d["data"]["ready"] and d["data"]["speech_probe"]["language"]=="zh" else 1)'; then
  fail '模型已就緒，但採集匣代理連線尚未通過。'
fi
if ! /usr/bin/curl --max-time 10 -fsS http://127.0.0.1:8481/ >/dev/null; then
  fail '模型已就緒，但採集匣網頁尚未能開啟。'
fi

printf '\n本機服務、採集匣連線、語音模型與中文自檢已通過。\n'
printf '素材採集匣：http://127.0.0.1:8481\n'
printf '已自動準備本機 Whisper base，純轉錄不需要 API Key。\n'
printf '影片平台可能另有登入與存取限制；模型就緒不代表每個平台連結都能下載。\n'
printf '要停止服務並保留資料，可在此資料夾執行：docker compose stop\n'
printf '訂閱 AI：執行 Enable-AI.command，通過實際整理自檢後啟用。\n'
printf '手機私人連線：執行 Enable-Mobile.command，檢查成功後會顯示網址。\n'
/usr/bin/open http://127.0.0.1:8481
