#!/usr/bin/env python3
"""Mac-only setup using official clients. No credentials leave the Mac."""
import argparse,hashlib,json,os,pathlib,platform,shutil,subprocess,sys,tarfile,tempfile,time,urllib.request
from codex_worker import run_codex,subscription_env,Worker
ROOT=pathlib.Path(__file__).resolve().parents[1]
STATE=ROOT/'.collector'
def run(args,**kw):return subprocess.run(args,check=True,**kw)
def find(name,extras=()):
    return shutil.which(name) or next((str(p) for p in map(pathlib.Path,extras) if p.is_file() and os.access(p,os.X_OK)),None)
def docker():
    binary=find('docker',['/Applications/Docker.app/Contents/Resources/bin/docker',str(pathlib.Path.home()/'Applications/Docker.app/Contents/Resources/bin/docker')])
    if not binary:raise RuntimeError('請先執行 Start-Mac.command')
    if os.getenv('DOCKER_HOST') or os.getenv('DOCKER_CONTEXT'):raise RuntimeError('請取消遠端 Docker 環境覆寫，僅支援本機引擎')
    endpoint=run([binary,'context','inspect','--format','{{.Endpoints.docker.Host}}'],capture_output=True,text=True).stdout.strip()
    if not endpoint.startswith('unix://'):raise RuntimeError('Docker 必須使用本機 Unix socket')
    return binary

def install_codex():
    existing=find('codex',[str(STATE/'bin/codex'),str(pathlib.Path.home()/'.local/bin/codex'),'/usr/local/bin/codex','/opt/homebrew/bin/codex'])
    if existing:return existing
    arch='aarch64' if platform.machine()=='arm64' else 'x86_64'
    name=f'codex-{arch}-apple-darwin.tar.gz'
    print('正在從 OpenAI 官方 GitHub 發行版下載 Codex…',flush=True)
    request=urllib.request.Request('https://api.github.com/repos/openai/codex/releases/latest',headers={'User-Agent':'MaterialCollector-Mac'})
    with urllib.request.urlopen(request,timeout=30) as r:release=json.load(r)
    asset=next((a for a in release['assets'] if a['name']==name),None)
    if not asset or not str(asset.get('digest','')).startswith('sha256:'):raise RuntimeError('官方下載未提供可核對的 SHA-256，已停止自動安裝')
    url=asset['browser_download_url']
    if not url.startswith('https://github.com/openai/codex/releases/download/'):raise RuntimeError('下載來源不符合官方路徑')
    with tempfile.TemporaryDirectory() as d:
        archive=pathlib.Path(d)/'codex.tar.gz';digest=hashlib.sha256();size=0
        with urllib.request.urlopen(url,timeout=60) as response,archive.open('wb') as f:
            while chunk:=response.read(1024*1024):
                size+=len(chunk)
                if size>200*1024*1024:raise RuntimeError('下載檔超過大小上限')
                digest.update(chunk);f.write(chunk)
        if 'sha256:'+digest.hexdigest()!=asset['digest']:raise RuntimeError('下載完整性核對失敗')
        target=STATE/'bin/codex';target.parent.mkdir(parents=True,exist_ok=True)
        with tarfile.open(archive) as tar:
            members=[m for m in tar.getmembers() if m.isfile() and pathlib.PurePosixPath(m.name).name==name[:-7]]
            if len(members)!=1:raise RuntimeError('官方壓縮檔內容不符預期')
            with tar.extractfile(members[0]) as source,target.open('wb') as dest:shutil.copyfileobj(source,dest)
        target.chmod(0o700)
    return str(target)

def enable_ai():
    d=docker();binary=install_codex();env=subscription_env()
    login=subprocess.run([binary,'login','status'],capture_output=True,text=True,env=env)
    if login.returncode or 'chatgpt' not in (login.stdout+login.stderr).lower():
        print('接著由官方 Codex 開啟登入；請選擇自己的 ChatGPT 訂閱帳號。',flush=True)
        run([binary,'login'],env=env)
    print('正在用訂閱執行一次小型文字整理自檢（會使用少量額度）…',flush=True)
    result=run_codex({'mode':'summary','source':{'title':'連線自檢','transcript':'今天完成素材採集匣連線檢查。原文和整理稿會分開保存。'}},binary)
    if not result:raise RuntimeError('AI 自檢未完成')
    token=run([d,'compose','exec','-T','bilinote','python','-c',"from pathlib import Path;print(Path('/app/backend/data/collector_worker.token').read_text())"],cwd=ROOT,capture_output=True,text=True).stdout.strip()
    if len(token)<32:raise RuntimeError('尚未取得本機配對資料')
    tokenfile=STATE/'worker.token';tokenfile.write_text(token);tokenfile.chmod(0o600)
    worker=Worker(token,binary=binary);worker.request('heartbeat',{})
    print('AI 訂閱整理自檢通過。此視窗保持開啟時，手機和 Mac 都能送出整理任務。按 Control-C 停止。',flush=True)
    while True:
        try:worker.once()
        except Exception:print('本機服務暫時無法連線；稍後重試。',flush=True)
        time.sleep(5)

def verify_private_serve(config):
    if not isinstance(config,dict):raise RuntimeError('無法核對 Tailscale Serve 設定，已停止')
    def check(node):
        if not isinstance(node,dict):return
        if any((node.get('AllowFunnel') or {}).values()):raise RuntimeError('此 Mac 已啟用公開 Funnel，已停止，以免把私人收藏公開')
        for key,web in (node.get('Web') or {}).items():
            handler=(web.get('Handlers') or {}).get('/')
            if key.endswith(':443') and handler and handler.get('Proxy') not in ('http://127.0.0.1:8481','http://localhost:8481'):
                raise RuntimeError('Tailscale 的 HTTPS 根網址已有其他服務；已保留原設定，未覆蓋')
        for value in node.values():
            if isinstance(value,dict):check(value)
    check(config)

def enable_mobile():
    d=docker();binary=find('tailscale',['/Applications/Tailscale.app/Contents/MacOS/Tailscale','/usr/local/bin/tailscale','/opt/homebrew/bin/tailscale'])
    if not binary:
        run(['open','https://tailscale.com/download/mac']);raise RuntimeError('請先安裝官方 Tailscale，Mac 與 iPhone 使用同一帳號登入，再執行此檔')
    state=json.loads(run([binary,'status','--json'],capture_output=True,text=True).stdout)
    host=state.get('Self',{}).get('DNSName','').rstrip('.')
    import re
    if state.get('BackendState')!='Running' or not re.fullmatch(r'[a-zA-Z0-9-]+\.[a-zA-Z0-9-]+\.ts\.net',host):
        run(['open','-a','Tailscale']);raise RuntimeError('請先完成 Tailscale 登入並連線')
    current=json.loads(run([binary,'serve','status','--json'],capture_output=True,text=True).stdout or '{}')
    verify_private_serve(current)
    origin='https://'+host;envfile=ROOT/'.env' 
    original=envfile.read_text() if envfile.exists() else ''
    lines=[line for line in original.splitlines() if not line.startswith('COLLECTOR_ALLOWED_ORIGIN=')]
    envfile.write_text('\n'.join(lines+['COLLECTOR_ALLOWED_ORIGIN='+origin])+'\n');envfile.chmod(0o600)
    run([d,'compose','up','-d','--no-build'],cwd=ROOT)
    run([binary,'serve','--bg','http://127.0.0.1:8481'])
    # This is Serve (private tailnet), never Funnel (public Internet).
    data=None
    for _ in range(30):
        try:
            with urllib.request.urlopen(origin+'/engine/api/collector/collection',timeout=10) as response:data=json.load(response)
            if data.get('code')==0:break
        except Exception:time.sleep(2)
    if not data or data.get('code')!=0:raise RuntimeError('私人網址尚未通過共用資料庫連線檢查；沒有標記手機連線完成')
    (STATE/'mobile-url.txt').write_text(origin)
    print('Mac 私人網址已通過檢查：'+origin+'\n在已登入同一 Tailscale 網路的 iPhone Safari 開啟。Mac 必須保持開機與連線。',flush=True)
    run(['open',origin])

def main():
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['ai','mobile']);args=parser.parse_args()
    if sys.platform!='darwin':raise RuntimeError('此啟用程式只能在 Mac 執行')
    STATE.mkdir(mode=0o700,exist_ok=True);STATE.chmod(0o700)
    {'ai':enable_ai,'mobile':enable_mobile}[args.mode]()
if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('\n已停止 AI 工作程序；收藏資料保留。')
    except Exception as e:print('尚未完成：'+str(e),file=sys.stderr);sys.exit(1)
