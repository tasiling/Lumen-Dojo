#!/usr/bin/env python3
"""Read-only checks; does not install, start, stop or delete anything."""
import json
import shutil
import subprocess
import sys
import urllib.error
import urllib.request

def main():
    docker = shutil.which('docker')
    if not docker:
        print('尚未找到 Docker。請先在預定自架的電腦安裝並啟動 Docker Desktop，或選擇 Docker 主機。')
        return 2
    version = subprocess.run([docker, 'compose', 'version'], capture_output=True, text=True)
    if version.returncode:
        print('Docker Compose 尚未就緒。')
        return 2
    print(version.stdout.strip())
    daemon = subprocess.run([docker, 'info', '--format', '{{.ServerVersion}}'], capture_output=True, text=True)
    if daemon.returncode:
        print('Docker 已安裝，但容器服務尚未啟動。')
        return 2
    print('Docker 服務已就緒。')
    for label, url in [('採集匣', 'http://127.0.0.1:8481/'), ('BiliNote', 'http://127.0.0.1:8481/engine/api/collector/health')]:
        try:
            with urllib.request.urlopen(url, timeout=5) as response:
                if label == 'BiliNote':
                    payload = json.load(response)
                    if payload.get('code') != 0 or not payload.get('data', {}).get('ready'):
                        print(f'{label} 已回應，但模型／語音自檢未完成：{payload.get("data", {}).get("phase", "unknown")}')
                        continue
                print(f'{label} 已可連線（HTTP {response.status}）。')
        except (OSError, ValueError, urllib.error.URLError):
            print(f'{label} 尚未啟動；可先執行 docker compose up -d。')
    return 0

if __name__ == '__main__':
    sys.exit(main())
