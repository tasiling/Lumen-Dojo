#!/bin/bash
set -euo pipefail
kit_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PATH="/usr/local/bin:/opt/homebrew/bin:$PATH"
if ! command -v python3 >/dev/null; then printf '需要 Python 3，請先安裝官方 Python，再重新執行。\n'; open 'https://www.python.org/downloads/macos/'; exit 1; fi
python3 "$kit_dir/host/setup.py" mobile
