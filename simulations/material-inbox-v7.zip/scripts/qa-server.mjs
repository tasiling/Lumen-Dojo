// Development-only server. Optional local runtime config is never packaged.
import http from 'node:http';
import {readFileSync, existsSync} from 'node:fs';
import {spawn} from 'node:child_process';
import path from 'node:path';
const root=process.cwd(),configPath=path.join(root,'.openai/local-runtime.json');
let child;
if(existsSync(configPath)){
 const c=JSON.parse(readFileSync(configPath,'utf8'));
 child=spawn(c.python,[path.join(root,'selfhost/runtime/verified_main.py')],{cwd:c.state,env:{...process.env,...c.env,PYTHONPATH:path.join(root,'selfhost/runtime')+':'+c.source+'/backend'},stdio:['ignore','inherit','inherit']});
}
if(!child) child=spawn('python3',[path.join(root,'scripts/qa_collection.py')],{stdio:['ignore','inherit','inherit']});
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.md':'text/plain','.zip':'application/zip'};
http.createServer(async(req,res)=>{
 if(req.url.startsWith('/engine/api/collector/worker/')){res.writeHead(404);res.end();return;}
 if(req.url.startsWith('/engine/api/')){
  const upstream=http.request({host:'127.0.0.1',port:8483,path:req.url.slice(7),method:req.method,headers:{...req.headers,host:'127.0.0.1:8483',...(req.headers.origin?{origin:'http://127.0.0.1:8481'}:{})}},r=>{res.writeHead(r.statusCode,r.headers);r.pipe(res);});
  upstream.on('error',()=>{res.writeHead(503,{'Content-Type':'application/json'});res.end(JSON.stringify({detail:'本機工程環境尚未啟動'}));});req.pipe(upstream);return;
 }
 try{const name=decodeURIComponent(new URL(req.url,'http://localhost').pathname),file=path.resolve(root,'dist','.'+(name==='/'?'/index.html':name));if(!file.startsWith(root+'/dist/'))throw Error();const body=readFileSync(file);res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream'});res.end(body);}catch{res.writeHead(404);res.end('Not found');}
}).listen(Number(process.env.PORT||4173),'0.0.0.0');
process.on('SIGTERM',()=>{child?.kill();process.exit();});
process.on('SIGINT',()=>{child?.kill();process.exit();});
