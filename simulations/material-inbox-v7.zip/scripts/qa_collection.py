"""Development QA: real SQLite/OCR API; no pretend Whisper readiness."""
import sys,tempfile,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'selfhost/runtime'))
from fastapi import FastAPI
from collector_runtime import CollectorRuntime,install
import uvicorn
app=FastAPI();state=tempfile.TemporaryDirectory(prefix='collector-qa-');install(app,CollectorRuntime(state.name))
uvicorn.run(app,host='127.0.0.1',port=8483,log_level='warning')
