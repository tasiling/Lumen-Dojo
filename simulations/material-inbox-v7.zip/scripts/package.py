#!/usr/bin/env python3
"""Build a private selfhost test kit and a human-readable audit page."""
from pathlib import Path
import json
import shutil
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / 'dist'

html = """<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>素材採集匣 v0.5 狀態</title><style>body{max-width:850px;margin:40px auto;padding:0 22px;font:17px/1.9 system-ui;color:#293c32;background:#fcfaf4}h1{font-size:28px}li{margin-bottom:12px}a{color:#315b49}.status{padding:18px;background:#f2e7cf}</style><a href="/">返回採集匣</a><h1>素材採集匣 v0.5</h1><p class="status">工程測試包，尚未在你的 Mac 完成本輪驗證，也尚未取得使用者驗收。AI 真實訂閱呼叫在雲端因唯讀環境受阻；不能標成已可用。</p><ul><li>社群擷取：Threads 正文與作者回覆分開預覽保存；IG 貼文候選、FB 摘要標示完整度。經 Mac 呼叫 Jina，不需額外 AI 模型。手機可用私人網址操作，Mac 須開機。</li><li>UX 更新：快速收藏、情境操作、自動追蹤、保留錯誤、草稿恢復、內容直連及本頁文字匯出。</li><li>修正 B 站影音下載 HTTP 567：已針對回報影片完成音訊下載與解碼驗證；Mac 容器仍待驗證。</li><li>共用 SQLite 收藏、版本衝突保護與瀏覽器舊資料合併。</li><li>Mac Codex 訂閱工作程序、三種文字整理方式、來源快照；先通過實際整理自檢才啟用。</li><li>Tailscale Serve 私人手機網址與連線檢查；Mac 須保持開機。</li><li>影片檔畫面 OCR、時間點與截圖依據；繁中、簡中、英文在本機辨識。不是逐幀完整擷取，尚未自動從平台網址取得畫面。</li><li>原文、逐字稿、畫面文字、AI 整理稿和個人筆記各自保存。</li></ul><p>線上版僅為介面預覽與下載，不會連入你的 Mac；手機同步請使用自架後的私人網址。</p><p><a href="design.md">安裝、升級與完整限制</a> · <a href="verification.json">本輪驗證紀錄</a></p></html>"""
DIST.joinpath('analysis.html').write_text(html, encoding='utf-8')
shutil.copy2(ROOT / 'docs/design.md', DIST / 'design.md')
with tempfile.TemporaryDirectory() as temp:
    kit = Path(temp) / 'bilinote-selfhost-kit'
    shutil.copytree(ROOT / 'selfhost', kit, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.collector', '.env'))
    collector = kit / 'collector'
    collector.mkdir()
    for name in ('index.html', 'core.js', 'ux.js', 'app.js', 'style.css', 'analysis.html', 'design.md', 'verification.json'):
        path = DIST / name
        if path.exists(): shutil.copy2(path, collector / name)
    # On the local gateway the kit download is not nested into its own ZIP.
    index = collector / 'index.html'
    index.write_text(index.read_text().replace('<a href="bilinote-selfhost-kit.zip" download>下載自架測試包</a>', '<a href="analysis.html">自架說明與分析</a>'))
    analysis = collector / 'analysis.html'
    analysis.write_text(analysis.read_text().replace('<a href="bilinote-selfhost-kit.zip" download>下載自架測試包</a>', '<span>你正在使用已解壓的自架測試包</span>'))
    with zipfile.ZipFile(DIST / 'bilinote-selfhost-kit.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(kit.rglob('*')):
            if path.is_file(): archive.write(path, path.relative_to(Path(temp)))
print(json.dumps({'report': str(DIST / 'analysis.html'), 'kit': str(DIST / 'bilinote-selfhost-kit.zip'), 'size_bytes': (DIST / 'bilinote-selfhost-kit.zip').stat().st_size}))
